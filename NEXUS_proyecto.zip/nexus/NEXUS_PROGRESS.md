# NEXUS_PROGRESS

## ⚠ ESTADO DE VERIFICACIÓN
En la sesión 2 NO había Flutter SDK ni red: **nada de lo nuevo está compilado ni probado**. El código se ha escrito con cuidado pero puede dar errores menores. Primer paso siguiente: `flutter pub get && flutter analyze` y corregir.

## Sesión 1 (código escrito, sin compilar)
12 herramientas originales, tema glass, SQLite, CI (`.github/workflows/build.yml`, `tool/bootstrap.sh`).

## Sesión 2 (código escrito, SIN COMPILAR NI PROBAR)
- Home rediseñada (`lib/home.dart`): cabecera con degradado, buscador, categorías, accesos rápidos (recientes), favoritos (★ o pulsación larga, guardados en SQLite), animaciones.
- `registry.dart`: nuevo campo `cat` (categoría). Las 12 herramientas previas intactas.
- `core/net.dart`: getJson con errores claros, permiso de ubicación con diálogo propio (geolocator), búsqueda de ciudad (Open-Meteo geocoding).
- `weather.dart`: previsión 48 h + 7 días (Open-Meteo), avisos CALCULADOS por umbrales (no oficiales, así se indica), radar de lluvia animado (RainViewer + OSM, flutter_map).
- `nearby.dart`: farmacias, hospitales, gasolineras, restaurantes, cafeterías, supermercados, cajeros, parkings (Overpass/OSM), lista y mapa.
- `calculator.dart` (científica, parser propio), `units.dart` (8 magnitudes + divisas Frankfurter/BCE), `timer.dart`, `tasks.dart`, `translator.dart` (MyMemory, 500 car.), `textdiff.dart`.
- pubspec: +geolocator, flutter_map, latlong2. bootstrap.sh: +permisos de ubicación Android.

## Sesión 3 (NEXUS WORLD, código escrito, SIN COMPILAR NI PROBAR)
- Corregidos errores de compilación reportados: coma sobrante en registry.dart y iconos inexistentes (weather.dart).
- `lib/world/world.dart`: mapa mundial central + capas on/off + filtro de fecha (24 h/7 d/30 d) + panel lateral (Windows/ancho) o bottom sheet (Android) + estado Confirmado/Preliminar + hora de actualización por capa.
  Capas: conflictos (editorial estático), terremotos (USGS), incendios/volcanes/inundaciones/meteo extrema (NASA EONET), calidad del aire (Open-Meteo, 30 ciudades, modelo), aviones (OpenSky anónimo, zoom ≥4), barcos (Digitraffic, SOLO Finlandia/Báltico), ISS (wheretheiss.at, con trazado), cables submarinos (submarinecablemap.com, CC BY-SA 3.0, URL no verificada).
- `lib/world/news.dart`: noticias GDELT (ES/EN/FR; Conflictos/Emergencias/Mundo; también por conflicto).
- `lib/world/data.dart`: 12 fichas de conflicto estáticas, sin cifras de víctimas ni zonas tácticas; revisar vigencia.
- NO implementado por falta de fuente gratuita fiable sin clave: radar marítimo global y puertos, rutas de vuelo, otros satélites (solo ISS), conflictos en tiempo real (UCDP/ACLED/ReliefWeb exigen token).
- Riesgos a verificar en el primer run: URL de cables, parámetro `from` de Digitraffic, límites de OpenSky (anónimo) y GDELT (1 petición/5 s).

## Sesión 4 — Fase 1: reparaciones (código escrito, SIN COMPILAR NI PROBAR)
Causas probables (no verificables sin red; no es seguro cuál era la real en cada caso):
- Aviones: OpenSky anónimo es lento/inestable y el cliente ocultaba la causa real (timeout/DNS/TLS) tras un mensaje genérico.
- Cerca de mí: un único servidor Overpass (saturable) y sin respaldo.
- Noticias 429: GDELT admite ~1 petición/5 s y la pantalla lanzaba una por cada chip.
Cambios:
- `core/net.dart`: `httpGet/getJson/getText` con timeout, errores específicos (`NetError`), backoff exponencial y Retry-After, caché por TTL, `throttle`.
- `world/aircraft.dart`: adsb.lol → airplanes.live → adsb.fi → OpenSky (último recurso); caché 15 s; actualización automática cada 25 s solo con la capa activa; si todos fallan se muestra cada error, sin inventar aviones.
- `tools/nearby.dart`: Overpass con 3 servidores + respaldo Nominatim; caché 10 min; timeouts 12 s; sin cargas infinitas; ignora respuestas obsoletas.
- `world/news.dart`: RSS (BBC Mundo/World, DW, ONU, Al Jazeera) con caché 10 min y carga bajo demanda; GDELT solo al pulsar el icono, con throttle 6 s, backoff y caché 15 min; filtros por categoría/idioma/palabra; fuentes y fechas visibles.
- pubspec: +xml.

## Sesión 5 — Fase 2: 6 herramientas nuevas (código escrito, SIN COMPILAR NI PROBAR)
`dns_tool.dart` (DNS-over-HTTPS Google + RDAP), `http_tool.dart` (cliente API, cabeceras de seguridad, códigos), `ssl_tool.dart` (cert. vía SecureSocket), `json_tool.dart` (JSON/XML + árbol), `palette.dart` (armonías + contraste WCAG), `astro.dart` (Open-Meteo sol/UV + fase lunar calculada). Registradas en `registry.dart` (27 herramientas + NEXUS WORLD en total).


## Sesión 6 — Fase 0 (sin Flutter ni red: NO COMPILADO)
REVISIÓN ESTÁTICA (solo lectura de código, no es compilación):
- `registry.dart:45` (coma sobrante) y `weather.dart:24` (`partly_cloudy_day_rounded`): en este ZIP NO aparecen; ya estaban corregidos en sesión 3. Si GitHub Actions sigue mostrándolos, el workflow usa un ZIP antiguo: subir ESTE ZIP.
- Comprobado por script: los 27 imports de `registry.dart` apuntan a ficheros existentes; todos los paquetes importados están en `pubspec.yaml`; `fmtNum` existe en `calculator.dart`; los iconos usados parecen existir en Flutter reciente (no verificado con el SDK).
- ESCRITO: todo. PROBADO: nada. Compilación Windows/Android: pendiente de logs de Actions.
Siguiente: subir ZIP, ejecutar Actions, enviar logs, corregir. Sin nuevas herramientas hasta compilar.

## Sesión 6b — Dependencias (NO COMPILADO)
Error CI: `image-4.11.0 png_decoder.dart:377 decodeLazy` con `archive-4.0.9`. Cambio: `pubspec.yaml` fija `image: 4.5.4` y `archive: 4.0.7` (dependencies + dependency_overrides). No existe `pubspec.lock` en el ZIP (no se puede generar sin Flutter/red). La combinación NO está verificada: si `pub get` falla por conflicto (p. ej. con `pdf`), enviar el log.

## Sesión 7 — Fase 2, lote 1 (ESCRITO, NO COMPILADO NI PROBADO)
Usuario confirma que la compilación previa (con pins image 4.5.4 / archive 4.0.7) funcionó en Actions.
Nuevos (cada uno un módulo en `lib/tools/`, registrado en `registry.dart`): `timezones.dart` (Open-Meteo), `quakes_hist.dart` (USGS FDSN; reviewed=Confirmado), `gdacs.dart` (endpoint `EVENTS4APP` NO verificado), `pwned.dart` (HIBP k-anonymity, SHA-1 local; +dep `crypto`), `fx_history.dart` (Frankfurter), `climate_hist.dart` (Open-Meteo Archive). Util: `core/spark.dart`.
Pendiente de la Fase 2: capas WORLD (rayos, asteroides, relieve, población, ferrocarril, cronología, noticias por país), monitor web, generadores, mareas, mar, comparador, mercados, calendario astro, organización personal, multimedia, Windows/Android, Home personalizable.

## Siguientes fases (NO empezadas)
Capas WORLD restantes (rayos, asteroides NASA NeoWs/Sentry, relieve, zonas horarias, población, ferrocarril Overpass, sismicidad histórica USGS), y herramientas nuevas por módulos (DNS-over-HTTPS, SSL, cabeceras HTTP, JSON/XML, colores, luna/sol, mareas, etc.).

## APIs (sin API key; límites NO verificados desde aquí, comprobar)
Open-Meteo (uso no comercial), RainViewer (radar; sus condiciones cambian: comprobar zoom/fotogramas), Overpass (cuota compartida), Frankfurter, MyMemory (cuota diaria), OSM tiles (política de uso: sin uso intensivo).

## Pendiente
- Compilar y corregir (Windows + Android) y generar instaladores.
- Tráfico: no hay fuente gratuita sin clave fiable → NO implementado.
- Valoraciones/precios de restaurantes: no existen en APIs abiertas → NO implementado (solo cocina y horario de OSM).
- Alertas oficiales (MeteoAlarm), recordatorios con notificaciones (flutter_local_notifications), calendario, notas avanzadas, escáner de documentos, editor PDF (unir/dividir), analizador WiFi (wifi_scan, solo Android), info de batería/almacenamiento (battery_plus, disk_space).
