# NEXUS_PROGRESS

## ⚠ ESTADO DE VERIFICACIÓN
En la sesión 2 NO había Flutter SDK ni red: **nada de lo nuevo está compilado ni probado**. El código se ha escrito con cuidado pero puede dar errores menores. Primer paso siguiente: `flutter pub get && flutter analyze` y corregir.

## Sesión 1 (código escrito, sin compilar)
12 herramientas originales, tema glass, SQLite, CI (`.github/workflows/build.yml`, `tool/bootstrap.sh`).

## Sesión 2 (código escrito, SIN COMPILAR NI PROBAR)
- Home rediseñada (`lib/home.dart`): cabecera con degradado, buscador, categorías, accesos rápidos (recientes), favoritos (★ o pulsación larga, guardados en SQLite), animaciones.
- `registry.dart`: nuevo campo `cat` (categoría). Las 12 herramientas previas intactas.
- `core/net.dart`: getJson con errores claros, permiso de ubicación con diálogo propio (geolocator), búsqueda de ciudad (Open-Meteo geocoding).
- `weather.dart`: previsión 48 h + 7 días (Open-Meteo), avisos CALCULADOS por umbrales (no oficiales, así se indica), radar de lluvia animado (RainViewer + OSM, flutter_map).
- `nearby.dart`: farmacias, hospitales, gasolineras, restaurantes, cafeterías, supermercados, cajeros, parkings (Overpass/OSM), lista y mapa.
- `calculator.dart` (científica, parser propio), `units.dart` (8 magnitudes + divisas Frankfurter/BCE), `timer.dart`, `tasks.dart`, `translator.dart` (MyMemory, 500 car.), `textdiff.dart`.
- pubspec: +geolocator, flutter_map, latlong2. bootstrap.sh: +permisos de ubicación Android.

## Sesión 3 (NEXUS WORLD, código escrito, SIN COMPILAR NI PROBAR)
- Corregidos errores de compilación reportados: coma sobrante en registry.dart y iconos inexistentes (weather.dart).
- `lib/world/world.dart`: mapa mundial central + capas on/off + filtro de fecha (24 h/7 d/30 d) + panel lateral (Windows/ancho) o bottom sheet (Android) + estado Confirmado/Preliminar + hora de actualización por capa.
  Capas: conflictos (editorial estático), terremotos (USGS), incendios/volcanes/inundaciones/meteo extrema (NASA EONET), calidad del aire (Open-Meteo, 30 ciudades, modelo), aviones (OpenSky anónimo, zoom ≥4), barcos (Digitraffic, SOLO Finlandia/Báltico), ISS (wheretheiss.at, con trazado), cables submarinos (submarinecablemap.com, CC BY-SA 3.0, URL no verificada).
- `lib/world/news.dart`: noticias GDELT (ES/EN/FR; Conflictos/Emergencias/Mundo; también por conflicto).
- `lib/world/data.dart`: 12 fichas de conflicto estáticas, sin cifras de víctimas ni zonas tácticas; revisar vigencia.
- NO implementado por falta de fuente gratuita fiable sin clave: radar marítimo global y puertos, rutas de vuelo, otros satélites (solo ISS), conflictos en tiempo real (UCDP/ACLED/ReliefWeb exigen token).
- Riesgos a verificar en el primer run: URL de cables, parámetro `from` de Digitraffic, límites de OpenSky (anónimo) y GDELT (1 petición/5 s).

## APIs (sin API key; límites NO verificados desde aquí, comprobar)
Open-Meteo (uso no comercial), RainViewer (radar; sus condiciones cambian: comprobar zoom/fotogramas), Overpass (cuota compartida), Frankfurter, MyMemory (cuota diaria), OSM tiles (política de uso: sin uso intensivo).

## Pendiente
- Compilar y corregir (Windows + Android) y generar instaladores.
- Tráfico: no hay fuente gratuita sin clave fiable → NO implementado.
- Valoraciones/precios de restaurantes: no existen en APIs abiertas → NO implementado (solo cocina y horario de OSM).
- Alertas oficiales (MeteoAlarm), recordatorios con notificaciones (flutter_local_notifications), calendario, notas avanzadas, escáner de documentos, editor PDF (unir/dividir), analizador WiFi (wifi_scan, solo Android), info de batería/almacenamiento (battery_plus, disk_space).
