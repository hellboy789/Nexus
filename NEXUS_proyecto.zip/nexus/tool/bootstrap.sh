#!/usr/bin/env bash
# Genera las carpetas android/ y windows/ (no versionadas) y aplica parches.
# Uso: bash tool/bootstrap.sh
set -e
flutter create --platforms=android,windows --org dev.nexus --project-name nexus --no-pub ../nexus_scaffold
cp -r ../nexus_scaffold/android ./android
cp -r ../nexus_scaffold/windows ./windows
M=android/app/src/main/AndroidManifest.xml
sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>\n    <application#' "$M"
sed -i 's#<application#<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>\n    <application#' "$M"
sed -i 's#android:label="nexus"#android:label="NEXUS"#' "$M"
sed -i 's/minSdk = flutter.minSdkVersion/minSdk = 24/; s/minSdkVersion flutter.minSdkVersion/minSdkVersion 24/' android/app/build.gradle* || true
# Bridge/Share: el cliente de NEXUS usa HTTP en la LAN (cleartext)
sed -i 's#<application#<application android:usesCleartextTraffic="true"#' "$M"
