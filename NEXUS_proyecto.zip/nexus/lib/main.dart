import 'package:flutter/material.dart';
import 'core/db.dart';
import 'core/glass.dart';
import 'home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NexusDb.init();
  themeMode.value = (await NexusDb.getSetting('theme')) == 'light' ? ThemeMode.light : ThemeMode.dark;
  runApp(const NexusApp());
}

class NexusApp extends StatelessWidget {
  const NexusApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
      valueListenable: themeMode,
      builder: (_, m, __) => MaterialApp(
            title: 'NEXUS',
            debugShowCheckedModeBanner: false,
            themeMode: m,
            theme: nexusTheme(Brightness.light),
            darkTheme: nexusTheme(Brightness.dark),
            home: const HomePage(),
          ));
}
