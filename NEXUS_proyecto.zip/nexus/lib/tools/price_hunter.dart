import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/db.dart';
import '../core/glass.dart';
import '../core/mini_charts.dart';
import '../core/net.dart';

/// PRICE HUNTER: productos (Open Food Facts) + precios reales aportados por la comunidad (Open Prices).
/// No hay API gratuita y abierta con precios en vivo de todas las tiendas: lo que no existe en la fuente se indica, no se inventa.
class PriceHunterTool extends StatefulWidget {
  const PriceHunterTool({super.key});
  @override
  State<PriceHunterTool> createState() => _PH();
}

class _Prod {
  _Prod(this.code, this.name, this.brand, this.qty, this.img);
  final String code, name, brand, qty;
  final String? img;
}

class _Offer {
  _Offer(this.store, this.city, this.country, this.price, this.currency, this.date, this.discounted, this.original);
  final String store, city, country, currency, date;
  final double price;
  final bool discounted;
  final double? original;
}

class _PH extends State<PriceHunterTool> {
  static const _kAlerts = 'ph_alerts';
  final ctl = TextEditingController();
  bool loading = false;
  String? error, info, fetchedAt;
  List<_Prod> results = [];
  _Prod? sel;
  List<_Offer> offers = [];
  List<Map<String, dynamic>> alerts = [];
  final Map<String, double?> alertNow = {};
  bool checkingAlerts = false;

  @override
  void initState() {
    super.initState();
    _loadAlerts();
  }

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  String _pricesUrl(String code) => 'https://prices.openfoodfacts.org/api/v1/prices?product_code=${Uri.encodeQueryComponent(code)}&order_by=-date&size=100';

  List<_Offer> _parse(dynamic j) {
    final out = <_Offer>[];
    final items = (j is Map ? j['items'] : null) as List? ?? [];
    for (final e in items) {
      if (e is! Map) continue;
      final price = num.tryParse('${e['price']}')?.toDouble();
      if (price == null) continue;
      final loc = e['location'] is Map ? e['location'] as Map : const {};
      out.add(_Offer('${loc['osm_name'] ?? 'Tienda sin nombre'}', '${loc['osm_address_city'] ?? ''}', '${loc['osm_address_country'] ?? ''}', price,
          '${e['currency'] ?? ''}', '${e['date'] ?? ''}', e['price_is_discounted'] == true, num.tryParse('${e['price_without_discount']}')?.toDouble()));
    }
    out.sort((a, b) => b.date.compareTo(a.date));
    return out;
  }

  Future<void> _search() async {
    final q = ctl.text.trim();
    if (q.isEmpty) return;
    setState(() {
      loading = true;
      error = null;
      info = null;
      sel = null;
      offers = [];
      results = [];
    });
    try {
      if (RegExp(r'^\d{8,14}$').hasMatch(q)) {
        await throttle('off', const Duration(milliseconds: 600));
        final j = await getJson('https://world.openfoodfacts.org/api/v2/product/$q.json?fields=code,product_name,brands,quantity,image_small_url', ttl: const Duration(hours: 6));
        final p = j is Map && j['status'] == 1 && j['product'] is Map ? j['product'] as Map : null;
        await _open(_Prod(q, '${p?['product_name'] ?? 'Código $q'}', '${p?['brands'] ?? ''}', '${p?['quantity'] ?? ''}', p?['image_small_url'] as String?), fromSearch: true);
        if (p == null) info = 'El código no figura en Open Food Facts; se muestran solo los precios registrados para ese código.';
      } else {
        await throttle('off', const Duration(milliseconds: 600));
        final j = await getJson(
            'https://world.openfoodfacts.org/cgi/search.pl?search_terms=${Uri.encodeQueryComponent(q)}&search_simple=1&action=process&json=1&page_size=25&fields=code,product_name,brands,quantity,image_small_url',
            ttl: const Duration(hours: 1),
            timeout: const Duration(seconds: 25));
        results = [
          for (final p in ((j is Map ? j['products'] : null) as List? ?? []))
            if (p is Map && '${p['code'] ?? ''}'.isNotEmpty) _Prod('${p['code']}', '${p['product_name'] ?? 'Sin nombre'}', '${p['brands'] ?? ''}', '${p['quantity'] ?? ''}', p['image_small_url'] as String?)
        ];
        if (results.isEmpty) info = 'Sin resultados en Open Food Facts (cubre sobre todo alimentación y droguería).';
      }
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _open(_Prod p, {bool fromSearch = false}) async {
    if (!fromSearch) setState(() { loading = true; error = null; });
    try {
      await throttle('openprices', const Duration(milliseconds: 700));
      final j = await getJson(_pricesUrl(p.code), ttl: const Duration(minutes: 15), timeout: const Duration(seconds: 25));
      offers = _parse(j);
      sel = p;
      fetchedAt = DateTime.now().toIso8601String().substring(0, 16).replaceAll('T', ' ');
    } catch (e) {
      error = '$e';
    }
    if (!fromSearch && mounted) setState(() => loading = false);
  }

  String get cur => offers.isEmpty ? '' : offers.first.currency;
  List<_Offer> get inCur => offers.where((o) => o.currency == cur).toList();

  List<_Offer> _latestByStore(List<_Offer> os) {
    final m = <String, _Offer>{};
    for (final o in os) {
      m.putIfAbsent('${o.store}|${o.city}', () => o);
    }
    return m.values.toList()..sort((a, b) => a.price.compareTo(b.price));
  }

  // ---- Alertas (se comprueban al abrir/actualizar; no hay segundo plano) ----
  Future<void> _loadAlerts() async {
    try {
      final s = await NexusDb.getSetting(_kAlerts);
      if (s != null) alerts = [for (final a in (jsonDecode(s) as List)) Map<String, dynamic>.from(a as Map)];
    } catch (_) {}
    if (mounted) setState(() {});
    _checkAlerts();
  }

  Future<void> _saveAlerts() => NexusDb.setSetting(_kAlerts, jsonEncode(alerts));

  Future<void> _checkAlerts() async {
    if (alerts.isEmpty) return;
    setState(() => checkingAlerts = true);
    for (final a in alerts) {
      try {
        await throttle('openprices', const Duration(milliseconds: 700));
        final j = await getJson(_pricesUrl('${a['code']}'), ttl: const Duration(minutes: 15));
        final l = _latestByStore(_parse(j).where((o) => o.currency == a['currency']).toList());
        alertNow['${a['code']}'] = l.isEmpty ? null : l.first.price;
      } catch (_) {
        alertNow['${a['code']}'] = null;
      }
    }
    if (mounted) setState(() => checkingAlerts = false);
  }

  Future<void> _addAlert() async {
    final p = sel;
    if (p == null || offers.isEmpty) return;
    final c = TextEditingController();
    final v = await showDialog<double>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('Alerta de bajada'),
              content: TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: 'Avisarme si baja de ($cur)')),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
                TextButton(onPressed: () => Navigator.pop(ctx, double.tryParse(c.text.replaceAll(',', '.'))), child: const Text('Guardar')),
              ],
            ));
    if (v == null || v <= 0) return;
    alerts.removeWhere((a) => a['code'] == p.code);
    alerts.add({'code': p.code, 'name': p.name, 'target': v, 'currency': cur});
    await _saveAlerts();
    if (mounted) setState(() {});
    _checkAlerts();
  }

  Future<void> _scan() async {
    final v = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const _ScanPage()));
    if (v != null && mounted) {
      ctl.text = v;
      _search();
    }
  }

  @override
  Widget build(BuildContext context) {
    final hint = TextStyle(color: Theme.of(context).hintColor, fontSize: 12);
    final stores = _latestByStore(inCur);
    final byDate = <String, double>{};
    for (final o in inCur) {
      final d = o.date.length >= 10 ? o.date.substring(0, 10) : o.date;
      byDate[d] = byDate.containsKey(d) ? math.min(byDate[d]!, o.price) : o.price;
    }
    final days = byDate.keys.toList()..sort();
    return GlassPage(
        title: 'PRICE HUNTER',
        maxWidth: 800,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            Expanded(
                child: TextField(
                    controller: ctl,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                    decoration: const InputDecoration(hintText: 'Nombre, marca, modelo o código de barras'))),
            if (Platform.isAndroid) IconButton(icon: const Icon(Icons.qr_code_scanner_rounded), onPressed: loading ? null : _scan),
            IconButton(icon: const Icon(Icons.search_rounded), onPressed: loading ? null : _search),
          ]),
          const SizedBox(height: 8),
          Text('Fuente: Open Food Facts (productos) y Open Prices (precios aportados por voluntarios, no en tiempo real). Cobertura sobre todo alimentación y droguería. '
              'No incluye gastos de envío ni ofertas de tiendas online.', style: hint),
          if (loading) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
          if (info != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(info!, style: hint)),
          if (alerts.isNotEmpty) ...[
            const SizedBox(height: 12),
            GlassCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Expanded(child: Text('Alertas de bajada', style: TextStyle(fontWeight: FontWeight.w800))),
                if (checkingAlerts) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) else IconButton(icon: const Icon(Icons.refresh_rounded, size: 20), onPressed: _checkAlerts),
              ]),
              for (final a in alerts)
                Builder(builder: (_) {
                  final now = alertNow['${a['code']}'];
                  final hit = now != null && now <= (a['target'] as num);
                  return Row(children: [
                    Icon(hit ? Icons.notifications_active_rounded : Icons.notifications_none_rounded, color: hit ? Colors.greenAccent : null, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Text('${a['name']} · objetivo ${(a['target'] as num).toStringAsFixed(2)} ${a['currency']} · ${now == null ? 'sin precio reciente' : 'mínimo actual ${now.toStringAsFixed(2)}'}${hit ? ' ✓ alcanzado' : ''}',
                            style: const TextStyle(fontSize: 13))),
                    IconButton(
                        icon: const Icon(Icons.close_rounded, size: 18),
                        onPressed: () async {
                          alerts.remove(a);
                          await _saveAlerts();
                          if (mounted) setState(() {});
                        }),
                  ]);
                }),
              Text('Se comprueban al abrir la herramienta o al pulsar actualizar (no hay avisos en segundo plano).', style: hint),
            ])),
          ],
          const SizedBox(height: 12),
          for (final p in results)
            GlassCard(
                onTap: () => _open(p),
                child: Row(children: [
                  if (p.img != null) Padding(padding: const EdgeInsets.only(right: 12), child: Image.network(p.img!, width: 44, height: 44, errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported_outlined))),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text([p.brand, p.qty, p.code].where((e) => e.isNotEmpty).join(' · '), style: hint),
                  ])),
                ])),
          if (sel != null) ...[
            GlassCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(sel!.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              Text([sel!.brand, sel!.qty, 'Código ${sel!.code}'].where((e) => e.isNotEmpty).join(' · '), style: hint),
              const SizedBox(height: 8),
              if (offers.isEmpty)
                const Text('No hay precios registrados para este producto en Open Prices.')
              else ...[
                Text('${stores.length} tiendas · ${inCur.length} registros en $cur · consulta $fetchedAt', style: hint),
                if (offers.length != inCur.length) Text('${offers.length - inCur.length} registros en otras monedas no se mezclan.', style: hint),
              ],
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                if (offers.isNotEmpty) GlassButton('Crear alerta', icon: Icons.add_alert_rounded, onTap: _addAlert),
                GlassButton('Buscar online (externo)', icon: Icons.open_in_new_rounded, onTap: () => launchUrl(Uri.parse('https://www.google.com/search?tbm=shop&q=${Uri.encodeQueryComponent('${sel!.brand} ${sel!.name}')}'), mode: LaunchMode.externalApplication)),
              ]),
            ])),
            if (stores.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('Precio más reciente por tienda', style: TextStyle(fontWeight: FontWeight.w800)),
              for (var i = 0; i < stores.length; i++)
                GlassCard(
                    child: Row(children: [
                  Icon(i == 0 ? Icons.emoji_events_rounded : Icons.storefront_rounded, color: i == 0 ? Colors.amberAccent : null),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(stores[i].store, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text([stores[i].city, stores[i].country, stores[i].date.length >= 10 ? stores[i].date.substring(0, 10) : stores[i].date].where((e) => e.isNotEmpty).join(' · '), style: hint),
                  ])),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text('${stores[i].price.toStringAsFixed(2)} $cur', style: const TextStyle(fontWeight: FontWeight.w800)),
                    if (stores[i].discounted) Text('Oferta${stores[i].original != null ? ' (antes ${stores[i].original!.toStringAsFixed(2)})' : ''}', style: const TextStyle(color: Colors.orangeAccent, fontSize: 12)),
                  ]),
                ])),
            ],
            if (days.length >= 2) ...[
              const SizedBox(height: 8),
              const Text('Evolución (precio más bajo registrado por fecha)', style: TextStyle(fontWeight: FontWeight.w800)),
              GlassCard(child: LineSeries([for (final d in days) byDate[d]!], first: days.first, last: days.last, unit: cur)),
            ] else if (offers.isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 8), child: Text('Evolución histórica: no hay suficientes fechas distintas en la fuente.', style: hint)),
          ],
        ]));
  }
}

class _ScanPage extends StatefulWidget {
  const _ScanPage();
  @override
  State<_ScanPage> createState() => _SP();
}

class _SP extends State<_ScanPage> {
  bool done = false;
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Escanear código de barras')),
      body: MobileScanner(onDetect: (cap) {
        final v = cap.barcodes.isEmpty ? null : cap.barcodes.first.rawValue;
        if (v != null && !done) {
          done = true;
          Navigator.pop(context, v);
        }
      }));
}
