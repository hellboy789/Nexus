import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../core/files.dart';
import '../core/glass.dart';

class PdfTool extends StatefulWidget {
  const PdfTool({super.key});
  @override
  State<PdfTool> createState() => _S();
}

class _S extends State<PdfTool> {
  List<String> images = [];
  final text = TextEditingController();
  String status = '';

  Future<void> _imgs() async {
    final doc = pw.Document();
    for (final f in images) {
      final im = pw.MemoryImage(await File(f).readAsBytes());
      doc.addPage(pw.Page(pageFormat: PdfPageFormat.a4, build: (_) => pw.Center(child: pw.Image(im, fit: pw.BoxFit.contain))));
    }
    await _save(doc, 'imagenes.pdf');
  }

  Future<void> _txt() async {
    final doc = pw.Document();
    doc.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(40), build: (_) => [pw.Paragraph(text: text.text, style: const pw.TextStyle(fontSize: 12))]));
    await _save(doc, 'texto.pdf');
  }

  Future<void> _save(pw.Document d, String name) async {
    try {
      final bytes = await d.save();
      final s = await saveBytes(name, bytes);
      setState(() => status = s == null ? 'Cancelado' : 'Guardado: $s (${fmtSize(bytes.length)})');
    } catch (e) {
      setState(() => status = 'Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 2,
      child: GlassPage(
        title: 'PDF',
        bottom: const TabBar(tabs: [Tab(text: 'Imágenes → PDF'), Tab(text: 'Texto → PDF')]),
        child: Column(children: [
          Expanded(
              child: TabBarView(children: [
            ListView(padding: const EdgeInsets.all(16), children: [
              GlassCard(child: Text(images.isEmpty ? 'Sin imágenes' : images.map((e) => e.split(RegExp(r'[\\/]')).last).join('\n'))),
              const SizedBox(height: 12),
              Wrap(spacing: 10, children: [
                GlassButton('Elegir imágenes', icon: Icons.photo_library_rounded, onTap: () async {
                  final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jpg', 'jpeg', 'png'], allowMultiple: true);
                  if (r != null) setState(() => images = r.paths.whereType<String>().toList());
                }),
                GlassButton('Crear PDF', icon: Icons.picture_as_pdf_rounded, onTap: images.isEmpty ? null : _imgs),
              ]),
            ]),
            ListView(padding: const EdgeInsets.all(16), children: [
              TextField(controller: text, minLines: 8, maxLines: 16, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Escribe o pega el texto…')),
              const SizedBox(height: 12),
              Align(alignment: Alignment.centerLeft, child: GlassButton('Crear PDF', icon: Icons.picture_as_pdf_rounded, onTap: text.text.trim().isEmpty ? null : _txt)),
            ]),
          ])),
          if (status.isNotEmpty) Padding(padding: const EdgeInsets.all(16), child: GlassCard(child: SelectableText(status))),
        ]),
      ));
}
