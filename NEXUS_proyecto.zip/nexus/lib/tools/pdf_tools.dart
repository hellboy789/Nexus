import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../core/files.dart';
import '../core/glass.dart';
import '../core/ui.dart';

/// PDF STUDIO: imágenes→PDF (orden, formato, orientación, margen, ajuste) y texto→PDF.
/// Unir/dividir PDF existentes NO está: el paquete `pdf` solo crea documentos.
class PdfTool extends StatefulWidget {
  const PdfTool({super.key});
  @override
  State<PdfTool> createState() => _S();
}

const _formats = <String, PdfPageFormat>{'A4': PdfPageFormat.a4, 'A3': PdfPageFormat.a3, 'A5': PdfPageFormat.a5, 'Carta': PdfPageFormat.letter};

class _S extends State<PdfTool> {
  List<String> images = [];
  final text = TextEditingController();
  final title = TextEditingController();
  String fmt = 'A4';
  bool landscape = false, numbers = true, cover = false;
  double margin = 24, fontSize = 12;
  String status = '';
  bool busy = false;

  PdfPageFormat get _pf => landscape ? _formats[fmt]!.landscape : _formats[fmt]!;
  String _n(String p) => p.split(RegExp(r'[\\/]')).last;

  @override
  void dispose() {
    text.dispose();
    title.dispose();
    super.dispose();
  }

  Future<void> _imgs() async {
    setState(() {
      busy = true;
      status = 'Creando PDF…';
    });
    try {
      final doc = pw.Document(title: title.text.trim().isEmpty ? null : title.text.trim());
      for (final f in images) {
        final im = pw.MemoryImage(await File(f).readAsBytes());
        doc.addPage(pw.Page(
            pageFormat: _pf,
            margin: pw.EdgeInsets.all(margin),
            build: (_) => cover ? pw.SizedBox.expand(child: pw.Image(im, fit: pw.BoxFit.cover)) : pw.Center(child: pw.Image(im, fit: pw.BoxFit.contain))));
      }
      await _save(doc, 'imagenes.pdf');
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _txt() async {
    setState(() {
      busy = true;
      status = 'Creando PDF…';
    });
    try {
      final t = title.text.trim();
      final doc = pw.Document(title: t.isEmpty ? null : t);
      doc.addPage(pw.MultiPage(
          pageFormat: _pf,
          margin: pw.EdgeInsets.all(margin + 16),
          footer: numbers ? (c) => pw.Align(alignment: pw.Alignment.centerRight, child: pw.Text('${c.pageNumber} / ${c.pagesCount}', style: const pw.TextStyle(fontSize: 9))) : null,
          build: (_) => [
                if (t.isNotEmpty) pw.Header(level: 0, child: pw.Text(t, style: pw.TextStyle(fontSize: fontSize + 8, fontWeight: pw.FontWeight.bold))),
                pw.Paragraph(text: text.text, style: pw.TextStyle(fontSize: fontSize)),
              ]));
      await _save(doc, t.isEmpty ? 'texto.pdf' : '${t.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_')}.pdf');
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _save(pw.Document d, String name) async {
    final bytes = await d.save();
    final s = await saveBytes(name, bytes);
    status = s == null ? 'Cancelado' : 'Guardado: $s (${fmtSize(bytes.length)})';
  }

  Widget _options({required bool forImages}) => GlassCard(
          child: Column(children: [
        TextField(controller: title, decoration: const InputDecoration(labelText: 'Título (opcional)')),
        const SizedBox(height: 12),
        Row(children: [
          const Text('Tamaño'),
          const SizedBox(width: 12),
          DropdownButton<String>(value: fmt, items: _formats.keys.map((k) => DropdownMenuItem(value: k, child: Text(k))).toList(), onChanged: (v) => setState(() => fmt = v ?? fmt)),
          const Spacer(),
          const Text('Horizontal'),
          Switch(value: landscape, onChanged: (v) => setState(() => landscape = v)),
        ]),
        Row(children: [const Text('Margen'), const Spacer(), Text('${margin.round()} pt')]),
        Slider(value: margin, min: 0, max: 80, onChanged: (v) => setState(() => margin = v)),
        if (forImages)
          Row(children: [const Expanded(child: Text('Rellenar la página (recorta)')), Switch(value: cover, onChanged: (v) => setState(() => cover = v))])
        else ...[
          Row(children: [const Text('Tamaño de letra'), const Spacer(), Text('${fontSize.round()} pt')]),
          Slider(value: fontSize, min: 8, max: 24, divisions: 16, onChanged: (v) => setState(() => fontSize = v)),
          Row(children: [const Expanded(child: Text('Numerar páginas')), Switch(value: numbers, onChanged: (v) => setState(() => numbers = v))]),
        ],
      ]));

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 2,
      child: GlassPage(
        title: 'PDF STUDIO',
        bottom: const TabBar(tabs: [Tab(text: 'Imágenes → PDF'), Tab(text: 'Texto → PDF')]),
        child: Column(children: [
          Expanded(
              child: TabBarView(children: [
            ListView(padding: const EdgeInsets.all(16), children: [
              if (images.isEmpty)
                const GlassCard(child: Text('Sin imágenes (JPG/PNG). Cada una será una página; puedes reordenarlas.'))
              else
                GlassCard(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: ReorderableListView(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      buildDefaultDragHandles: true,
                      onReorder: (a, b) => setState(() {
                        if (b > a) b--;
                        images.insert(b, images.removeAt(a));
                      }),
                      children: [
                        for (var i = 0; i < images.length; i++)
                          ListTile(
                              key: ValueKey('$i-${images[i]}'),
                              dense: true,
                              leading: CircleAvatar(radius: 14, child: Text('${i + 1}', style: const TextStyle(fontSize: 12))),
                              title: Text(_n(images[i]), maxLines: 1, overflow: TextOverflow.ellipsis),
                              trailing: Padding(
                                  padding: const EdgeInsets.only(right: 28),
                                  child: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => images.removeAt(i))))),
                      ],
                    )),
              const SizedBox(height: 12),
              _options(forImages: true),
              const SizedBox(height: 12),
              Wrap(spacing: 10, runSpacing: 10, children: [
                GlassButton('Añadir imágenes', icon: Icons.photo_library_rounded, onTap: () async {
                  final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jpg', 'jpeg', 'png'], allowMultiple: true);
                  if (r != null) setState(() => images = [...images, ...r.paths.whereType<String>()]);
                }),
                GlassButton('Vaciar', icon: Icons.delete_outline_rounded, onTap: images.isEmpty ? null : () async {
                  if (await confirmDlg(context, '¿Quitar todas las imágenes de la lista?', ok: 'Quitar')) setState(() => images = []);
                }),
                GlassButton('Crear PDF', icon: Icons.picture_as_pdf_rounded, onTap: (images.isEmpty || busy) ? null : _imgs),
              ]),
            ]),
            ListView(padding: const EdgeInsets.all(16), children: [
              TextField(controller: text, minLines: 8, maxLines: 16, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Escribe o pega el texto…')),
              const SizedBox(height: 12),
              _options(forImages: false),
              const SizedBox(height: 12),
              Align(alignment: Alignment.centerLeft, child: GlassButton('Crear PDF', icon: Icons.picture_as_pdf_rounded, onTap: (text.text.trim().isEmpty || busy) ? null : _txt)),
              const SizedBox(height: 8),
              const Text('Fuente estándar del PDF: caracteres latinos (á, ñ, ü…). Símbolos como € o escrituras no latinas pueden no mostrarse.', style: TextStyle(fontSize: 12)),
            ]),
          ])),
          if (status.isNotEmpty) Padding(padding: const EdgeInsets.all(16), child: GlassCard(child: SelectableText(status))),
        ]),
      ));
}
