import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/files.dart';
import '../core/glass.dart';
import '../core/store.dart';
import '../core/ui.dart';

class DropzoneTool extends StatefulWidget {
  const DropzoneTool({super.key});
  @override
  State<DropzoneTool> createState() => _S();
}

class _S extends State<DropzoneTool> {
  bool ready = false;

  @override
  void initState() {
    super.initState();
    DropStore.ensure().then((_) {
      if (mounted) setState(() => ready = true);
    });
  }

  Future<void> _files() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r == null) return;
    var n = 0;
    for (final f in r.files) {
      if (f.path == null) continue;
      try {
        await DropStore.addFile(f.path!);
        n++;
      } catch (e) {
        if (mounted) msg(context, 'No se pudo añadir ${f.name}: $e');
      }
    }
    if (mounted && n > 0) msg(context, '$n elemento(s) añadidos');
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text?.trim() ?? '';
    if (t.isEmpty) {
      if (mounted) msg(context, 'El portapapeles no tiene texto');
      return;
    }
    await DropStore.addText(t);
    if (mounted) msg(context, 'Pegado en la bandeja');
  }

  Future<void> _textDlg() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('Texto o enlace'),
              content: TextField(controller: c, autofocus: true, minLines: 2, maxLines: 8),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
                FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Añadir')),
              ],
            ));
    if (ok == true && c.text.trim().isNotEmpty) await DropStore.addText(c.text);
  }

  Future<void> _export(DropItem it) async {
    if (it.size > 200 * 1048576) {
      msg(context, 'Archivo >200 MB: no se exporta desde aquí (límite de memoria)');
      return;
    }
    try {
      final path = await saveBytes(it.title, await File(it.path!).readAsBytes());
      if (mounted && path != null) msg(context, 'Guardado');
    } catch (e) {
      if (mounted) msg(context, 'Error: $e');
    }
  }

  Future<void> _open(DropItem it) async {
    try {
      if (it.kind == 'link') {
        await launchUrl(Uri.parse(it.text!), mode: LaunchMode.externalApplication);
      } else if (it.isFile && Platform.isWindows) {
        await launchUrl(Uri.file(it.path!));
      }
    } catch (e) {
      if (mounted) msg(context, 'No se pudo abrir: $e');
    }
  }

  Future<void> _del(DropItem it) async {
    if (await confirmDlg(context, '¿Eliminar "${it.title}" de la bandeja? Se borra la copia guardada en NEXUS (no el original).')) {
      await DropStore.remove(it);
    }
  }

  IconData _icon(String k) => switch (k) {
        'image' => Icons.image_rounded,
        'link' => Icons.link_rounded,
        'text' => Icons.notes_rounded,
        _ => Icons.insert_drive_file_rounded,
      };

  Widget _tile(DropItem it) {
    final d = DateTime.fromMillisecondsSinceEpoch(it.added);
    final sub = '${it.kind == 'text' || it.kind == 'link' ? '' : '${fmtSize(it.size)} · '}${d.day}/${d.month} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    final canOpen = it.kind == 'link' || (it.isFile && Platform.isWindows);
    return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassCard(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              if (it.kind == 'image' && it.path != null)
                ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(File(it.path!), width: 48, height: 48, fit: BoxFit.cover, cacheWidth: 96, errorBuilder: (_, __, ___) => Icon(_icon(it.kind), size: 36)))
              else
                Icon(_icon(it.kind), size: 36),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(it.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text(sub, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
              ])),
              if (!it.isFile) IconButton(tooltip: 'Copiar', icon: const Icon(Icons.copy_rounded), onPressed: () => copy(context, it.text ?? '')),
              if (canOpen) IconButton(tooltip: 'Abrir', icon: const Icon(Icons.open_in_new_rounded), onPressed: () => _open(it)),
              if (it.isFile) IconButton(tooltip: 'Guardar como…', icon: const Icon(Icons.save_alt_rounded), onPressed: () => _export(it)),
              IconButton(tooltip: 'Eliminar', icon: const Icon(Icons.delete_outline_rounded), onPressed: () => _del(it)),
            ])));
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'DROPZONE',
      child: !ready
          ? const Center(child: CircularProgressIndicator())
          : ValueListenableBuilder<List<DropItem>>(
              valueListenable: DropStore.items,
              builder: (_, l, __) => ListView(padding: const EdgeInsets.all(16), children: [
                Wrap(spacing: 10, runSpacing: 10, children: [
                  GlassButton('Archivos', icon: Icons.attach_file_rounded, onTap: _files),
                  GlassButton('Pegar', icon: Icons.content_paste_rounded, onTap: _paste),
                  GlassButton('Texto / enlace', icon: Icons.edit_note_rounded, onTap: _textDlg),
                ]),
                const SizedBox(height: 8),
                Text('Los archivos se COPIAN a la bandeja de NEXUS; los originales no se modifican. Arrastrar y soltar: pendiente.',
                    style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
                const SizedBox(height: 14),
                if (l.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Bandeja vacía'))),
                for (final it in l) _tile(it),
              ])));
}
