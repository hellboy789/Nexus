import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

/// Alertas internacionales GDACS (ONU/UE). Endpoint no verificado desde el desarrollo: si falla se muestra el error real.
class GdacsTool extends StatefulWidget {
  const GdacsTool({super.key});
  @override
  State<GdacsTool> createState() => _G();
}

class _G extends State<GdacsTool> {
  bool loading = false;
  String? error, info;
  List<Map> items = [];
  static const types = {'EQ': 'Terremoto', 'TC': 'Ciclón', 'FL': 'Inundación', 'VO': 'Volcán', 'DR': 'Sequía', 'WF': 'Incendio'};

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    setState(() { loading = true; error = null; });
    try {
      final j = await getJson('https://www.gdacs.org/gdacsapi/api/events/geteventlist/EVENTS4APP', ttl: const Duration(minutes: 10), timeout: const Duration(seconds: 20));
      items = [for (final f in (j['features'] as List)) Map<String, dynamic>.from(f['properties'])];
      info = '${items.length} eventos · Fuente: GDACS · ${DateTime.now().toIso8601String().substring(0, 16)}';
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  Color _c(String? l) => switch ('$l'.toLowerCase()) { 'red' => Colors.redAccent, 'orange' => Colors.orangeAccent, _ => Colors.greenAccent };

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Alertas GDACS',
      maxWidth: 800,
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: loading ? null : _run)],
      child: ListView(padding: const EdgeInsets.all(16), children: [
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (info != null) Text(info!, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
        for (final p in items)
          GlassCard(
              child: Row(children: [
            Icon(Icons.warning_amber_rounded, color: _c('${p['alertlevel']}')),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${types['${p['eventtype']}'] ?? p['eventtype']} · ${p['name'] ?? p['country'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
              Text('${p['country'] ?? ''} · alerta ${p['alertlevel']} · ${'${p['fromdate']}'.split('T').first} · ${p['iscurrent'] == 'false' ? 'Cerrado' : 'Preliminar (en curso)'}', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
              if ((p['severitydata'] is Map) && p['severitydata']['severitytext'] != null) Text('${p['severitydata']['severitytext']}', style: const TextStyle(fontSize: 12)),
            ])),
          ])),
      ]));
}
