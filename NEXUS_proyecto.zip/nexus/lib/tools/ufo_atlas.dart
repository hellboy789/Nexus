import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/files.dart';
import '../core/glass.dart';
import '../core/mini_charts.dart';
import '../core/net.dart';

/// UFO ATLAS. Testimonios: dataset público derivado de NUFORC (planetsig/ufo-reports, geocodificado).
/// Registros oficiales: NO se incluye ninguno por defecto (no hay fuente verificada integrada); se pueden importar desde CSV
/// (columnas: date, lat, lon, country, category, description, source) y quedan marcados como "Oficial (importado)".
/// Un avistamiento NO es prueba de origen extraterrestre.
const _nuforcUrl = 'https://raw.githubusercontent.com/planetsig/ufo-reports/master/csv-data/ufo-scrubbed-geocoded-time-standardized.csv';

class UfoRec {
  UfoRec(this.date, this.year, this.lat, this.lon, this.country, this.cat, this.place, this.text, this.official, this.src);
  final String date, country, cat, place, text, src;
  final int year;
  final double lat, lon;
  final bool official;
}

List<List<String>> _csv(String s) {
  final rows = <List<String>>[];
  var row = <String>[];
  final sb = StringBuffer();
  var q = false;
  final n = s.length;
  for (var i = 0; i < n; i++) {
    final c = s.codeUnitAt(i);
    if (q) {
      if (c == 34) {
        if (i + 1 < n && s.codeUnitAt(i + 1) == 34) {
          sb.writeCharCode(34);
          i++;
        } else {
          q = false;
        }
      } else {
        sb.writeCharCode(c);
      }
    } else if (c == 34) {
      q = true;
    } else if (c == 44) {
      row.add(sb.toString());
      sb.clear();
    } else if (c == 10 || c == 13) {
      if (c == 13 && i + 1 < n && s.codeUnitAt(i + 1) == 10) i++;
      row.add(sb.toString());
      sb.clear();
      if (row.length > 1 || row[0].isNotEmpty) rows.add(row);
      row = <String>[];
    } else {
      sb.writeCharCode(c);
    }
  }
  if (sb.isNotEmpty || row.isNotEmpty) {
    row.add(sb.toString());
    rows.add(row);
  }
  return rows;
}

(String, int)? _date(String raw) {
  final t = raw.trim().split(' ').first;
  int? y, m, d;
  if (t.contains('/')) {
    final p = t.split('/');
    if (p.length != 3) return null;
    m = int.tryParse(p[0]);
    d = int.tryParse(p[1]);
    y = int.tryParse(p[2]);
  } else if (t.contains('-')) {
    final p = t.split('-');
    if (p.length < 3) return null;
    y = int.tryParse(p[0]);
    m = int.tryParse(p[1]);
    d = int.tryParse(p[2]);
  }
  if (y == null || m == null || d == null || y < 1000 || m < 1 || m > 12) return null;
  return ('$y-${m.toString().padLeft(2, '0')}-${d.toString().padLeft(2, '0')}', y);
}

String _clean(String s) => s
    // Con ';' el código puede tener varios dígitos (&#8217;). Sin ';' el dataset usa códigos de 2 dígitos (&#44 &#39 &#33) pegados al texto (&#44000 = ", 000"... "&#44"+"000").
    .replaceAllMapped(RegExp(r'&#(\d{1,7});|&#(\d{2})'), (m) {
      final n = int.tryParse(m[1] ?? m[2]!);
      return n == null || n > 0x10FFFF || (n >= 0xD800 && n <= 0xDFFF) ? '' : String.fromCharCode(n);
    })
    .replaceAll('&quot;', '"')
    .replaceAll('&amp;', '&')
    .trim();

/// Comprueba que el texto es un CSV y no HTML/JSON/Git LFS. Lanza FormatException con mensaje claro.
void checkNuforcText(String s) {
  final t = s.trimLeft();
  final head = (t.length > 400 ? t.substring(0, 400) : t).toLowerCase();
  if (t.isEmpty) throw const FormatException('NUFORC: la descarga está vacía.');
  if (head.startsWith('<!doctype') || head.startsWith('<html') || head.contains('<head') || head.contains('<body')) {
    throw const FormatException('NUFORC devolvió una página HTML en vez del CSV (posible bloqueo, redirección o error del servidor).');
  }
  if (head.startsWith('{') || head.startsWith('[')) throw const FormatException('NUFORC devolvió JSON en vez de un CSV (posible mensaje de error de la fuente).');
  if (head.startsWith('version https://git-lfs')) throw const FormatException('La fuente devolvió un puntero Git LFS, no el CSV real.');
}

/// Formato REAL de ufo-scrubbed-geocoded-time-standardized.csv (planetsig/ufo-reports), comprobado sobre el fichero:
/// SIN fila de encabezado, delimitador ',', comillas '"', UTF-8/ASCII, 11 columnas por fila, en este orden fijo:
/// 0 datetime (M/D/AAAA HH:MM) · 1 city · 2 state · 3 country · 4 shape · 5 duration(s) · 6 duration(texto) ·
/// 7 comments · 8 date posted · 9 latitude · 10 longitude.
/// Si en el futuro la fuente trae encabezado con nombres, se usan por nombre (datetime/city/state/country/shape/comments/latitude/longitude).
List<UfoRec> parseNuforc(String s) {
  if (s.startsWith('\uFEFF')) s = s.substring(1);
  checkNuforcText(s);
  final rows = _csv(s);
  if (rows.isEmpty) throw const FormatException('NUFORC: el CSV no contiene filas.');
  var iD = 0, iC = 1, iS = 2, iK = 3, iH = 4, iT = 7, iLa = 9, iLo = 10;
  var start = 0;
  final first = rows.first;
  final hasDataFirst = first.length >= 11 && _date(first[0]) != null && double.tryParse(first[9].trim()) != null;
  if (!hasDataFirst) {
    // Posible encabezado con nombres.
    final h = [for (final x in first) x.trim().toLowerCase()];
    int ix(String n) => h.indexWhere((e) => e.startsWith(n));
    iD = ix('datetime');
    if (iD < 0) iD = ix('date');
    iC = ix('city');
    iS = ix('state');
    iK = ix('country');
    iH = ix('shape');
    iT = ix('comments');
    iLa = ix('latitude');
    iLo = ix('longitude');
    if (iD < 0 || iLa < 0 || iLo < 0) {
      final preview = first.take(11).map((e) => e.length > 25 ? '${e.substring(0, 25)}…' : e).join(' | ');
      throw FormatException('El dataset NUFORC no tiene el formato esperado (sin encabezado: 11 columnas con fecha en la 1ª y latitud/longitud en la 10ª/11ª; con encabezado: datetime, latitude, longitude). Primera fila recibida (${first.length} columnas): $preview');
    }
    start = 1;
  }
  String g(List<String> w, int i) => i >= 0 && i < w.length ? w[i].trim() : '';
  final need = math.max(iLo, iLa) + 1;
  final out = <UfoRec>[];
  for (var r = start; r < rows.length; r++) {
    final w = rows[r];
    if (w.length < need) continue;
    final la = double.tryParse(g(w, iLa)), lo = double.tryParse(g(w, iLo));
    if (la == null || lo == null || la.abs() > 90 || lo.abs() > 180) continue;
    final d = _date(g(w, iD));
    if (d == null) continue;
    final shape = g(w, iH).toLowerCase();
    final place = [g(w, iC), g(w, iS).toUpperCase()].where((e) => e.isNotEmpty).join(', ');
    out.add(UfoRec(d.$1, d.$2, la, lo, g(w, iK).toLowerCase(), shape.isEmpty ? 'desconocida' : shape, place, _clean(g(w, iT)), false, 'NUFORC'));
  }
  if (out.isEmpty) throw FormatException('NUFORC: se leyeron ${rows.length} filas pero ninguna tiene fecha y coordenadas válidas.');
  return out;
}

List<UfoRec> parseOfficial(String s) {
  final rows = _csv(s);
  if (rows.isEmpty) return [];
  final h = [for (final x in rows.first) x.trim().toLowerCase()];
  final iD = h.indexOf('date'), iLa = h.indexOf('lat'), iLo = h.indexOf('lon'), iK = h.indexOf('country'), iC = h.indexOf('category'), iT = h.indexOf('description'), iS = h.indexOf('source');
  if (iD < 0 || iLa < 0 || iLo < 0) throw const FormatException('Faltan columnas obligatorias: date, lat, lon.');
  String g(List<String> w, int i) => i >= 0 && i < w.length ? w[i].trim() : '';
  final out = <UfoRec>[];
  for (var r = 1; r < rows.length; r++) {
    final w = rows[r];
    final la = double.tryParse(g(w, iLa)), lo = double.tryParse(g(w, iLo));
    final d = _date(g(w, iD));
    if (la == null || lo == null || d == null || la.abs() > 90 || lo.abs() > 180) continue;
    final c = g(w, iC).toLowerCase();
    out.add(UfoRec(d.$1, d.$2, la, lo, g(w, iK).toLowerCase(), c.isEmpty ? 'desconocida' : c, '', g(w, iT), true, g(w, iS)));
  }
  return out;
}

const _countryNames = {'us': 'EE. UU.', 'ca': 'Canadá', 'gb': 'Reino Unido', 'au': 'Australia', 'de': 'Alemania'};
String _cn(String c) => c.isEmpty ? 'Sin país' : (_countryNames[c] ?? c.toUpperCase());

class UfoAtlasTool extends StatefulWidget {
  const UfoAtlasTool({super.key});
  @override
  State<UfoAtlasTool> createState() => _UA();
}

class _Cl {
  double lat = 0, lon = 0;
  int n = 0, off = 0;
  UfoRec? one;
}

class _UA extends State<UfoAtlasTool> {
  final map = MapController();
  bool loading = false;
  String stage = '', type = 'all', country = '', shape = '';
  String? error, warn, updated;
  List<UfoRec> all = [], view = [];
  int yMin = 1900, yMax = DateTime.now().year;
  RangeValues yr = RangeValues(1900, DateTime.now().year.toDouble());
  double zoom = 2;
  List<MapEntry<String, int>> countries = [], shapes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<File> _f(String n) async => File('${(await getApplicationSupportDirectory()).path}/$n');

  Future<void> _load({bool force = false}) async {
    setState(() { loading = true; error = null; warn = null; stage = 'Preparando…'; });
    try {
      final f = await _f('ufo_nuforc.csv');
      final fresh = f.existsSync() && DateTime.now().difference(f.lastModifiedSync()) < const Duration(days: 30);
      if (force || !fresh) {
        try {
          setState(() => stage = 'Descargando dataset NUFORC (varios MB)…');
          final r = await httpGet(_nuforcUrl, timeout: const Duration(seconds: 150), retries: 1);
          checkNuforcText(utf8.decode(r.bodyBytes.length > 2000 ? r.bodyBytes.sublist(0, 2000) : r.bodyBytes, allowMalformed: true));
          await f.writeAsBytes(r.bodyBytes);
        } catch (e) {
          if (!f.existsSync()) rethrow;
          warn = 'No se pudo actualizar ($e). Usando la copia local.';
        }
      }
      setState(() => stage = 'Procesando registros…');
      List<UfoRec> nuf;
      try {
        nuf = await compute(parseNuforc, utf8.decode(await f.readAsBytes(), allowMalformed: true));
      } catch (_) {
        if (f.existsSync()) await f.delete(); // copia local inválida (p. ej. HTML guardado por la versión anterior): no reutilizar
        rethrow;
      }
      updated = f.lastModifiedSync().toIso8601String().substring(0, 10);
      final of = await _f('ufo_official.csv');
      final off = of.existsSync() ? await compute(parseOfficial, utf8.decode(await of.readAsBytes(), allowMalformed: true)) : <UfoRec>[];
      all = [...nuf, ...off];
      if (all.isEmpty) throw const FormatException('El dataset no contiene registros válidos.');
      final ys = all.map((e) => e.year).where((y) => y >= 1900 && y <= DateTime.now().year);
      yMin = ys.reduce(math.min);
      yMax = ys.reduce(math.max);
      yr = RangeValues(yMin.toDouble(), yMax.toDouble());
      final cc = <String, int>{}, ss = <String, int>{};
      for (final e in all) {
        cc[e.country] = (cc[e.country] ?? 0) + 1;
        ss[e.cat] = (ss[e.cat] ?? 0) + 1;
      }
      countries = (cc.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(40).toList();
      shapes = (ss.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(40).toList();
      _apply();
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _import() async {
    final p = await pickPath(ext: ['csv']);
    if (p == null) return;
    try {
      final txt = utf8.decode(await File(p).readAsBytes(), allowMalformed: true);
      final recs = await compute(parseOfficial, txt);
      if (recs.isEmpty) throw const FormatException('El CSV no contiene filas válidas.');
      await (await _f('ufo_official.csv')).writeAsString(txt);
      await _load();
    } catch (e) {
      if (mounted) setState(() => error = 'Importación fallida: $e');
    }
  }

  void _apply() {
    view = all.where((e) => e.year >= yr.start && e.year <= yr.end && (country.isEmpty || e.country == country) && (shape.isEmpty || e.cat == shape) && (type == 'all' || (type == 'off') == e.official)).toList();
  }

  List<_Cl> _cluster() {
    var cell = math.max(40 / math.pow(2, zoom), 0.005).toDouble();
    Map<String, _Cl> g;
    do {
      g = {};
      for (final e in view) {
        final k = '${(e.lat / cell).floor()}|${(e.lon / cell).floor()}';
        final c = g.putIfAbsent(k, () => _Cl());
        c.lat += e.lat;
        c.lon += e.lon;
        c.n++;
        if (e.official) c.off++;
        c.one = e;
      }
      if (g.length > 1500) cell *= 2;
    } while (g.length > 1500);
    for (final c in g.values) {
      c.lat /= c.n;
      c.lon /= c.n;
    }
    return g.values.toList();
  }

  void _detail(UfoRec e) => showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(e.official ? 'Registro oficial (importado)' : 'Testimonio sin verificar', style: TextStyle(fontWeight: FontWeight.w800, color: e.official ? Colors.amber : Colors.cyan)),
            const SizedBox(height: 6),
            Text('${e.date} · ${e.place.isEmpty ? _cn(e.country) : '${e.place} (${_cn(e.country)})'}'),
            Text('Categoría (forma/tipo informado): ${e.cat}'),
            const SizedBox(height: 8),
            Text(e.text.isEmpty ? 'Sin descripción.' : e.text),
            const SizedBox(height: 8),
            Text('Fuente: ${e.official ? (e.src.isEmpty ? 'no indicada en el CSV' : e.src) : 'NUFORC (dataset planetsig/ufo-reports)'}', style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              if (!e.official) TextButton(onPressed: () => launchUrl(Uri.parse('https://nuforc.org'), mode: LaunchMode.externalApplication), child: const Text('Abrir NUFORC')),
              if (e.official && e.src.startsWith('http')) TextButton(onPressed: () => launchUrl(Uri.parse(e.src), mode: LaunchMode.externalApplication), child: const Text('Abrir fuente')),
            ]),
            const Text('Un avistamiento no constituye prueba de origen extraterrestre.', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
          ]))));

  Widget _filters() {
    final hint = TextStyle(color: Theme.of(context).hintColor, fontSize: 12);
    return Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
        child: Column(children: [
          Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
            DropdownButton<String>(
                value: country,
                items: [const DropdownMenuItem(value: '', child: Text('Todos los países')), for (final c in countries) DropdownMenuItem(value: c.key, child: Text('${_cn(c.key)} (${c.value})'))],
                onChanged: (v) => setState(() { country = v ?? ''; _apply(); })),
            DropdownButton<String>(
                value: shape,
                items: [const DropdownMenuItem(value: '', child: Text('Todas las categorías')), for (final c in shapes) DropdownMenuItem(value: c.key, child: Text('${c.key} (${c.value})'))],
                onChanged: (v) => setState(() { shape = v ?? ''; _apply(); })),
            SegmentedButton<String>(
                showSelectedIcon: false,
                segments: const [ButtonSegment(value: 'all', label: Text('Todos')), ButtonSegment(value: 'test', label: Text('Testimonios')), ButtonSegment(value: 'off', label: Text('Oficiales'))],
                selected: {type},
                onSelectionChanged: (s) => setState(() { type = s.first; _apply(); })),
          ]),
          Row(children: [
            Text('${yr.start.round()}', style: hint),
            Expanded(
                child: RangeSlider(
                    min: yMin.toDouble(),
                    max: math.max(yMax, yMin + 1).toDouble(),
                    values: yr,
                    onChanged: (v) => setState(() => yr = v),
                    onChangeEnd: (_) => setState(_apply))),
            Text('${yr.end.round()}', style: hint),
          ]),
          Text('${view.length} de ${all.length} reportes con los filtros actuales', style: hint),
        ]));
  }

  Widget _map() {
    final cl = _cluster();
    return FlutterMap(
        mapController: map,
        options: MapOptions(
            initialCenter: const LatLng(30, 0),
            initialZoom: 2,
            minZoom: 1,
            maxZoom: 17,
            onPositionChanged: (cam, _) {
              if ((cam.zoom - zoom).abs() >= .5) WidgetsBinding.instance.addPostFrameCallback((_) => mounted ? setState(() => zoom = cam.zoom) : null);
            }),
        children: [
          TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'dev.nexus.nexus'),
          MarkerLayer(markers: [
            for (final c in cl)
              Marker(
                  point: LatLng(c.lat, c.lon),
                  width: c.n == 1 ? 22 : 44,
                  height: c.n == 1 ? 22 : 44,
                  child: GestureDetector(
                      onTap: () => c.n == 1 ? _detail(c.one!) : map.move(LatLng(c.lat, c.lon), math.min(zoom + 2.5, 17)),
                      child: Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: (c.off > 0 ? Colors.amber : (c.n > 100 ? Colors.deepPurpleAccent : c.n > 10 ? Colors.indigoAccent : Colors.cyan)).withOpacity(.8),
                              border: Border.all(color: Colors.white, width: 1.5)),
                          child: c.n == 1 ? null : Text('${c.n}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))))),
          ]),
        ]);
  }

  Widget _charts() {
    final byYear = <int, int>{}, byShape = <String, int>{}, byCountry = <String, int>{}, byPlace = <String, int>{};
    for (final e in view) {
      byYear[e.year] = (byYear[e.year] ?? 0) + 1;
      byShape[e.cat] = (byShape[e.cat] ?? 0) + 1;
      byCountry[_cn(e.country)] = (byCountry[_cn(e.country)] ?? 0) + 1;
      if (e.place.isNotEmpty) byPlace['${e.place} ${e.country.toUpperCase()}'] = (byPlace['${e.place} ${e.country.toUpperCase()}'] ?? 0) + 1;
    }
    List<MapEntry<String, num>> top(Map<String, int> m) => (m.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(10).map((e) => MapEntry<String, num>(e.key, e.value)).toList();
    if (view.isEmpty) return const Center(child: Text('Sin reportes con los filtros actuales.'));
    final y0 = byYear.keys.reduce(math.min), y1 = byYear.keys.reduce(math.max);
    return ListView(padding: const EdgeInsets.all(12), children: [
      const Text('Reportes por año', style: TextStyle(fontWeight: FontWeight.w800)),
      GlassCard(child: Columns([for (var y = y0; y <= y1; y++) byYear[y] ?? 0], first: '$y0', last: '$y1')),
      const SizedBox(height: 8),
      const Text('Categorías', style: TextStyle(fontWeight: FontWeight.w800)),
      GlassCard(child: HBars(top(byShape))),
      const SizedBox(height: 8),
      const Text('Países', style: TextStyle(fontWeight: FontWeight.w800)),
      GlassCard(child: HBars(top(byCountry), color: Colors.indigoAccent)),
      const SizedBox(height: 8),
      const Text('Zonas con más reportes (concentración)', style: TextStyle(fontWeight: FontWeight.w800)),
      GlassCard(child: HBars(top(byPlace), color: Colors.deepPurpleAccent)),
      Padding(padding: const EdgeInsets.all(8), child: Text('Sesgo: NUFORC es una base estadounidense; más reportes en una zona refleja también más población y más difusión de la base, no más actividad real.', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12))),
    ]);
  }

  Widget _sources() => ListView(padding: const EdgeInsets.all(12), children: [
        GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Testimonios', style: TextStyle(fontWeight: FontWeight.w800)),
          const Text('Reportes ciudadanos recogidos por NUFORC (National UFO Reporting Center), en el dataset público geocodificado planetsig/ufo-reports. No están verificados ni investigados.'),
          Text('Última descarga: ${updated ?? '—'}', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
          Wrap(spacing: 8, children: [
            TextButton(onPressed: () => launchUrl(Uri.parse('https://nuforc.org'), mode: LaunchMode.externalApplication), child: const Text('NUFORC')),
            TextButton(onPressed: () => launchUrl(Uri.parse('https://github.com/planetsig/ufo-reports'), mode: LaunchMode.externalApplication), child: const Text('Dataset')),
          ]),
        ])),
        GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Registros oficiales', style: TextStyle(fontWeight: FontWeight.w800)),
          Text('Ninguno incluido por defecto. Puedes importar un CSV (columnas: date, lat, lon, country, category, description, source), p. ej. de Project Blue Book o AARO; se marcan como "Oficial (importado)" y la fuente es la que indiques. Registros importados: ${all.where((e) => e.official).length}.'),
          const SizedBox(height: 8),
          GlassButton('Importar CSV oficial', icon: Icons.upload_file_rounded, onTap: loading ? null : _import),
        ])),
        const GlassCard(child: Text('Aviso: un avistamiento es un objeto o fenómeno no identificado por quien lo reporta. Las causas habituales son aviones, satélites, globos, planetas o fenómenos atmosféricos. No son pruebas de vida extraterrestre.')),
      ]);

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 3,
      child: GlassPage(
          title: 'UFO ATLAS',
          maxWidth: 1100,
          actions: [IconButton(tooltip: 'Actualizar dataset', icon: const Icon(Icons.refresh_rounded), onPressed: loading ? null : () => _load(force: true))],
          bottom: const TabBar(tabs: [Tab(text: 'Mapa'), Tab(text: 'Gráficos'), Tab(text: 'Fuentes')]),
          child: loading
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const CircularProgressIndicator(), const SizedBox(height: 12), Text(stage)]))
              : error != null
                  ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(error!, style: const TextStyle(color: Colors.redAccent)), const SizedBox(height: 12), GlassButton('Reintentar', icon: Icons.refresh_rounded, onTap: () => _load(force: true))])))
                  : Column(children: [
                      const Padding(padding: EdgeInsets.fromLTRB(12, 4, 12, 0), child: Text('Testimonios y registros no verificados; no son pruebas extraterrestres.', style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic))),
                      if (warn != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text(warn!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 12))),
                      _filters(),
                      Expanded(child: TabBarView(physics: const NeverScrollableScrollPhysics(), children: [_map(), _charts(), _sources()])),
                    ])));
}
