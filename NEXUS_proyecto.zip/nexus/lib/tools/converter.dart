import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import '../core/files.dart';
import '../core/glass.dart';

List<List<String>> parseCsv(String s) {
  final rows = <List<String>>[];
  var row = <String>[];
  var f = StringBuffer();
  var q = false;
  for (var i = 0; i < s.length; i++) {
    final c = s[i];
    if (q) {
      if (c == '"') {
        if (i + 1 < s.length && s[i + 1] == '"') {
          f.write('"');
          i++;
        } else {
          q = false;
        }
      } else {
        f.write(c);
      }
    } else if (c == '"') {
      q = true;
    } else if (c == ',') {
      row.add(f.toString());
      f = StringBuffer();
    } else if (c == '\n') {
      row.add(f.toString());
      f = StringBuffer();
      rows.add(row);
      row = [];
    } else if (c != '\r') {
      f.write(c);
    }
  }
  if (f.isNotEmpty || row.isNotEmpty) {
    row.add(f.toString());
    rows.add(row);
  }
  return rows;
}

String _esc(String v) => (v.contains(',') || v.contains('"') || v.contains('\n')) ? '"${v.replaceAll('"', '""')}"' : v;

class ConverterTool extends StatefulWidget {
  const ConverterTool({super.key});
  @override
  State<ConverterTool> createState() => _S();
}

class _S extends State<ConverterTool> {
  static const modes = ['Imagen → PNG', 'Imagen → JPG', 'Imagen → BMP', 'Imagen → GIF', 'JSON → CSV', 'CSV → JSON'];
  String mode = modes.first;
  String? path;
  String status = '';

  Future<void> _convert() async {
    if (path == null) return;
    try {
      final bytes = await File(path!).readAsBytes();
      final base = p.basenameWithoutExtension(path!);
      late Uint8List out;
      late String name;
      if (mode.startsWith('Imagen')) {
        final im = img.decodeImage(bytes);
        if (im == null) throw 'Formato de imagen no soportado';
        final ext = mode.split('→').last.trim().toLowerCase();
        out = Uint8List.fromList(switch (ext) {
          'png' => img.encodePng(im),
          'jpg' => img.encodeJpg(im, quality: 92),
          'bmp' => img.encodeBmp(im),
          _ => img.encodeGif(im),
        });
        name = '$base.$ext';
      } else if (mode == 'JSON → CSV') {
        final data = jsonDecode(utf8.decode(bytes));
        if (data is! List || data.any((e) => e is! Map)) throw 'El JSON debe ser una lista de objetos';
        final keys = <String>{};
        for (final m in data) {
          keys.addAll((m as Map).keys.map((k) => '$k'));
        }
        final sb = StringBuffer()..writeln(keys.map(_esc).join(','));
        for (final m in data) {
          sb.writeln(keys.map((k) => _esc('${(m as Map)[k] ?? ''}')).join(','));
        }
        out = Uint8List.fromList(utf8.encode(sb.toString()));
        name = '$base.csv';
      } else {
        final rows = parseCsv(utf8.decode(bytes));
        if (rows.isEmpty) throw 'CSV vacío';
        final h = rows.first;
        final list = rows.skip(1).map((r) => {for (var i = 0; i < h.length; i++) h[i]: i < r.length ? r[i] : ''}).toList();
        out = Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(list)));
        name = '$base.json';
      }
      final saved = await saveBytes(name, out);
      setState(() => status = saved == null ? 'Cancelado' : 'Guardado: $saved (${fmtSize(out.length)})');
    } catch (e) {
      setState(() => status = 'Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Conversor',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          DropdownButtonFormField<String>(
              value: mode,
              decoration: const InputDecoration(),
              items: modes.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
              onChanged: (v) => setState(() => mode = v!)),
          const SizedBox(height: 12),
          GlassCard(child: Text(path ?? 'Ningún archivo seleccionado')),
          const SizedBox(height: 12),
          Wrap(spacing: 10, children: [
            GlassButton('Elegir archivo', icon: Icons.folder_open_rounded, onTap: () async {
              final f = await pickPath();
              if (f != null) setState(() => path = f);
            }),
            GlassButton('Convertir', icon: Icons.swap_horiz_rounded, onTap: path == null ? null : _convert),
          ]),
          const SizedBox(height: 16),
          if (status.isNotEmpty) GlassCard(child: SelectableText(status)),
        ]),
      );
}
