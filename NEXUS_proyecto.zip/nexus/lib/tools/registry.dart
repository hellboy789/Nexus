import 'package:flutter/material.dart';
import 'device_info.dart';
import 'notes.dart';
import 'speedtest.dart';
import 'benchmark.dart';
import 'qr.dart';
import 'links.dart';
import 'media.dart';
import 'converter.dart';
import 'compressor.dart';
import 'pdf_tools.dart';
import 'passwords.dart';
import 'netanalyzer.dart';

class NexusTool {
  const NexusTool(this.id, this.name, this.desc, this.icon, this.color, this.builder);
  final String id, name, desc;
  final IconData icon;
  final Color color;
  final WidgetBuilder builder;
}

/// Para añadir una herramienta: crea su widget en lib/tools y regístrala aquí.
final nexusTools = <NexusTool>[
  NexusTool('device', 'Dispositivo', 'Hardware y sistema', Icons.memory_rounded, const Color(0xFF6C7BFF), (_) => const DeviceInfoTool()),
  NexusTool('notes', 'Notas', 'Guardadas en SQLite', Icons.sticky_note_2_rounded, const Color(0xFFFFB84D), (_) => const NotesTool()),
  NexusTool('speed', 'Velocidad', 'Test de Internet', Icons.speed_rounded, const Color(0xFF3DDCFF), (_) => const SpeedTestTool()),
  NexusTool('bench', 'Benchmark', 'CPU, RAM, disco', Icons.analytics_rounded, const Color(0xFFFF6B6B), (_) => const BenchmarkTool()),
  NexusTool('qr', 'QR', 'Generar y leer', Icons.qr_code_2_rounded, const Color(0xFF8E7CFF), (_) => const QrTool()),
  NexusTool('links', 'Enlaces', 'TikTok, Instagram, YouTube', Icons.link_rounded, const Color(0xFFFF6CCB), (_) => const LinksTool()),
  NexusTool('media', 'Multimedia', 'MP3 / MP4', Icons.movie_filter_rounded, const Color(0xFF4DD99A), (_) => const MediaTool()),
  NexusTool('convert', 'Conversor', 'Imágenes, JSON, CSV', Icons.swap_horiz_rounded, const Color(0xFF5AA9FF), (_) => const ConverterTool()),
  NexusTool('compress', 'Comprimir', 'Imágenes', Icons.compress_rounded, const Color(0xFFFFA05A), (_) => const CompressorTool()),
  NexusTool('pdf', 'PDF', 'Imágenes y texto a PDF', Icons.picture_as_pdf_rounded, const Color(0xFFE5484D), (_) => const PdfTool()),
  NexusTool('pass', 'Contraseñas', 'Generador seguro', Icons.password_rounded, const Color(0xFF7BD88F), (_) => const PasswordTool()),
  NexusTool('net', 'Red', 'DNS, ping, puertos', Icons.lan_rounded, const Color(0xFF47C1BF), (_) => const NetAnalyzerTool()),
];
