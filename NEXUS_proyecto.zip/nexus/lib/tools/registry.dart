import 'package:flutter/material.dart';
import 'device_info.dart';
import 'notes.dart';
import 'speedtest.dart';
import 'benchmark.dart';
import 'qr.dart';
import 'links.dart';
import 'media.dart';
import 'converter.dart';
import 'compressor.dart';
import 'pdf_tools.dart';
import 'passwords.dart';
import 'netanalyzer.dart';
import 'weather.dart';
import 'nearby.dart';
import 'calculator.dart';
import 'units.dart';
import 'timer.dart';
import 'textdiff.dart';
import 'translator.dart';
import 'tasks.dart';
import '../world/world.dart';

class NexusTool {
  const NexusTool(this.id, this.name, this.desc, this.icon, this.color, this.builder, {this.cat = 'Sistema'});
  final String id, name, desc, cat;
  final IconData icon;
  final Color color;
  final WidgetBuilder builder;
}

/// Para añadir una herramienta: crea su widget en lib/tools y regístrala aquí.
final nexusTools = <NexusTool>[
  NexusTool('device', 'Dispositivo', 'Hardware y sistema', Icons.memory_rounded, const Color(0xFF6C7BFF), (_) => const DeviceInfoTool(), cat: 'Sistema'),
  NexusTool('notes', 'Notas', 'Guardadas en SQLite', Icons.sticky_note_2_rounded, const Color(0xFFFFB84D), (_) => const NotesTool(), cat: 'Productividad'),
  NexusTool('speed', 'Velocidad', 'Test de Internet', Icons.speed_rounded, const Color(0xFF3DDCFF), (_) => const SpeedTestTool(), cat: 'Sistema'),
  NexusTool('bench', 'Benchmark', 'CPU, RAM, disco', Icons.analytics_rounded, const Color(0xFFFF6B6B), (_) => const BenchmarkTool(), cat: 'Sistema'),
  NexusTool('qr', 'QR', 'Generar y leer', Icons.qr_code_2_rounded, const Color(0xFF8E7CFF), (_) => const QrTool(), cat: 'Sistema'),
  NexusTool('links', 'Enlaces', 'TikTok, Instagram, YouTube', Icons.link_rounded, const Color(0xFFFF6CCB), (_) => const LinksTool(), cat: 'Otras'),
  NexusTool('media', 'Multimedia', 'MP3 / MP4', Icons.movie_filter_rounded, const Color(0xFF4DD99A), (_) => const MediaTool(), cat: 'Otras'),
  NexusTool('convert', 'Conversor', 'Imágenes, JSON, CSV', Icons.swap_horiz_rounded, const Color(0xFF5AA9FF), (_) => const ConverterTool(), cat: 'Sistema'),
  NexusTool('compress', 'Comprimir', 'Imágenes', Icons.compress_rounded, const Color(0xFFFFA05A), (_) => const CompressorTool(), cat: 'Sistema'),
  NexusTool('pdf', 'PDF', 'Imágenes y texto a PDF', Icons.picture_as_pdf_rounded, const Color(0xFFE5484D), (_) => const PdfTool(), cat: 'Productividad'),
  NexusTool('pass', 'Contraseñas', 'Generador seguro', Icons.password_rounded, const Color(0xFF7BD88F), (_) => const PasswordTool(), cat: 'Sistema'),
  NexusTool('net', 'Red', 'DNS, ping, puertos', Icons.lan_rounded, const Color(0xFF47C1BF), (_) => const NetAnalyzerTool(), cat: 'Sistema'),
  NexusTool('weather', 'Clima y radar', 'Previsión, radar, avisos', Icons.thunderstorm_rounded, const Color(0xFF3DA5FF), (_) => const WeatherTool(), cat: 'Clima y mapas'),
  NexusTool('nearby', 'Cerca de mí', 'Farmacias, comida, gasolineras', Icons.place_rounded, const Color(0xFFFF7A59), (_) => const NearbyTool(), cat: 'Clima y mapas'),
  NexusTool('calc', 'Calculadora', 'Científica con historial', Icons.calculate_rounded, const Color(0xFF9B7BFF), (_) => const CalculatorTool(), cat: 'Productividad'),
  NexusTool('units', 'Unidades y divisas', 'Conversión + tipos de cambio', Icons.currency_exchange_rounded, const Color(0xFF2FC4A0), (_) => const UnitsTool(), cat: 'Productividad'),
  NexusTool('timer', 'Reloj', 'Temporizador y cronómetro', Icons.timer_rounded, const Color(0xFFFFC857), (_) => const TimerTool(), cat: 'Productividad'),
  NexusTool('tasks', 'Tareas', 'Lista con fechas', Icons.checklist_rounded, const Color(0xFF6CCB5F), (_) => const TasksTool(), cat: 'Productividad'),
  NexusTool('translate', 'Traductor', 'Texto entre idiomas', Icons.translate_rounded, const Color(0xFF5A8DFF), (_) => const TranslatorTool(), cat: 'Productividad'),
  NexusTool('diff', 'Comparar textos', 'Diferencias línea a línea', Icons.compare_rounded, const Color(0xFFE56CFF), (_) => const TextDiffTool(), cat: 'Sistema'),
  NexusTool('world', 'NEXUS WORLD', 'Mapa mundial: conflictos, emergencias, aviones, ISS', Icons.public_rounded, const Color(0xFF00C2A8), (_) => const WorldTool(), cat: 'NEXUS WORLD'),
];
