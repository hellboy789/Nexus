import 'dart:math' as math;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../core/files.dart';
import '../core/glass.dart';
import '../core/scan.dart';

/// Treemap "squarified": área proporcional al tamaño. Toca una carpeta para entrar.
List<Rect> squarify(List<double> v, Rect rect) {
  final out = List<Rect>.filled(v.length, Rect.zero);
  final total = v.fold(0.0, (a, b) => a + b);
  if (total <= 0 || rect.width <= 0 || rect.height <= 0) return out;
  final scale = rect.width * rect.height / total;
  final a = v.map((e) => e * scale).toList();
  var x = rect.left, y = rect.top, w = rect.width, h = rect.height;
  var i = 0;
  while (i < a.length && a[i] > 0) {
    final side = math.min(w, h);
    var j = i;
    var sum = 0.0, worst = double.infinity;
    while (j < a.length && a[j] > 0) {
      final ns = sum + a[j];
      final nw = math.max(side * side * a[i] / (ns * ns), ns * ns / (side * side * a[j]));
      if (j > i && nw > worst) break;
      worst = nw;
      sum = ns;
      j++;
    }
    if (w >= h) {
      final cw = sum / h;
      var cy = y;
      for (var k = i; k < j; k++) {
        final ch = a[k] / cw;
        out[k] = Rect.fromLTWH(x, cy, cw, ch);
        cy += ch;
      }
      x += cw;
      w -= cw;
    } else {
      final rh = sum / w;
      var cx = x;
      for (var k = i; k < j; k++) {
        final cw = a[k] / rh;
        out[k] = Rect.fromLTWH(cx, y, cw, rh);
        cx += cw;
      }
      y += rh;
      h -= rh;
    }
    i = j;
  }
  return out;
}

class DiskMapTool extends StatefulWidget {
  const DiskMapTool({super.key});
  @override
  State<DiskMapTool> createState() => _S();
}

class _S extends State<DiskMapTool> {
  TreeResult? tree;
  final List<DNode> stack = [];
  String? root;
  bool busy = false;
  String status = '';
  List<DNode> items = [];
  List<Rect> rects = [];

  Future<void> _pick() async {
    final d = await FilePicker.platform.getDirectoryPath();
    if (d == null) return;
    setState(() {
      root = d;
      busy = true;
      status = '';
      tree = null;
      stack.clear();
    });
    try {
      final t = await scanTree(d);
      tree = t;
      stack.add(t.root);
      status = t.files == 0
          ? (t.errors > 0 ? 'Sin archivos legibles. En Android activa "Acceso a todos los archivos" para NEXUS o elige otra carpeta.' : 'Carpeta vacía.')
          : '${t.files} archivos · ${fmtSize(t.root.size)}${t.truncated ? ' · LÍMITE alcanzado (parcial)' : ''}${t.errors > 0 ? ' · ${t.errors} no legibles' : ''}';
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  Color _col(String n, bool dir) {
    final h = (n.hashCode.abs() % 360).toDouble();
    return HSLColor.fromAHSL(1, h, dir ? .55 : .35, dir ? .42 : .34).toColor();
  }

  void _tap(Offset o) {
    for (var i = 0; i < rects.length; i++) {
      if (rects[i].contains(o)) {
        final n = items[i];
        if (n.isDir && n.kids.isNotEmpty) setState(() => stack.add(n));
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cur = stack.isEmpty ? null : stack.last;
    List<DNode> kids = [];
    if (cur != null) {
      kids = cur.sorted().where((n) => n.size > 0).take(60).toList();
    }
    items = kids;
    return GlassPage(
      title: 'DISK MAP',
      maxWidth: 1000,
      child: Column(children: [
        Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              GlassButton('Elegir carpeta', icon: Icons.folder_open_rounded, onTap: busy ? null : _pick),
              const SizedBox(width: 8),
              if (stack.length > 1) GlassButton('Subir', icon: Icons.arrow_upward_rounded, onTap: () => setState(() => stack.removeLast())),
            ])),
        if (busy) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: LinearProgressIndicator(borderRadius: BorderRadius.circular(8))),
        if (status.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Text(status)),
        if (cur != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Align(alignment: Alignment.centerLeft, child: Text(stack.map((e) => e.name).join(' / '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)))),
        if (cur != null && kids.isNotEmpty)
          Expanded(
              child: Column(children: [
            Padding(
                padding: const EdgeInsets.all(16),
                child: LayoutBuilder(builder: (_, c) {
                  final size = Size(c.maxWidth, 320);
                  rects = squarify(kids.map((n) => n.size.toDouble()).toList(), Offset.zero & size);
                  return GestureDetector(
                      onTapUp: (d) => _tap(d.localPosition),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: SizedBox(width: size.width, height: size.height, child: CustomPaint(painter: _TreePainter(kids, rects, _col, cur.size)))));
                })),
            Expanded(
                child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: kids.length,
                    itemBuilder: (_, i) {
                      final n = kids[i];
                      return ListTile(
                        dense: true,
                        leading: Icon(n.isDir ? Icons.folder_rounded : Icons.insert_drive_file_rounded, color: _col(n.name, n.isDir)),
                        title: Text(n.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: LinearProgressIndicator(value: cur.size == 0 ? 0 : n.size / cur.size, borderRadius: BorderRadius.circular(6)),
                        trailing: Text('${fmtSize(n.size)} · ${(n.size * 100 / (cur.size == 0 ? 1 : cur.size)).toStringAsFixed(1)}%'),
                        onTap: n.isDir && n.kids.isNotEmpty ? () => setState(() => stack.add(n)) : null,
                      );
                    })),
          ]))
        else if (!busy)
          const Expanded(child: Center(child: Text('Elige una carpeta para ver su mapa'))),
      ]),
    );
  }
}

class _TreePainter extends CustomPainter {
  _TreePainter(this.items, this.rects, this.col, this.total);
  final List<DNode> items;
  final List<Rect> rects;
  final Color Function(String, bool) col;
  final int total;
  @override
  void paint(Canvas canvas, Size size) {
    for (var i = 0; i < items.length && i < rects.length; i++) {
      final r = rects[i].deflate(1);
      if (r.width < 1 || r.height < 1) continue;
      canvas.drawRect(r, Paint()..color = col(items[i].name, items[i].isDir));
      if (r.width > 56 && r.height > 28) {
        final tp = TextPainter(
            text: TextSpan(text: '${items[i].name}\n${fmtSize(items[i].size)}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
            textDirection: TextDirection.ltr,
            maxLines: 2,
            ellipsis: '…')
          ..layout(maxWidth: r.width - 8);
        tp.paint(canvas, r.topLeft + const Offset(4, 3));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TreePainter o) => o.items != items || o.rects != rects;
}
