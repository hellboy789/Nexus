import 'dart:io';
import 'package:flutter/material.dart';
import '../core/glass.dart';

class NetAnalyzerTool extends StatefulWidget {
  const NetAnalyzerTool({super.key});
  @override
  State<NetAnalyzerTool> createState() => _S();
}

class _S extends State<NetAnalyzerTool> {
  final host = TextEditingController(text: 'google.com');
  final log = StringBuffer();
  bool busy = false;
  void _w(String s) {
    if (mounted) setState(() => log.writeln(s));
  }

  Future<void> _do(Future<void> Function() f) async {
    setState(() {
      busy = true;
      log.clear();
    });
    try {
      await f();
    } catch (e) {
      _w('Error: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _ifaces() => _do(() async {
        for (final i in await NetworkInterface.list(includeLoopback: false)) {
          _w('● ${i.name}');
          for (final a in i.addresses) {
            _w('   ${a.type.name.toUpperCase()}  ${a.address}');
          }
        }
      });

  Future<void> _dns() => _do(() async {
        final h = host.text.trim();
        final sw = Stopwatch()..start();
        final r = await InternetAddress.lookup(h);
        _w('DNS $h  (${sw.elapsedMilliseconds} ms)');
        for (final a in r) {
          _w('   ${a.address}');
        }
      });

  Future<void> _ping() => _do(() async {
        final h = host.text.trim();
        _w('Ping TCP a $h:443');
        final t = <int>[];
        for (var i = 0; i < 4; i++) {
          final sw = Stopwatch()..start();
          try {
            final s = await Socket.connect(h, 443, timeout: const Duration(seconds: 3));
            s.destroy();
            t.add(sw.elapsedMilliseconds);
            _w('   ${sw.elapsedMilliseconds} ms');
          } catch (_) {
            _w('   sin respuesta');
          }
        }
        if (t.isNotEmpty) _w('Media: ${(t.reduce((a, b) => a + b) / t.length).toStringAsFixed(0)} ms');
      });

  Future<void> _ports() => _do(() async {
        final h = host.text.trim();
        _w('Escaneo de puertos comunes en $h (usa solo en equipos propios)');
        const ports = {21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3', 143: 'IMAP', 443: 'HTTPS', 445: 'SMB', 3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL', 8080: 'HTTP-alt'};
        await Future.wait(ports.entries.map((e) async {
          try {
            final s = await Socket.connect(h, e.key, timeout: const Duration(milliseconds: 1500));
            s.destroy();
            _w('   ${e.key} ${e.value}: ABIERTO');
          } catch (_) {}
        }));
        _w('Fin.');
      });

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Analizador de red',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: host, decoration: const InputDecoration(hintText: 'Host o IP', prefixIcon: Icon(Icons.dns_rounded))),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 10, children: [
            GlassButton('Interfaces', icon: Icons.settings_ethernet_rounded, onTap: busy ? null : _ifaces),
            GlassButton('DNS', icon: Icons.travel_explore_rounded, onTap: busy ? null : _dns),
            GlassButton('Ping', icon: Icons.network_ping_rounded, onTap: busy ? null : _ping),
            GlassButton('Puertos', icon: Icons.radar_rounded, onTap: busy ? null : _ports),
          ]),
          const SizedBox(height: 16),
          GlassCard(child: SizedBox(width: double.infinity, child: SelectableText(log.isEmpty ? 'Salida…' : log.toString(), style: const TextStyle(fontFamily: 'monospace', fontSize: 13)))),
        ]),
      );
}
