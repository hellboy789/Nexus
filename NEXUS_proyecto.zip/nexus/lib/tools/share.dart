import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../core/files.dart';
import '../core/glass.dart';
import '../core/localserver.dart';
import '../core/store.dart';
import 'package:file_picker/file_picker.dart';

/// Tarjeta con PIN, direcciones y QR del servidor local (la usan SHARE y BRIDGE).
class ServerCard extends StatelessWidget {
  const ServerCard({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
      valueListenable: NexusServer.I.tick,
      builder: (_, __, ___) {
        final s = NexusServer.I;
        if (!s.running) return const SizedBox.shrink();
        final qr = s.qrData;
        return Column(children: [
          GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.wifi_tethering_rounded, color: Color(0xFF4DD99A)),
              const SizedBox(width: 8),
              const Text('Servidor activo', style: TextStyle(fontWeight: FontWeight.w800)),
              const Spacer(),
              Text('PIN ${s.pin}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20, letterSpacing: 2)),
            ]),
            const SizedBox(height: 8),
            if (s.ips.isEmpty)
              const Text('No se detectó ninguna red local (conecta a WiFi/Ethernet).')
            else
              for (final u in s.urls()) SelectableText(u, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Text('Solo en tu red local. HTTP sin cifrar: el PIN limita el acceso, no cifra. En Windows acepta el aviso del firewall (redes privadas).',
                style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
          ])),
          if (qr != null) ...[
            const SizedBox(height: 10),
            Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                child: QrImageView(data: qr, size: 190)),
          ],
        ]);
      });
}

class _LogView extends StatelessWidget {
  const _LogView();
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<List<String>>(
      valueListenable: NexusServer.I.log,
      builder: (_, l, __) => l.isEmpty
          ? const SizedBox.shrink()
          : GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final s in l.take(12)) Text(s, style: const TextStyle(fontSize: 12))])));
}

class ShareTool extends StatefulWidget {
  const ShareTool({super.key});
  @override
  State<ShareTool> createState() => _S();
}

class _S extends State<ShareTool> {
  final sel = <String>{};
  bool ready = false;

  @override
  void initState() {
    super.initState();
    DropStore.ensure().then((_) {
      if (mounted) setState(() => ready = true);
    });
  }

  @override
  void dispose() {
    NexusServer.I.stop('send');
    NexusServer.I.stop('recv');
    super.dispose();
  }

  Future<void> _toggle(String owner, bool on) async {
    try {
      if (on) {
        if (owner == 'send') {
          NexusServer.I.shareIds
            ..clear()
            ..addAll(sel);
        }
        await NexusServer.I.start(owner);
      } else {
        await NexusServer.I.stop(owner);
      }
    } catch (e) {
      if (mounted) msg(context, 'No se pudo iniciar el servidor: $e');
    }
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r == null) return;
    for (final f in r.files) {
      if (f.path != null) sel.add((await DropStore.addFile(f.path!)).id);
    }
    NexusServer.I.shareIds
      ..clear()
      ..addAll(sel);
    if (mounted) setState(() {});
  }

  Widget _send() => ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          GlassButton('Añadir archivos', icon: Icons.add_rounded, onTap: _add),
          const SizedBox(width: 10),
          GlassButton(NexusServer.I.owners.contains('send') ? 'Detener' : 'Compartir (${sel.length})',
              icon: NexusServer.I.owners.contains('send') ? Icons.stop_rounded : Icons.play_arrow_rounded,
              onTap: NexusServer.I.owners.contains('send') ? () => _toggle('send', false) : (sel.isEmpty ? null : () => _toggle('send', true))),
        ]),
        const SizedBox(height: 12),
        const ServerCard(),
        const SizedBox(height: 12),
        if (ready)
          ValueListenableBuilder<List<DropItem>>(
              valueListenable: DropStore.items,
              builder: (_, l, __) {
                final files = l.where((i) => i.isFile).toList();
                if (files.isEmpty) return const Center(child: Text('Añade archivos o usa la bandeja DROPZONE'));
                return Column(children: [
                  for (final i in files)
                    Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: GlassCard(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            child: CheckboxListTile(
                                contentPadding: EdgeInsets.zero,
                                value: sel.contains(i.id),
                                title: Text(i.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                                subtitle: Text(fmtSize(i.size)),
                                onChanged: (v) => setState(() {
                                      v == true ? sel.add(i.id) : sel.remove(i.id);
                                      if (NexusServer.I.owners.contains('send')) {
                                        NexusServer.I.shareIds
                                          ..clear()
                                          ..addAll(sel);
                                      }
                                    })))),
                ]);
              }),
        const SizedBox(height: 8),
        const _LogView(),
      ]);

  Widget _recv() => ListView(padding: const EdgeInsets.all(16), children: [
        GlassButton(NexusServer.I.owners.contains('recv') ? 'Dejar de recibir' : 'Empezar a recibir',
            icon: NexusServer.I.owners.contains('recv') ? Icons.stop_rounded : Icons.download_rounded,
            onTap: () => _toggle('recv', !NexusServer.I.owners.contains('recv'))),
        const SizedBox(height: 8),
        Text('Desde otro dispositivo abre la dirección (o escanea el QR) en cualquier navegador y envía archivos o texto. Lo recibido aparece en DROPZONE.',
            style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
        const SizedBox(height: 12),
        const ServerCard(),
        const SizedBox(height: 12),
        const _LogView(),
      ]);

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 2,
      child: GlassPage(
          title: 'SHARE',
          bottom: const TabBar(tabs: [Tab(text: 'Enviar'), Tab(text: 'Recibir')]),
          child: TabBarView(children: [_send(), _recv()])));
}
