import 'dart:async';
import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

/// Zonas horarias: la zona y el desfase UTC los da Open-Meteo (timezone=auto).
class TimezonesTool extends StatefulWidget {
  const TimezonesTool({super.key});
  @override
  State<TimezonesTool> createState() => _TZ();
}

class _Z {
  _Z(this.name, this.tz, this.off);
  final String name, tz;
  final int off; // segundos respecto a UTC (actual, incluye horario de verano)
}

class _TZ extends State<TimezonesTool> {
  final zones = <_Z>[];
  String? error;
  Timer? t;
  @override
  void initState() {
    super.initState();
    t = Timer.periodic(const Duration(seconds: 1), (_) => mounted ? setState(() {}) : null);
  }

  @override
  void dispose() {
    t?.cancel();
    super.dispose();
  }

  Future<void> _add(Place p) async {
    setState(() => error = null);
    try {
      final j = await getJson('https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&current=temperature_2m&timezone=auto', ttl: const Duration(hours: 1));
      zones.add(_Z(p.name, '${j['timezone']} (${j['timezone_abbreviation']})', (j['utc_offset_seconds'] as num).toInt()));
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() {});
  }

  String _fmt(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final utc = DateTime.now().toUtc();
    final loc = DateTime.now();
    return GlassPage(
        title: 'Zonas horarias',
        maxWidth: 700,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          PlaceBar(onPlace: _add),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
          const SizedBox(height: 8),
          GlassCard(child: Row(children: [
            const Expanded(child: Text('UTC')),
            Text(_fmt(utc), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          ])),
          GlassCard(child: Row(children: [
            Expanded(child: Text('Tu dispositivo (${loc.timeZoneName})')),
            Text(_fmt(loc), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          ])),
          for (final z in zones)
            GlassCard(
                child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(z.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('${z.tz} · UTC${z.off >= 0 ? '+' : '-'}${(z.off.abs() / 3600).toStringAsFixed(z.off % 3600 == 0 ? 0 : 2)}', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
              ])),
              Text(_fmt(utc.add(Duration(seconds: z.off))), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => zones.remove(z))),
            ])),
          const SizedBox(height: 8),
          Text('Fuente: Open-Meteo (zona y desfase actuales). Busca una ciudad para añadirla.', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
        ]));
  }
}
