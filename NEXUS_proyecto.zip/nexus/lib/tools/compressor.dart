import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import '../core/files.dart';
import '../core/glass.dart';

Uint8List? _compress(Map<String, dynamic> a) {
  var im = img.decodeImage(a['b'] as Uint8List);
  if (im == null) return null;
  final mw = a['w'] as int;
  if (im.width > mw) im = img.copyResize(im, width: mw);
  return Uint8List.fromList(img.encodeJpg(im, quality: a['q'] as int));
}

class CompressorTool extends StatefulWidget {
  const CompressorTool({super.key});
  @override
  State<CompressorTool> createState() => _S();
}

class _S extends State<CompressorTool> {
  String? path;
  double quality = 75, maxW = 1920;
  String status = '';
  bool busy = false;

  Future<void> _run() async {
    if (path == null) return;
    setState(() {
      busy = true;
      status = 'Comprimiendo…';
    });
    try {
      final src = await File(path!).readAsBytes();
      final out = await compute(_compress, {'b': src, 'q': quality.round(), 'w': maxW.round()});
      if (out == null) throw 'Imagen no soportada';
      final saved = await saveBytes('${p.basenameWithoutExtension(path!)}_min.jpg', out);
      final pct = (100 - out.length * 100 / src.length).toStringAsFixed(0);
      status = '${fmtSize(src.length)} → ${fmtSize(out.length)} (−$pct%)${saved == null ? '  · sin guardar' : '\nGuardado: $saved'}';
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Comprimir imágenes',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          GlassCard(child: Text(path ?? 'Ninguna imagen seleccionada')),
          const SizedBox(height: 12),
          GlassCard(
              child: Column(children: [
            Row(children: [const Text('Calidad'), const Spacer(), Text('${quality.round()}%')]),
            Slider(value: quality, min: 10, max: 100, onChanged: (v) => setState(() => quality = v)),
            Row(children: [const Text('Ancho máximo'), const Spacer(), Text('${maxW.round()} px')]),
            Slider(value: maxW, min: 320, max: 4096, onChanged: (v) => setState(() => maxW = v)),
          ])),
          const SizedBox(height: 12),
          Wrap(spacing: 10, children: [
            GlassButton('Elegir imagen', icon: Icons.image_rounded, onTap: () async {
              final f = await pickPath(ext: ['jpg', 'jpeg', 'png', 'bmp', 'gif', 'webp']);
              if (f != null) setState(() => path = f);
            }),
            GlassButton('Comprimir', icon: Icons.compress_rounded, onTap: (path == null || busy) ? null : _run),
          ]),
          const SizedBox(height: 16),
          if (status.isNotEmpty) GlassCard(child: SelectableText(status)),
        ]),
      );
}
