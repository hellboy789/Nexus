import 'package:flutter/material.dart';
import '../core/glass.dart';

enum _Op { same, add, del }

/// Diff línea a línea con LCS.
List<(_Op, String)> _diff(List<String> a, List<String> b) {
  final n = a.length, m = b.length;
  final t = List.generate(n + 1, (_) => List.filled(m + 1, 0));
  for (var i = n - 1; i >= 0; i--) {
    for (var j = m - 1; j >= 0; j--) {
      t[i][j] = a[i] == b[j] ? t[i + 1][j + 1] + 1 : (t[i + 1][j] > t[i][j + 1] ? t[i + 1][j] : t[i][j + 1]);
    }
  }
  final r = <(_Op, String)>[];
  var i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] == b[j]) { r.add((_Op.same, a[i])); i++; j++; }
    else if (t[i + 1][j] >= t[i][j + 1]) { r.add((_Op.del, a[i++])); }
    else { r.add((_Op.add, b[j++])); }
  }
  while (i < n) r.add((_Op.del, a[i++]));
  while (j < m) r.add((_Op.add, b[j++]));
  return r;
}

class TextDiffTool extends StatefulWidget {
  const TextDiffTool({super.key});
  @override
  State<TextDiffTool> createState() => _TD();
}

class _TD extends State<TextDiffTool> {
  final a = TextEditingController(), b = TextEditingController();
  List<(_Op, String)>? res;

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Comparar textos',
      maxWidth: 900,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: a, maxLines: 6, decoration: const InputDecoration(hintText: 'Texto original')),
        const SizedBox(height: 8),
        TextField(controller: b, maxLines: 6, decoration: const InputDecoration(hintText: 'Texto nuevo')),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Comparar', icon: Icons.compare_rounded, onTap: () {
          if (a.text.length + b.text.length > 200000) return msg(context, 'Texto demasiado largo (máx. 200 000 caracteres).');
          setState(() => res = _diff(a.text.split('\n'), b.text.split('\n')));
        })),
        const SizedBox(height: 12),
        if (res != null) ...[
          Text('${res!.where((e) => e.$1 == _Op.add).length} añadidas · ${res!.where((e) => e.$1 == _Op.del).length} eliminadas'),
          const SizedBox(height: 8),
          GlassCard(
              padding: const EdgeInsets.all(8),
              child: Column(children: [
                for (final e in res!)
                  Container(
                      width: double.infinity,
                      color: e.$1 == _Op.add ? Colors.green.withOpacity(.25) : e.$1 == _Op.del ? Colors.red.withOpacity(.25) : null,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      child: Text('${e.$1 == _Op.add ? '+ ' : e.$1 == _Op.del ? '- ' : '  '}${e.$2}', style: const TextStyle(fontFamily: 'monospace'))),
              ])),
        ],
      ]));
}
