import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/files.dart';
import '../core/glass.dart';

/// Conversor MP3/MP4 para archivos propios. Usa FFmpeg del sistema (Windows).
/// Android: pendiente de integrar una librería FFmpeg (ver NEXUS_PROGRESS.md).
class MediaTool extends StatefulWidget {
  const MediaTool({super.key});
  @override
  State<MediaTool> createState() => _S();
}

class _S extends State<MediaTool> {
  String? path;
  String fmt = 'mp3';
  String status = '';
  bool busy = false;

  Future<void> _convert() async {
    if (path == null) return;
    final out = p.join(p.dirname(path!), '${p.basenameWithoutExtension(path!)}_nexus.$fmt');
    setState(() {
      busy = true;
      status = 'Convirtiendo…';
    });
    try {
      final args = fmt == 'mp3'
          ? ['-y', '-i', path!, '-vn', '-codec:a', 'libmp3lame', '-q:a', '2', out]
          : ['-y', '-i', path!, '-c:v', 'libx264', '-preset', 'medium', '-c:a', 'aac', out];
      final r = await Process.run('ffmpeg', args);
      status = r.exitCode == 0 ? 'Listo: $out' : 'FFmpeg falló:\n${(r.stderr as String).split('\n').reversed.take(6).toList().reversed.join('\n')}';
    } on ProcessException {
      status = 'No se encontró FFmpeg. Instálalo (winget install ffmpeg) y reinicia NEXUS.';
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Multimedia',
        child: !Platform.isWindows
            ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Conversión MP3/MP4 disponible por ahora solo en Windows (requiere FFmpeg instalado). Android: pendiente.', textAlign: TextAlign.center)))
            : ListView(padding: const EdgeInsets.all(16), children: [
                GlassCard(child: Text(path ?? 'Ningún archivo seleccionado')),
                const SizedBox(height: 12),
                Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
                  GlassButton('Elegir archivo', icon: Icons.folder_open_rounded, onTap: () async {
                    final f = await pickPath();
                    if (f != null) setState(() => path = f);
                  }),
                  SegmentedButton<String>(
                      segments: const [ButtonSegment(value: 'mp3', label: Text('MP3')), ButtonSegment(value: 'mp4', label: Text('MP4'))],
                      selected: {fmt},
                      onSelectionChanged: (s) => setState(() => fmt = s.first)),
                  GlassButton(busy ? 'Convirtiendo…' : 'Convertir', icon: Icons.play_arrow_rounded, onTap: (path == null || busy) ? null : _convert),
                ]),
                const SizedBox(height: 16),
                if (status.isNotEmpty) GlassCard(child: SelectableText(status)),
                const SizedBox(height: 12),
                Text('Úsalo solo con archivos propios o sin restricciones de copyright.', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
              ]),
      );
}
