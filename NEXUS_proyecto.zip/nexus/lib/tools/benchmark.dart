import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import '../core/glass.dart';

int _cpuWork(int _) {
  final sw = Stopwatch()..start();
  var n = 0;
  for (var i = 2; i < 300000; i++) {
    var p = true;
    for (var j = 2; j * j <= i; j++) {
      if (i % j == 0) {
        p = false;
        break;
      }
    }
    if (p) n++;
  }
  return n < 0 ? -1 : sw.elapsedMilliseconds;
}

double _ramWork() {
  const mb = 64;
  final a = Uint8List(mb * 1024 * 1024);
  final sw = Stopwatch()..start();
  for (var i = 0; i < a.length; i++) {
    a[i] = i & 255;
  }
  var s = 0;
  for (var i = 0; i < a.length; i++) {
    s += a[i];
  }
  final secs = sw.elapsedMicroseconds / 1e6;
  return s < 0 ? 0 : (mb * 2) / secs;
}

class BenchmarkTool extends StatefulWidget {
  const BenchmarkTool({super.key});
  @override
  State<BenchmarkTool> createState() => _S();
}

class _S extends State<BenchmarkTool> {
  final res = <String, String>{};
  String status = '';
  bool busy = false;
  void _s(VoidCallback f) {
    if (mounted) setState(f);
  }

  Future<void> _run() async {
    _s(() {
      busy = true;
      res.clear();
    });
    try {
      _s(() => status = 'CPU (1 núcleo)…');
      final single = await Isolate.run(() => _cpuWork(0));
      res['CPU 1 núcleo'] = '$single ms  ·  ${(3e5 / single).toStringAsFixed(0)} pts';
      _s(() => status = 'CPU (todos los núcleos)…');
      final cores = Platform.numberOfProcessors;
      final sw = Stopwatch()..start();
      await Future.wait(List.generate(cores, (i) => Isolate.run(() => _cpuWork(i))));
      final multi = sw.elapsedMilliseconds;
      res['CPU $cores núcleos'] = '$multi ms  ·  ${(3e5 * cores / multi).toStringAsFixed(0)} pts';
      _s(() => status = 'RAM…');
      final ram = await Isolate.run(_ramWork);
      res['RAM (64 MB)'] = '${ram.toStringAsFixed(0)} MB/s';
      _s(() => status = 'Almacenamiento…');
      final f = File('${(await getTemporaryDirectory()).path}/nexus_bench.tmp');
      final chunk = Uint8List(4 * 1024 * 1024);
      final w = Stopwatch()..start();
      final raf = await f.open(mode: FileMode.write);
      for (var i = 0; i < 16; i++) {
        await raf.writeFrom(chunk);
      }
      await raf.flush();
      await raf.close();
      final wMBs = 64 / (w.elapsedMicroseconds / 1e6);
      final r = Stopwatch()..start();
      var tot = 0;
      await for (final c in f.openRead()) {
        tot += c.length;
      }
      final rMBs = tot / 1048576 / (r.elapsedMicroseconds / 1e6);
      await f.delete();
      res['Disco escritura'] = '${wMBs.toStringAsFixed(0)} MB/s';
      res['Disco lectura*'] = '${rMBs.toStringAsFixed(0)} MB/s';
      _s(() => status = 'Completado');
    } catch (e) {
      _s(() => status = 'Error: $e');
    }
    _s(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Benchmark',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          if (res.isNotEmpty) KV(res),
          const SizedBox(height: 16),
          Center(child: Text(status)),
          const SizedBox(height: 12),
          Center(child: GlassButton(busy ? 'Ejecutando…' : 'Iniciar benchmark', icon: Icons.play_arrow_rounded, onTap: busy ? null : _run)),
          const SizedBox(height: 12),
          Center(child: Text('*La lectura puede estar inflada por la caché del sistema. Puntuaciones solo comparables entre ejecuciones de NEXUS.', textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12))),
        ]),
      );
}
