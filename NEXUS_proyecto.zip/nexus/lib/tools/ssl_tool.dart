import 'dart:io';
import 'package:flutter/material.dart';
import '../core/glass.dart';

/// Comprobador de certificado SSL/TLS (conexión directa al puerto 443, sin servicios externos).
class SslTool extends StatefulWidget {
  const SslTool({super.key});
  @override
  State<SslTool> createState() => _S();
}

class _S extends State<SslTool> {
  final c = TextEditingController();
  bool loading = false;
  String? error;
  Map<String, String> info = {};
  bool? trusted;

  Future<void> _run() async {
    final h = c.text.trim().replaceAll(RegExp(r'^https?://'), '').split('/').first;
    if (h.isEmpty) return;
    setState(() { loading = true; error = null; info = {}; trusted = null; });
    String? why;
    X509Certificate? cert;
    try {
      final s = await SecureSocket.connect(h, 443, timeout: const Duration(seconds: 10));
      cert = s.peerCertificate;
      trusted = true;
      s.destroy();
    } on HandshakeException catch (e) {
      trusted = false;
      why = e.message;
      try {
        final s = await SecureSocket.connect(h, 443, timeout: const Duration(seconds: 10), onBadCertificate: (_) => true);
        cert = s.peerCertificate;
        s.destroy();
      } catch (_) {}
    } catch (e) {
      error = 'No se pudo conectar a $h:443 (${e.toString().split('\n').first})';
    }
    if (cert != null) {
      final left = cert.endValidity.difference(DateTime.now()).inDays;
      info = {
        'Sujeto': cert.subject,
        'Emisor': cert.issuer,
        'Válido desde': cert.startValidity.toIso8601String().split('T').first,
        'Caduca': '${cert.endValidity.toIso8601String().split('T').first} ($left días${left < 0 ? ', CADUCADO' : left < 15 ? ', caduca pronto' : ''})',
        'Confianza': trusted == true ? 'Certificado de confianza' : 'NO confiable${why == null ? '' : ': $why'}',
      };
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Certificado SSL',
      maxWidth: 700,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: c, onSubmitted: (_) => _run(), decoration: const InputDecoration(hintText: 'ejemplo.com', prefixIcon: Icon(Icons.lock_rounded))),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Comprobar', icon: Icons.verified_user_rounded, onTap: loading ? null : _run)),
        const SizedBox(height: 12),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (info.isNotEmpty) KV(info),
      ]));
}
