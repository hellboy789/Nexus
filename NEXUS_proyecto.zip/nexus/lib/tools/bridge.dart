import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:path/path.dart' as p;
import '../core/db.dart';
import '../core/files.dart';
import '../core/glass.dart';
import '../core/localserver.dart';
import '../core/net.dart';
import '../core/store.dart';
import 'share.dart';

class BridgeTool extends StatefulWidget {
  const BridgeTool({super.key});
  @override
  State<BridgeTool> createState() => _S();
}

class _S extends State<BridgeTool> {
  final host = TextEditingController();
  final pin = TextEditingController();
  String? base; // http://ip:puerto
  String? remoteName;
  List<Map<String, dynamic>> remote = [];
  bool busy = false;

  @override
  void initState() {
    super.initState();
    DropStore.ensure();
    NexusDb.getSetting('bridge_host').then((v) {
      if (v != null && mounted) host.text = v;
    });
  }

  @override
  void dispose() {
    NexusServer.I.stop('bridge');
    super.dispose();
  }

  Map<String, String> get _h => {'X-Nexus-Key': pin.text.trim()};

  Uri? _parse(String s) {
    s = s.trim();
    if (s.isEmpty) return null;
    final u = Uri.tryParse(s.contains('://') ? s : 'http://$s');
    if (u == null || u.host.isEmpty) return null;
    return u;
  }

  Future<void> _connect() async {
    final u = _parse(host.text);
    if (u == null || pin.text.trim().isEmpty) {
      msg(context, 'Indica dirección y PIN');
      return;
    }
    final b = 'http://${u.host}:${u.hasPort ? u.port : 8765}';
    setState(() => busy = true);
    try {
      final r = await httpGet('$b/api/ping', headers: _h, timeout: const Duration(seconds: 6), retries: 0);
      final j = jsonDecode(r.body) as Map<String, dynamic>;
      if (j['nexus'] != 1) throw 'No es un equipo NEXUS';
      base = b;
      remoteName = '${j['name']} (${j['os']})';
      await NexusDb.setSetting('bridge_host', '${u.host}:${u.hasPort ? u.port : 8765}');
      await _refresh();
    } catch (e) {
      base = null;
      if (mounted) msg(context, 'No se pudo conectar: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _refresh() async {
    final r = await httpGet('$base/api/list', headers: _h, timeout: const Duration(seconds: 8), retries: 0);
    remote = (jsonDecode(r.body) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    if (mounted) setState(() {});
  }

  Future<void> _sendFiles() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r == null) return;
    setState(() => busy = true);
    for (final f in r.files) {
      if (f.path == null) continue;
      try {
        final file = File(f.path!);
        final req = http.StreamedRequest('POST', Uri.parse('$base/up?name=${Uri.encodeQueryComponent(safeName(f.name))}'));
        req.headers.addAll(_h);
        req.contentLength = await file.length();
        file.openRead().listen(req.sink.add, onDone: req.sink.close, onError: (_) => req.sink.close());
        final res = await req.send();
        await res.stream.drain<void>();
        if (mounted) msg(context, res.statusCode == 200 ? '${f.name} enviado' : '${f.name}: error ${res.statusCode} (¿el otro equipo tiene la recepción activa?)');
      } catch (e) {
        if (mounted) msg(context, '${f.name}: $e');
      }
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _sendText(String t) async {
    if (t.trim().isEmpty) return;
    try {
      final res = await http.post(Uri.parse('$base/txt'), headers: _h, body: t).timeout(const Duration(seconds: 10));
      if (mounted) msg(context, res.statusCode == 200 ? 'Texto enviado' : 'Error ${res.statusCode}');
    } catch (e) {
      if (mounted) msg(context, 'Error: $e');
    }
  }

  Future<void> _sendClipboard() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    await _sendText(d?.text ?? '');
  }

  Future<void> _download(Map<String, dynamic> it) async {
    try {
      if (it['kind'] == 'text' || it['kind'] == 'link') {
        await DropStore.addText(it['text'] as String? ?? '');
        if (mounted) msg(context, 'Guardado en tu bandeja');
        return;
      }
      setState(() => busy = true);
      final c = http.Client();
      final res = await c.send(http.Request('GET', Uri.parse('$base/f/${it['id']}'))..headers.addAll(_h));
      if (res.statusCode != 200) throw 'error ${res.statusCode}';
      final name = safeName(it['title'] as String);
      final id = DropStore.newId();
      final f = File(p.join(DropStore.dir.path, '${id}_$name'));
      final sink = f.openWrite();
      await sink.addStream(res.stream);
      await sink.close();
      c.close();
      await DropStore.adopt(id, name, f);
      if (mounted) msg(context, '$name guardado en tu bandeja');
    } catch (e) {
      if (mounted) msg(context, 'Descarga fallida: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _scan() async {
    final v = await showDialog<String>(
        context: context,
        builder: (_) => Dialog(
            child: SizedBox(
                height: 360,
                child: MobileScanner(onDetect: (cap) {
                  final r = cap.barcodes.isEmpty ? null : cap.barcodes.first.rawValue;
                  if (r != null) Navigator.of(context).pop(r);
                }))));
    if (v == null) return;
    final u = Uri.tryParse(v);
    if (u == null || u.host.isEmpty) {
      if (mounted) msg(context, 'QR no válido');
      return;
    }
    host.text = '${u.host}:${u.hasPort ? u.port : 8765}';
    pin.text = u.queryParameters['k'] ?? '';
    setState(() {});
  }

  Widget _hostTab() {
    final on = NexusServer.I.owners.contains('bridge');
    return ListView(padding: const EdgeInsets.all(16), children: [
      GlassButton(on ? 'Desactivar puente' : 'Activar puente en este equipo', icon: on ? Icons.stop_rounded : Icons.devices_rounded, onTap: () async {
        try {
          on ? await NexusServer.I.stop('bridge') : await NexusServer.I.start('bridge');
        } catch (e) {
          if (mounted) msg(context, 'Error: $e');
        }
        if (mounted) setState(() {});
      }),
      const SizedBox(height: 8),
      Text('Activo: el otro equipo (con NEXUS o un navegador) puede ver tu bandeja DROPZONE completa y enviarte archivos/texto. Se apaga al salir de esta pantalla.',
          style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
      const SizedBox(height: 12),
      const ServerCard(),
    ]);
  }

  Widget _connectTab() => ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: host, decoration: const InputDecoration(hintText: 'IP:puerto  (ej. 192.168.1.20:8765)')),
        const SizedBox(height: 8),
        TextField(controller: pin, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'PIN de 6 cifras')),
        const SizedBox(height: 10),
        Wrap(spacing: 10, runSpacing: 10, children: [
          GlassButton(busy ? 'Conectando…' : 'Conectar', icon: Icons.link_rounded, onTap: busy ? null : _connect),
          if (Platform.isAndroid) GlassButton('Escanear QR', icon: Icons.qr_code_scanner_rounded, onTap: _scan),
        ]),
        if (base != null) ...[
          const SizedBox(height: 16),
          GlassCard(child: Row(children: [const Icon(Icons.check_circle_rounded, color: Color(0xFF4DD99A)), const SizedBox(width: 8), Expanded(child: Text('Conectado a $remoteName'))])),
          const SizedBox(height: 10),
          Wrap(spacing: 10, runSpacing: 10, children: [
            GlassButton('Enviar archivos', icon: Icons.upload_file_rounded, onTap: busy ? null : _sendFiles),
            GlassButton('Enviar portapapeles', icon: Icons.content_paste_go_rounded, onTap: _sendClipboard),
            GlassButton('Actualizar', icon: Icons.refresh_rounded, onTap: _refresh),
          ]),
          const SizedBox(height: 12),
          Text('Bandeja del otro equipo', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          if (remote.isEmpty) const Text('Vacía o sin elementos visibles'),
          for (final it in remote)
            Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GlassCard(
                    padding: const EdgeInsets.all(12),
                    child: Row(children: [
                      Expanded(child: Text('${it['title']}${(it['kind'] == 'file' || it['kind'] == 'image') ? '  ·  ${fmtSize((it['size'] as num).toInt())}' : ''}', maxLines: 2, overflow: TextOverflow.ellipsis)),
                      IconButton(tooltip: 'Traer a mi bandeja', icon: const Icon(Icons.download_rounded), onPressed: busy ? null : () => _download(it)),
                    ]))),
        ],
      ]);

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 2,
      child: GlassPage(
          title: 'BRIDGE',
          bottom: const TabBar(tabs: [Tab(text: 'Este equipo'), Tab(text: 'Conectar')]),
          child: TabBarView(children: [_hostTab(), _connectTab()])));
}
