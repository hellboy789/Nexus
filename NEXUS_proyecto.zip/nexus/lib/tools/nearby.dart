import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../core/glass.dart';
import '../core/net.dart';

class _Cat {
  const _Cat(this.name, this.icon, this.filters);
  final String name;
  final IconData icon;
  final List<String> filters;
}

const _cats = [
  _Cat('Farmacias', Icons.local_pharmacy_rounded, ['amenity=pharmacy']),
  _Cat('Hospitales', Icons.local_hospital_rounded, ['amenity=hospital', 'amenity=clinic']),
  _Cat('Gasolineras', Icons.local_gas_station_rounded, ['amenity=fuel']),
  _Cat('Restaurantes', Icons.restaurant_rounded, ['amenity=restaurant']),
  _Cat('Cafeterías', Icons.local_cafe_rounded, ['amenity=cafe']),
  _Cat('Supermercados', Icons.shopping_cart_rounded, ['shop=supermarket']),
  _Cat('Cajeros', Icons.atm_rounded, ['amenity=atm']),
  _Cat('Aparcamientos', Icons.local_parking_rounded, ['amenity=parking']),
];

class _Poi {
  _Poi(this.name, this.pos, this.dist, this.tags);
  final String name;
  final LatLng pos;
  final double dist;
  final Map tags;
}

class NearbyTool extends StatefulWidget {
  const NearbyTool({super.key});
  @override
  State<NearbyTool> createState() => _N();
}

class _N extends State<NearbyTool> {
  Place? place;
  int cat = 0;
  List<_Poi> items = [];
  bool loading = false, showMap = false;
  String? error;
  double radius = 2000;

  static final _cache = <String, (DateTime, List<_Poi>, String)>{};
  static const _eps = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter'];
  static const _terms = ['pharmacy', 'hospital', 'fuel station', 'restaurant', 'cafe', 'supermarket', 'atm', 'parking'];
  int _req = 0;
  String via = '';

  Future<List<_Poi>> _viaOverpass(Place p, _Cat c) async {
    final q = '[out:json][timeout:15];(${c.filters.map((f) {
      final kv = f.split('=');
      return 'nwr["${kv[0]}"="${kv[1]}"](around:${radius.round()},${p.lat},${p.lon});';
    }).join()});out center 80;';
    final errs = <String>[];
    for (final ep in _eps) {
      final host = Uri.parse(ep).host;
      try {
        final r = await http.post(Uri.parse(ep), headers: {'User-Agent': nexusUA, 'Accept': 'application/json'}, body: {'data': q}).timeout(const Duration(seconds: 12));
        if (r.statusCode != 200) {
          errs.add('$host HTTP ${r.statusCode}');
          continue;
        }
        final j = jsonDecode(utf8.decode(r.bodyBytes));
        final els = (j['elements'] as List?) ?? [];
        if (els.isEmpty && j['remark'] != null) {
          errs.add('$host: ${j['remark']}');
          continue;
        }
        via = 'Overpass · $host';
        const d = Distance();
        final l = <_Poi>[];
        for (final e in els) {
          final lat = (e['lat'] ?? e['center']?['lat']) as num?, lon = (e['lon'] ?? e['center']?['lon']) as num?;
          if (lat == null || lon == null) continue;
          final pos = LatLng(lat.toDouble(), lon.toDouble());
          final tags = (e['tags'] as Map?) ?? {};
          l.add(_Poi(tags['name']?.toString() ?? '${c.name} (sin nombre)', pos, d.as(LengthUnit.Meter, LatLng(p.lat, p.lon), pos), tags));
        }
        return l;
      } on TimeoutException {
        errs.add('$host tiempo agotado');
      } on SocketException {
        errs.add('$host sin conexión');
      } catch (e) {
        errs.add('$host error');
      }
    }
    throw NetError('Overpass no respondió (${errs.join('; ')})');
  }

  Future<List<_Poi>> _viaNominatim(Place p, _Cat c) async {
    final dLat = radius / 111320, dLon = radius / (111320 * math.cos(p.lat * math.pi / 180).abs().clamp(.05, 1));
    final j = await getJson('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=40&bounded=1&accept-language=es&viewbox=${p.lon - dLon},${p.lat + dLat},${p.lon + dLon},${p.lat - dLat}&q=${Uri.encodeQueryComponent(_terms[cat])}', timeout: const Duration(seconds: 12), retries: 0);
    via = 'Nominatim (respaldo)';
    const d = Distance();
    final l = <_Poi>[];
    for (final e in (j as List)) {
      final pos = LatLng(double.parse('${e['lat']}'), double.parse('${e['lon']}'));
      final dn = '${e['display_name']}';
      l.add(_Poi(('${e['name'] ?? ''}').isEmpty ? '${c.name} (sin nombre)' : '${e['name']}', pos, d.as(LengthUnit.Meter, LatLng(p.lat, p.lon), pos), {'display': dn.split(',').skip(1).take(3).join(',').trim()}));
    }
    return l;
  }

  Future<void> _search() async {
    if (place == null) return;
    final p = place!, c = _cats[cat];
    final id = ++_req;
    final key = '${p.lat.toStringAsFixed(3)},${p.lon.toStringAsFixed(3)},$cat,${radius.round()}';
    final hit = _cache[key];
    if (hit != null && DateTime.now().difference(hit.$1) < const Duration(minutes: 10)) {
      setState(() { items = hit.$2; via = '${hit.$3} · caché'; error = null; loading = false; });
      return;
    }
    setState(() { loading = true; error = null; });
    try {
      List<_Poi> l;
      try {
        l = await _viaOverpass(p, c);
      } catch (e1) {
        try {
          l = await _viaNominatim(p, c);
        } catch (e2) {
          throw NetError('$e1\nRespaldo: $e2');
        }
      }
      l.sort((a, b) => a.dist.compareTo(b.dist));
      _cache[key] = (DateTime.now(), l, via);
      if (mounted && id == _req) setState(() => items = l);
    } catch (e) {
      if (mounted && id == _req) setState(() { items = []; error = '$e'; });
    }
    if (mounted && id == _req) setState(() => loading = false);
  }

  String _dist(double m) => m < 1000 ? '${m.round()} m' : '${(m / 1000).toStringAsFixed(1)} km';

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Cerca de mí',
      maxWidth: 1000,
      actions: [IconButton(icon: Icon(showMap ? Icons.list_rounded : Icons.map_rounded), onPressed: () => setState(() => showMap = !showMap))],
      child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 8), child: PlaceBar(onPlace: (p) {
          place = p;
          _search();
        })),
        SizedBox(
            height: 44,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
              for (var i = 0; i < _cats.length; i++)
                Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                        avatar: Icon(_cats[i].icon, size: 18),
                        label: Text(_cats[i].name),
                        selected: cat == i,
                        onSelected: (_) {
                          setState(() => cat = i);
                          _search();
                        })),
            ])),
        Row(children: [
          const SizedBox(width: 16),
          Text('Radio ${_dist(radius)}'),
          Expanded(child: Slider(value: radius, min: 500, max: 10000, divisions: 19, onChanged: (v) => setState(() => radius = v), onChangeEnd: (_) => _search())),
        ]),
        Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : error != null
                    ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center)))
                    : place == null
                        ? const Center(child: Text('Elige una ciudad o usa tu ubicación'))
                        : items.isEmpty
                            ? const Center(child: Text('Sin resultados en OpenStreetMap para este radio'))
                            : showMap
                                ? FlutterMap(options: MapOptions(initialCenter: LatLng(place!.lat, place!.lon), initialZoom: 14), children: [
                                    TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'dev.nexus.nexus'),
                                    MarkerLayer(markers: [
                                      Marker(point: LatLng(place!.lat, place!.lon), child: const Icon(Icons.my_location_rounded, color: Colors.blue)),
                                      for (final i in items) Marker(point: i.pos, child: Tooltip(message: i.name, child: Icon(_cats[cat].icon, color: Colors.redAccent))),
                                    ]),
                                    const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')]),
                                  ])
                                : ListView.builder(
                                    padding: const EdgeInsets.all(16),
                                    itemCount: items.length,
                                    itemBuilder: (_, k) {
                                      final i = items[k];
                                      final t = i.tags;
                                      final sub = [
                                        if (t['cuisine'] != null) t['cuisine'].toString().replaceAll('_', ' '),
                                        if (t['opening_hours'] != null) 'Horario: ${t['opening_hours']}',
                                        if (t['addr:street'] != null) '${t['addr:street']} ${t['addr:housenumber'] ?? ''}',
                                        if (t['phone'] != null) 'Tel: ${t['phone']}',
                                        if (t['display'] != null && '${t['display']}'.isNotEmpty) t['display'],
                                      ].join('\n');
                                      return Padding(
                                          padding: const EdgeInsets.only(bottom: 8),
                                          child: GlassCard(
                                              child: Row(children: [
                                            Icon(_cats[cat].icon),
                                            const SizedBox(width: 12),
                                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                              Text(i.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                                              if (sub.isNotEmpty) Text(sub, style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                                            ])),
                                            Text(_dist(i.dist), style: const TextStyle(fontWeight: FontWeight.w700)),
                                          ])));
                                    })),
        Padding(padding: const EdgeInsets.all(6), child: Text('Datos © OpenStreetMap${via.isEmpty ? '' : ' · $via'}. Valoraciones y precios no disponibles en servicios gratuitos abiertos.', style: TextStyle(fontSize: 10, color: Theme.of(context).hintColor), textAlign: TextAlign.center)),
      ]));
}
