import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/glass.dart';

const _codes = {
  200: 'OK: petición correcta', 201: 'Creado', 204: 'Sin contenido', 301: 'Movido permanentemente', 302: 'Redirección temporal', 304: 'No modificado (caché válida)',
  400: 'Petición incorrecta', 401: 'No autenticado', 403: 'Prohibido', 404: 'No encontrado', 405: 'Método no permitido', 408: 'Tiempo de espera del cliente',
  409: 'Conflicto', 429: 'Demasiadas peticiones (límite de uso)', 500: 'Error interno del servidor', 502: 'Puerta de enlace incorrecta', 503: 'Servicio no disponible', 504: 'Tiempo de espera de la puerta de enlace',
};

const _sec = {
  'strict-transport-security': 'HSTS',
  'content-security-policy': 'CSP',
  'x-content-type-options': 'X-Content-Type-Options',
  'x-frame-options': 'X-Frame-Options',
  'referrer-policy': 'Referrer-Policy',
  'permissions-policy': 'Permissions-Policy',
};

/// Cliente de APIs + analizador de cabeceras HTTP y códigos de estado.
class HttpTool extends StatefulWidget {
  const HttpTool({super.key});
  @override
  State<HttpTool> createState() => _H();
}

class _H extends State<HttpTool> {
  final url = TextEditingController(text: 'https://'), headers = TextEditingController(), body = TextEditingController();
  String method = 'GET';
  bool loading = false;
  String? error;
  http.Response? res;
  int ms = 0;

  Future<void> _send() async {
    final u = Uri.tryParse(url.text.trim());
    if (u == null || !u.hasScheme || u.host.isEmpty) return setState(() => error = 'URL no válida.');
    setState(() { loading = true; error = null; res = null; });
    try {
      final req = http.Request(method, u);
      for (final l in headers.text.split('\n')) {
        final i = l.indexOf(':');
        if (i > 0) req.headers[l.substring(0, i).trim()] = l.substring(i + 1).trim();
      }
      if (body.text.isNotEmpty && method != 'GET' && method != 'HEAD') req.body = body.text;
      final sw = Stopwatch()..start();
      final s = await req.send().timeout(const Duration(seconds: 20));
      final r = await http.Response.fromStream(s).timeout(const Duration(seconds: 20));
      sw.stop();
      ms = sw.elapsedMilliseconds;
      res = r;
    } catch (e) {
      error = 'Error de red: ${e.toString().split('\n').first}';
    }
    if (mounted) setState(() => loading = false);
  }

  String _pretty(String b) {
    try {
      return const JsonEncoder.withIndent('  ').convert(jsonDecode(b));
    } catch (_) {
      return b;
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = res;
    final text = r == null ? '' : _pretty(utf8.decode(r.bodyBytes, allowMalformed: true));
    return GlassPage(
        title: 'Cliente HTTP / API',
        maxWidth: 800,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            DropdownButton<String>(value: method, items: [for (final m in ['GET', 'POST', 'PUT', 'DELETE', 'HEAD']) DropdownMenuItem(value: m, child: Text(m))], onChanged: (v) => setState(() => method = v!)),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: url, keyboardType: TextInputType.url)),
          ]),
          const SizedBox(height: 8),
          TextField(controller: headers, maxLines: 3, decoration: const InputDecoration(hintText: 'Cabeceras (una por línea)\nAuthorization: Bearer …')),
          if (method != 'GET' && method != 'HEAD') ...[const SizedBox(height: 8), TextField(controller: body, maxLines: 4, decoration: const InputDecoration(hintText: 'Cuerpo'))],
          const SizedBox(height: 8),
          Align(alignment: Alignment.centerLeft, child: GlassButton('Enviar', icon: Icons.send_rounded, onTap: loading ? null : _send)),
          const SizedBox(height: 12),
          if (loading) const Center(child: CircularProgressIndicator()),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
          if (r != null) ...[
            GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${r.statusCode} ${r.reasonPhrase ?? ''}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              if (_codes[r.statusCode] != null) Text(_codes[r.statusCode]!),
              Text('$ms ms · ${r.bodyBytes.length} bytes'),
            ])),
            const SizedBox(height: 8),
            GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Cabeceras de seguridad', style: TextStyle(fontWeight: FontWeight.w700)),
              for (final e in _sec.entries) Row(children: [Icon(r.headers.containsKey(e.key) ? Icons.check_circle_rounded : Icons.cancel_rounded, size: 16, color: r.headers.containsKey(e.key) ? Colors.green : Colors.redAccent), const SizedBox(width: 6), Text(e.value)]),
              const SizedBox(height: 4),
              Text('Es un chequeo de presencia, no una auditoría completa.', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
            ])),
            const SizedBox(height: 8),
            KV({for (final e in r.headers.entries) e.key: e.value}),
            const SizedBox(height: 8),
            GlassCard(child: SelectableText(text.length > 20000 ? '${text.substring(0, 20000)}\n… (recortado)' : text, style: const TextStyle(fontFamily: 'monospace', fontSize: 12))),
          ],
        ]));
  }
}
