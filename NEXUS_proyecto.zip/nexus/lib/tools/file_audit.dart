import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/files.dart';
import '../core/glass.dart';
import '../core/scan.dart';
import '../core/ui.dart';

/// FILE AUDIT: resumen por tipo, mayores archivos, duplicados reales (SHA-256) y antiguos.
class FileAuditTool extends StatefulWidget {
  const FileAuditTool({super.key});
  @override
  State<FileAuditTool> createState() => _S();
}

class _S extends State<FileAuditTool> {
  String? root;
  ScanResult? res;
  List<List<FEntry>>? dupes;
  final Set<String> sel = {}; // rutas marcadas para borrar
  bool busy = false;
  String phase = '', status = '';
  int minDup = 1024;

  String _d(int ms) => DateTime.fromMillisecondsSinceEpoch(ms).toIso8601String().substring(0, 10);

  Future<void> _pick() async {
    final d = await FilePicker.platform.getDirectoryPath();
    if (d == null) return;
    setState(() {
      root = d;
      res = null;
      dupes = null;
      sel.clear();
      busy = true;
      phase = 'Escaneando…';
      status = '';
    });
    try {
      final r = await scanDir(d);
      res = r;
      if (r.files.isEmpty) {
        status = r.errors > 0
            ? 'Sin archivos legibles (${r.errors} errores). En Android activa "Acceso a todos los archivos" para NEXUS en Ajustes > Apps, o elige otra carpeta.'
            : 'Carpeta vacía.';
      } else if (r.truncated) {
        status = 'Límite de $kMaxScan archivos alcanzado: resultados parciales.';
      }
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _dupes() async {
    setState(() {
      busy = true;
      phase = 'Buscando duplicados (hash SHA-256)…';
    });
    try {
      final g = await findDuplicates(res!.files, minDup);
      dupes = g;
      sel
        ..clear()
        ..addAll(g.expand((x) => x.skip(1).map((e) => e.path))); // conserva el más antiguo
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _delete(List<String> paths) async {
    if (paths.isEmpty) return;
    final bytes = res!.files.where((f) => paths.contains(f.path)).fold<int>(0, (a, f) => a + f.size);
    if (!await confirmDlg(context, 'Se borrarán ${paths.length} archivos (${fmtSize(bytes)}) de forma PERMANENTE (sin papelera). ¿Continuar?', ok: 'Borrar')) return;
    var ok = 0;
    final fail = <String>[];
    for (final f in paths) {
      try {
        await File(f).delete();
        ok++;
      } catch (e) {
        fail.add(p.basename(f));
      }
    }
    final gone = paths.where((x) => !fail.contains(p.basename(x))).toSet();
    setState(() {
      res = ScanResult(res!.files.where((f) => !gone.contains(f.path)).toList(), res!.dirs, res!.errors, res!.truncated);
      if (dupes != null) {
        dupes = dupes!.map((g) => g.where((f) => !gone.contains(f.path)).toList()).where((g) => g.length > 1).toList();
      }
      sel.removeAll(gone);
      status = 'Borrados $ok${fail.isEmpty ? '' : ' · fallaron ${fail.length}: ${fail.take(5).join(', ')}'}';
    });
  }

  Widget _summary(ScanResult r) {
    final cat = <String, int>{}, cnt = <String, int>{};
    for (final f in r.files) {
      final c = categoryOf(f.path);
      cat[c] = (cat[c] ?? 0) + f.size;
      cnt[c] = (cnt[c] ?? 0) + 1;
    }
    final keys = cat.keys.toList()..sort((a, b) => cat[b]!.compareTo(cat[a]!));
    final total = r.total == 0 ? 1 : r.total;
    final yearAgo = DateTime.now().subtract(const Duration(days: 365)).millisecondsSinceEpoch;
    final old = r.files.where((f) => f.mod < yearAgo).toList();
    final oldSize = old.fold<int>(0, (a, f) => a + f.size);
    final empty = r.files.where((f) => f.size == 0).length;
    return ListView(padding: const EdgeInsets.all(16), children: [
      GlassCard(child: Text('${r.files.length} archivos · ${r.dirs} carpetas · ${fmtSize(r.total)}\n'
          'Sin modificar en +1 año: ${old.length} (${fmtSize(oldSize)})\nArchivos vacíos: $empty\nNo legibles: ${r.errors}')),
      const SizedBox(height: 12),
      for (final k in keys)
        Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GlassCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Text(k, style: const TextStyle(fontWeight: FontWeight.w700)), const Spacer(), Text('${cnt[k]} · ${fmtSize(cat[k]!)}')]),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: cat[k]! / total, minHeight: 8, borderRadius: BorderRadius.circular(8)),
            ]))),
    ]);
  }

  Widget _largest(ScanResult r) {
    final l = [...r.files]..sort((a, b) => b.size.compareTo(a.size));
    final top = l.take(100).toList();
    return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: top.length,
        itemBuilder: (_, i) {
          final f = top[i];
          return GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(p.basename(f.path), maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${p.relative(p.dirname(f.path), from: root!)} · ${_d(f.mod)}', maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(fmtSize(f.size), style: const TextStyle(fontWeight: FontWeight.w700)),
                  IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () => _delete([f.path])),
                ]),
              ));
        });
  }

  Widget _dupTab() {
    final g = dupes;
    return Column(children: [
      Padding(
          padding: const EdgeInsets.all(16),
          child: Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
            DropdownButton<int>(
                value: minDup,
                items: const [DropdownMenuItem(value: 1, child: Text('Cualquier tamaño')), DropdownMenuItem(value: 1024, child: Text('≥ 1 KB')), DropdownMenuItem(value: 1048576, child: Text('≥ 1 MB')), DropdownMenuItem(value: 52428800, child: Text('≥ 50 MB'))],
                onChanged: busy ? null : (v) => setState(() => minDup = v ?? minDup)),
            GlassButton('Buscar duplicados', icon: Icons.content_copy_rounded, onTap: busy ? null : _dupes),
            if (g != null && g.isNotEmpty) GlassButton('Borrar marcados (${sel.length})', icon: Icons.delete_forever_rounded, onTap: sel.isEmpty ? null : () => _delete(sel.toList())),
          ])),
      if (g != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Align(alignment: Alignment.centerLeft, child: Text(g.isEmpty ? 'Sin duplicados.' : '${g.length} grupos · recuperable: ${fmtSize(g.fold<int>(0, (a, x) => a + x.first.size * (x.length - 1)))}  (por defecto se conserva el más antiguo de cada grupo)'))),
      Expanded(
          child: g == null
              ? const SizedBox()
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: g.length,
                  itemBuilder: (_, i) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: GlassCard(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${fmtSize(g[i].first.size)} × ${g[i].length}', style: const TextStyle(fontWeight: FontWeight.w800)),
                        for (final f in g[i])
                          CheckboxListTile(
                              dense: true,
                              contentPadding: EdgeInsets.zero,
                              controlAffinity: ListTileControlAffinity.leading,
                              value: sel.contains(f.path),
                              onChanged: (v) => setState(() => v == true ? sel.add(f.path) : sel.remove(f.path)),
                              title: Text(p.relative(f.path, from: root!), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                              subtitle: Text(_d(f.mod))),
                      ]))))),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final r = res;
    return DefaultTabController(
        length: 3,
        child: GlassPage(
          title: 'FILE AUDIT',
          maxWidth: 1000,
          bottom: const TabBar(tabs: [Tab(text: 'Resumen'), Tab(text: 'Mayores'), Tab(text: 'Duplicados')]),
          child: Column(children: [
            Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  GlassButton('Elegir carpeta', icon: Icons.folder_open_rounded, onTap: busy ? null : _pick),
                  const SizedBox(width: 12),
                  Expanded(child: Text(root ?? 'Ninguna carpeta', maxLines: 1, overflow: TextOverflow.ellipsis)),
                ])),
            if (busy) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(children: [LinearProgressIndicator(borderRadius: BorderRadius.circular(8)), const SizedBox(height: 4), Text(phase)])),
            if (status.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 0), child: GlassCard(child: SelectableText(status))),
            Expanded(
                child: (r == null || r.files.isEmpty)
                    ? const Center(child: Text('Elige una carpeta para analizar'))
                    : TabBarView(children: [_summary(r), _largest(r), _dupTab()])),
          ]),
        ));
  }
}
