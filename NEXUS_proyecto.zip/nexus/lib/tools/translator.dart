import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

const _langs = {'es': 'Español', 'en': 'Inglés', 'fr': 'Francés', 'de': 'Alemán', 'it': 'Italiano', 'pt': 'Portugués', 'ca': 'Catalán', 'nl': 'Neerlandés', 'ru': 'Ruso', 'ja': 'Japonés', 'zh': 'Chino', 'ar': 'Árabe'};

/// Traductor vía MyMemory (gratuito, sin clave; límite diario por IP y 500 caracteres por petición).
class TranslatorTool extends StatefulWidget {
  const TranslatorTool({super.key});
  @override
  State<TranslatorTool> createState() => _TR();
}

class _TR extends State<TranslatorTool> {
  final c = TextEditingController();
  String from = 'es', to = 'en', out = '';
  String? error;
  bool loading = false;

  Future<void> _go() async {
    final t = c.text.trim();
    if (t.isEmpty) return;
    if (t.length > 500) return setState(() => error = 'Máximo 500 caracteres por traducción (límite del servicio gratuito).');
    setState(() { loading = true; error = null; });
    try {
      final j = await getJson('https://api.mymemory.translated.net/get?q=${Uri.encodeQueryComponent(t)}&langpair=$from|$to');
      final st = j['responseStatus'];
      if (st.toString() != '200') throw j['responseDetails']?.toString() ?? 'Error del traductor ($st)';
      if (mounted) setState(() => out = j['responseData']['translatedText'] as String);
    } catch (e) {
      if (mounted) setState(() { error = '$e'; out = ''; });
    }
    if (mounted) setState(() => loading = false);
  }

  Widget _dd(String v, void Function(String) f) => Expanded(
      child: DropdownButtonFormField<String>(
          value: v,
          items: [for (final e in _langs.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
          onChanged: (x) { if (x != null) setState(() => f(x)); }));

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Traductor',
      maxWidth: 700,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          _dd(from, (x) => from = x),
          IconButton(icon: const Icon(Icons.swap_horiz_rounded), onPressed: () => setState(() { final t = from; from = to; to = t; if (out.isNotEmpty) { c.text = out; out = ''; } })),
          _dd(to, (x) => to = x),
        ]),
        const SizedBox(height: 12),
        TextField(controller: c, maxLines: 6, maxLength: 500, decoration: const InputDecoration(hintText: 'Escribe el texto…')),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Traducir', icon: Icons.translate_rounded, onTap: loading ? null : _go)),
        const SizedBox(height: 16),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (out.isNotEmpty) GlassCard(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: SelectableText(out, style: const TextStyle(fontSize: 18))), IconButton(icon: const Icon(Icons.copy_rounded), onPressed: () => copy(context, out))])),
        const SizedBox(height: 8),
        Text('Servicio: MyMemory (gratuito, cuota diaria limitada).', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
      ]));
}
