import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/glass.dart';

String _hex(Color c) => '#${c.value.toRadixString(16).substring(2).toUpperCase()}';

double _lum(Color c) {
  double f(double v) => v <= .03928 ? v / 12.92 : math.pow((v + .055) / 1.055, 2.4).toDouble();
  return .2126 * f(c.red / 255) + .7152 * f(c.green / 255) + .0722 * f(c.blue / 255);
}

double _contrast(Color a, Color b) {
  final x = _lum(a), y = _lum(b);
  return (math.max(x, y) + .05) / (math.min(x, y) + .05);
}

/// Generador de paletas (armonías en HSL) con contraste WCAG.
class PaletteTool extends StatefulWidget {
  const PaletteTool({super.key});
  @override
  State<PaletteTool> createState() => _P();
}

class _P extends State<PaletteTool> {
  double h = 230, s = .7, l = .55;
  final hex = TextEditingController();

  Color _c(double dh, [double? ss, double? ll]) => HSLColor.fromAHSL(1, (h + dh) % 360, (ss ?? s).clamp(0.0, 1.0).toDouble(), (ll ?? l).clamp(0.0, 1.0).toDouble()).toColor();

  void _fromHex(String v) {
    final t = v.replaceAll('#', '').trim();
    if (t.length != 6) return;
    final n = int.tryParse(t, radix: 16);
    if (n == null) return;
    final hsl = HSLColor.fromColor(Color(0xFF000000 | n));
    setState(() { h = hsl.hue; s = hsl.saturation; l = hsl.lightness; });
  }

  Widget _row(String name, List<Color> cs) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Row(children: [
          for (final c in cs)
            Expanded(
                child: GestureDetector(
                    onTap: () => copy(context, _hex(c)),
                    child: Container(height: 64, margin: const EdgeInsets.only(right: 6), decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(14)), alignment: Alignment.center, child: Text(_hex(c), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _lum(c) > .4 ? Colors.black : Colors.white))))),
        ]),
      ]));

  @override
  Widget build(BuildContext context) {
    final base = _c(0);
    return GlassPage(
        title: 'Paletas de color',
        maxWidth: 700,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            Container(width: 56, height: 56, decoration: BoxDecoration(color: base, borderRadius: BorderRadius.circular(16))),
            const SizedBox(width: 12),
            Expanded(child: TextField(controller: hex, onChanged: _fromHex, decoration: InputDecoration(hintText: _hex(base)))),
          ]),
          Slider(value: h, min: 0, max: 359, onChanged: (v) => setState(() => h = v)),
          Slider(value: s, min: 0, max: 1, onChanged: (v) => setState(() => s = v)),
          Slider(value: l, min: .05, max: .95, onChanged: (v) => setState(() => l = v)),
          _row('Complementario', [_c(0), _c(180)]),
          _row('Análogo', [_c(-30), _c(0), _c(30)]),
          _row('Triada', [_c(0), _c(120), _c(240)]),
          _row('Tétrada', [_c(0), _c(90), _c(180), _c(270)]),
          _row('Monocromático', [for (final x in [.15, .3, .45, .6, .75, .9]) _c(0, s, x)]),
          GlassCard(child: Text('Contraste del color base: ${_contrast(base, Colors.white).toStringAsFixed(2)}:1 con blanco · ${_contrast(base, Colors.black).toStringAsFixed(2)}:1 con negro (WCAG AA texto normal ≥ 4.5).')),
        ]));
  }
}
