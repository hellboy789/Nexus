import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

/// Pwned Passwords (HIBP) con k-anonymity: solo se envían 5 caracteres del hash SHA-1.
class PwnedTool extends StatefulWidget {
  const PwnedTool({super.key});
  @override
  State<PwnedTool> createState() => _PW();
}

class _PW extends State<PwnedTool> {
  final c = TextEditingController();
  bool loading = false, hide = true;
  String? error, result;
  bool? bad;

  Future<void> _run() async {
    if (c.text.isEmpty) return;
    setState(() { loading = true; error = null; result = null; bad = null; });
    try {
      final h = sha1.convert(utf8.encode(c.text)).toString().toUpperCase();
      final pre = h.substring(0, 5), suf = h.substring(5);
      final r = await httpGet('https://api.pwnedpasswords.com/range/$pre', headers: {'Add-Padding': 'true'});
      var n = 0;
      for (final l in const LineSplitter().convert(utf8.decode(r.bodyBytes))) {
        final p = l.trim().split(':');
        if (p.length == 2 && p[0] == suf) n = int.tryParse(p[1]) ?? 0;
      }
      bad = n > 0;
      result = n > 0 ? 'Aparece $n veces en filtraciones conocidas. No la uses.' : 'No aparece en la base Pwned Passwords. Eso no garantiza que sea segura.';
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Filtraciones de contraseña',
      maxWidth: 600,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: c, obscureText: hide, onSubmitted: (_) => _run(), decoration: InputDecoration(hintText: 'Contraseña a comprobar', suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_rounded : Icons.visibility_off_rounded), onPressed: () => setState(() => hide = !hide)))),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Comprobar', icon: Icons.shield_outlined, onTap: loading ? null : _run)),
        const SizedBox(height: 12),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (result != null) GlassCard(child: Text(result!, style: TextStyle(fontWeight: FontWeight.w700, color: bad == true ? Colors.redAccent : Colors.greenAccent))),
        const SizedBox(height: 8),
        Text('Privacidad: se calcula SHA-1 en tu dispositivo y solo se envían los 5 primeros caracteres a api.pwnedpasswords.com (k-anonymity). La contraseña nunca sale del dispositivo.', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
      ]));
}
