import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/db.dart';
import '../core/glass.dart';

/// Tareas guardadas en la tabla settings (clave 'tasks', JSON).
class TasksTool extends StatefulWidget {
  const TasksTool({super.key});
  @override
  State<TasksTool> createState() => _TK();
}

class _TK extends State<TasksTool> {
  List<Map<String, dynamic>> tasks = [];
  final c = TextEditingController();
  DateTime? due;

  @override
  void initState() {
    super.initState();
    NexusDb.getSetting('tasks').then((s) {
      if (s != null && mounted) setState(() => tasks = (jsonDecode(s) as List).map((e) => Map<String, dynamic>.from(e)).toList());
    });
  }

  void _save() => NexusDb.setSetting('tasks', jsonEncode(tasks));

  void _add() {
    if (c.text.trim().isEmpty) return;
    setState(() {
      tasks.insert(0, {'t': c.text.trim(), 'done': false, 'due': due?.toIso8601String()});
      c.clear();
      due = null;
    });
    _save();
  }

  @override
  Widget build(BuildContext context) {
    final sorted = [...tasks]..sort((a, b) => (a['done'] == b['done']) ? 0 : (a['done'] ? 1 : -1));
    return GlassPage(
        title: 'Tareas',
        maxWidth: 700,
        child: Column(children: [
          Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Expanded(child: TextField(controller: c, onSubmitted: (_) => _add(), decoration: const InputDecoration(hintText: 'Nueva tarea…'))),
                IconButton(
                    icon: Icon(Icons.event_rounded, color: due != null ? Theme.of(context).colorScheme.primary : null),
                    tooltip: due == null ? 'Fecha límite' : due.toString().substring(0, 10),
                    onPressed: () async {
                      final d = await showDatePicker(context: context, firstDate: DateTime.now().subtract(const Duration(days: 1)), lastDate: DateTime.now().add(const Duration(days: 3650)), initialDate: DateTime.now());
                      if (d != null) setState(() => due = d);
                    }),
                IconButton.filled(icon: const Icon(Icons.add_rounded), onPressed: _add),
              ])),
          Expanded(
              child: sorted.isEmpty
                  ? const Center(child: Text('Sin tareas'))
                  : ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [
                      for (final t in sorted)
                        Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: GlassCard(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                child: Row(children: [
                                  Checkbox(value: t['done'], onChanged: (v) { setState(() => t['done'] = v); _save(); }),
                                  Expanded(
                                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text(t['t'], style: TextStyle(decoration: t['done'] ? TextDecoration.lineThrough : null)),
                                    if (t['due'] != null)
                                      Text('Vence: ${(t['due'] as String).substring(0, 10)}', style: TextStyle(fontSize: 12, color: !t['done'] && DateTime.parse(t['due']).isBefore(DateTime.now().subtract(const Duration(days: 1))) ? Colors.redAccent : Theme.of(context).hintColor)),
                                  ])),
                                  IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () { setState(() => tasks.remove(t)); _save(); }),
                                ]))),
                    ])),
        ]));
  }
}
