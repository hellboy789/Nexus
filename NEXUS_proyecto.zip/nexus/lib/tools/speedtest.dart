import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/glass.dart';

class SpeedTestTool extends StatefulWidget {
  const SpeedTestTool({super.key});
  @override
  State<SpeedTestTool> createState() => _S();
}

class _S extends State<SpeedTestTool> {
  double? ping, down, up;
  String status = 'Listo para medir';
  bool busy = false;
  void _s(VoidCallback f) {
    if (mounted) setState(f);
  }

  Future<void> _run() async {
    _s(() {
      busy = true;
      ping = down = up = null;
      status = 'Midiendo latencia…';
    });
    try {
      final times = <int>[];
      for (var i = 0; i < 5; i++) {
        final sw = Stopwatch()..start();
        await http.get(Uri.parse('https://speed.cloudflare.com/__down?bytes=0'));
        times.add(sw.elapsedMilliseconds);
      }
      times.sort();
      _s(() {
        ping = times[2].toDouble();
        status = 'Midiendo descarga…';
      });
      final client = http.Client();
      final sw = Stopwatch()..start();
      var total = 0, last = 0;
      final res = await client.send(http.Request('GET', Uri.parse('https://speed.cloudflare.com/__down?bytes=25000000')));
      await for (final c in res.stream) {
        total += c.length;
        if (sw.elapsedMilliseconds - last > 200) {
          last = sw.elapsedMilliseconds;
          _s(() => down = total * 8 / (sw.elapsedMicroseconds / 1e6) / 1e6);
        }
        if (sw.elapsed.inSeconds >= 10) break;
      }
      final d = total * 8 / (sw.elapsedMicroseconds / 1e6) / 1e6;
      client.close();
      _s(() {
        down = d;
        status = 'Midiendo subida…';
      });
      final sw2 = Stopwatch()..start();
      const n = 8 * 1024 * 1024;
      await http.post(Uri.parse('https://speed.cloudflare.com/__up'), body: Uint8List(n));
      final u = n * 8 / (sw2.elapsedMicroseconds / 1e6) / 1e6;
      _s(() {
        up = u;
        status = 'Completado';
      });
    } catch (e) {
      _s(() => status = 'Error: $e');
    }
    _s(() => busy = false);
  }

  Widget _tile(String l, String v, String unit) => Expanded(
      child: GlassCard(
          child: Column(children: [
        Text(l, style: TextStyle(color: Theme.of(context).hintColor)),
        const SizedBox(height: 6),
        Text(v, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        Text(unit, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
      ])));

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Velocidad',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            _tile('Ping', ping?.toStringAsFixed(0) ?? '–', 'ms'),
            const SizedBox(width: 12),
            _tile('Bajada', down?.toStringAsFixed(1) ?? '–', 'Mbps'),
            const SizedBox(width: 12),
            _tile('Subida', up?.toStringAsFixed(1) ?? '–', 'Mbps'),
          ]),
          const SizedBox(height: 20),
          Center(child: Text(status)),
          const SizedBox(height: 16),
          Center(child: GlassButton(busy ? 'Midiendo…' : 'Iniciar test', icon: Icons.play_arrow_rounded, onTap: busy ? null : _run)),
          const SizedBox(height: 16),
          Center(child: Text('Usa speed.cloudflare.com (≈25 MB de descarga).', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12))),
        ]),
      );
}
