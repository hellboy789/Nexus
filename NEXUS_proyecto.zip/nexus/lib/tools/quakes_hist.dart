import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

/// Sismicidad histórica (USGS FDSN). status=reviewed -> Confirmado; automatic -> Preliminar.
class QuakesHistTool extends StatefulWidget {
  const QuakesHistTool({super.key});
  @override
  State<QuakesHistTool> createState() => _QH();
}

class _QH extends State<QuakesHistTool> {
  int from = 2000, to = DateTime.now().year;
  double minMag = 7;
  bool loading = false;
  String? error, info;
  List<Map> items = [];

  Future<void> _run() async {
    setState(() { loading = true; error = null; items = []; info = null; });
    try {
      final u = 'https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&orderby=magnitude&limit=100&minmagnitude=$minMag&starttime=$from-01-01&endtime=${to + 1}-01-01';
      final j = await getJson(u, ttl: const Duration(minutes: 30), timeout: const Duration(seconds: 25));
      items = [for (final f in (j['features'] as List)) Map<String, dynamic>.from(f['properties'])];
      info = '${items.length} sismos (máx. 100, por magnitud) · Fuente: USGS · consulta ${DateTime.now().toIso8601String().substring(0, 16)}';
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Sismicidad histórica',
      maxWidth: 800,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: DropdownButton<int>(isExpanded: true, value: from, items: [for (var y = DateTime.now().year; y >= 1950; y--) DropdownMenuItem(value: y, child: Text('Desde $y'))], onChanged: (v) => setState(() { from = v!; if (to < from) to = from; }))),
          const SizedBox(width: 8),
          Expanded(child: DropdownButton<int>(isExpanded: true, value: to, items: [for (var y = DateTime.now().year; y >= from; y--) DropdownMenuItem(value: y, child: Text('Hasta $y'))], onChanged: (v) => setState(() => to = v!))),
        ]),
        Wrap(spacing: 6, children: [for (final m in [5.0, 6.0, 7.0, 8.0]) ChoiceChip(label: Text('M ≥ ${m.toInt()}'), selected: minMag == m, onSelected: (_) => setState(() => minMag = m))]),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Consultar USGS', icon: Icons.search_rounded, onTap: loading ? null : _run)),
        const SizedBox(height: 8),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (info != null) Text(info!, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
        for (final p in items)
          GlassCard(
              child: Row(children: [
            Text('M${(p['mag'] as num?)?.toStringAsFixed(1) ?? '?'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${p['place'] ?? 'Sin ubicación'}'),
              Text('${DateTime.fromMillisecondsSinceEpoch((p['time'] as num).toInt(), isUtc: true).toIso8601String().substring(0, 10)} · ${p['status'] == 'reviewed' ? 'Confirmado' : 'Preliminar'}', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
            ])),
          ])),
      ]));
}
