import 'package:flutter/material.dart';
import '../core/db.dart';
import '../core/glass.dart';

class NotesTool extends StatefulWidget {
  const NotesTool({super.key});
  @override
  State<NotesTool> createState() => _S();
}

class _S extends State<NotesTool> {
  List<Map<String, Object?>> notes = [];
  String q = '';
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final n = await NexusDb.notes(q);
    if (mounted) setState(() => notes = n);
  }

  Future<void> _edit([Map<String, Object?>? n]) async {
    final t = TextEditingController(text: n?['title'] as String? ?? '');
    final b = TextEditingController(text: n?['body'] as String? ?? '');
    final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              title: Text(n == null ? 'Nueva nota' : 'Editar nota'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: t, decoration: const InputDecoration(hintText: 'Título')),
                const SizedBox(height: 10),
                TextField(controller: b, minLines: 4, maxLines: 8, decoration: const InputDecoration(hintText: 'Contenido')),
              ]),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
                FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Guardar')),
              ],
            ));
    if (ok == true && (t.text.trim().isNotEmpty || b.text.trim().isNotEmpty)) {
      await NexusDb.saveNote(id: n?['id'] as int?, title: t.text.trim(), body: b.text.trim());
      _load();
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Notas',
        actions: [IconButton(icon: const Icon(Icons.add_rounded), onPressed: () => _edit())],
        child: Column(children: [
          Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: TextField(
                  decoration: const InputDecoration(hintText: 'Buscar…', prefixIcon: Icon(Icons.search_rounded)),
                  onChanged: (v) {
                    q = v;
                    _load();
                  })),
          Expanded(
              child: notes.isEmpty
                  ? const Center(child: Text('Sin notas. Pulsa + para crear una.'))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: notes.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (_, i) {
                        final n = notes[i];
                        return GlassCard(
                            onTap: () => _edit(n),
                            child: Row(children: [
                              Expanded(
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                if ((n['title'] as String).isNotEmpty)
                                  Text(n['title'] as String, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                                if ((n['body'] as String).isNotEmpty)
                                  Text(n['body'] as String, maxLines: 4, overflow: TextOverflow.ellipsis),
                              ])),
                              IconButton(
                                  icon: const Icon(Icons.delete_outline_rounded),
                                  onPressed: () async {
                                    await NexusDb.deleteNote(n['id'] as int);
                                    _load();
                                  }),
                            ]));
                      })),
        ]),
      );
}
