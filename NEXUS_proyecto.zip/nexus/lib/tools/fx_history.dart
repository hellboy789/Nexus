import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';
import '../core/spark.dart';

/// Divisas históricas (Frankfurter / BCE).
class FxHistoryTool extends StatefulWidget {
  const FxHistoryTool({super.key});
  @override
  State<FxHistoryTool> createState() => _FX();
}

class _FX extends State<FxHistoryTool> {
  final a = TextEditingController(text: 'EUR'), b = TextEditingController(text: 'USD');
  int days = 365;
  bool loading = false;
  String? error;
  List<double> v = [];
  String info = '';

  Future<void> _run() async {
    final f = a.text.trim().toUpperCase(), t = b.text.trim().toUpperCase();
    if (f.length != 3 || t.length != 3) return setState(() => error = 'Usa códigos de 3 letras (EUR, USD…).');
    setState(() { loading = true; error = null; v = []; });
    try {
      final end = DateTime.now(), st = end.subtract(Duration(days: days));
      String d(DateTime x) => x.toIso8601String().substring(0, 10);
      final j = await getJson('https://api.frankfurter.dev/v1/${d(st)}..${d(end)}?base=$f&symbols=$t', ttl: const Duration(hours: 1), timeout: const Duration(seconds: 20));
      final rates = Map<String, dynamic>.from(j['rates'] as Map);
      final keys = rates.keys.toList()..sort();
      v = [for (final k in keys) (rates[k][t] as num).toDouble()];
      if (v.isEmpty) throw NetError('Sin datos para $f→$t.');
      final lo = v.reduce((x, y) => x < y ? x : y), hi = v.reduce((x, y) => x > y ? x : y);
      info = '$f→$t · ${keys.first} a ${keys.last}\nÚltimo: ${v.last.toStringAsFixed(4)} · Mín: ${lo.toStringAsFixed(4)} · Máx: ${hi.toStringAsFixed(4)} · Var.: ${((v.last / v.first - 1) * 100).toStringAsFixed(2)} %\nFuente: BCE vía Frankfurter (datos oficiales de referencia, días hábiles)';
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  void dispose() {
    a.dispose();
    b.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Divisas históricas',
      maxWidth: 700,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Expanded(child: TextField(controller: a, decoration: const InputDecoration(labelText: 'De'))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: b, decoration: const InputDecoration(labelText: 'A'))),
        ]),
        const SizedBox(height: 8),
        Wrap(spacing: 6, children: [for (final d in [30, 90, 365, 1825]) ChoiceChip(label: Text(d < 365 ? '$d días' : '${d ~/ 365} año${d > 365 ? 's' : ''}'), selected: days == d, onSelected: (_) => setState(() => days = d))]),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Ver evolución', icon: Icons.search_rounded, onTap: loading ? null : _run)),
        const SizedBox(height: 12),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (v.isNotEmpty) GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Spark(v), const SizedBox(height: 8), Text(info)])),
      ]));
}
