import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

/// Fase lunar calculada (algoritmo de mes sinódico, precisión ≈ ±1 día).
({double age, double illum, String name}) moonPhase(DateTime d) {
  final jd = d.toUtc().millisecondsSinceEpoch / 86400000 + 2440587.5;
  const syn = 29.530588853;
  final age = (((jd - 2451550.1) % syn) + syn) % syn;
  final illum = (1 - math.cos(2 * math.pi * age / syn)) / 2;
  final n = age < 1.85 ? 'Luna nueva' : age < 5.54 ? 'Creciente' : age < 9.23 ? 'Cuarto creciente' : age < 12.92 ? 'Gibosa creciente' : age < 16.61 ? 'Luna llena' : age < 20.30 ? 'Gibosa menguante' : age < 23.99 ? 'Cuarto menguante' : age < 27.68 ? 'Menguante' : 'Luna nueva';
  return (age: age, illum: illum, name: n);
}

/// Sol, UV (Open-Meteo, 7 días) y fase lunar calculada.
class AstroTool extends StatefulWidget {
  const AstroTool({super.key});
  @override
  State<AstroTool> createState() => _A();
}

class _A extends State<AstroTool> {
  Place? place;
  Map? d;
  String? error;
  bool loading = false;

  Future<void> _load(Place p) async {
    setState(() { place = p; loading = true; error = null; });
    try {
      final j = await getJson('https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&daily=sunrise,sunset,daylight_duration,uv_index_max&forecast_days=7&timezone=auto', ttl: const Duration(minutes: 30));
      d = j['daily'] as Map;
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  String _tm(dynamic s) => '$s'.split('T').last;
  String _uv(num u) => u < 3 ? 'bajo' : u < 6 ? 'moderado' : u < 8 ? 'alto' : u < 11 ? 'muy alto' : 'extremo';

  @override
  Widget build(BuildContext context) {
    final m = moonPhase(DateTime.now());
    return GlassPage(
        title: 'Sol, UV y luna',
        maxWidth: 700,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          PlaceBar(onPlace: _load),
          const SizedBox(height: 12),
          GlassCard(child: Row(children: [
            const Icon(Icons.nightlight_round, size: 40),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text('Iluminación ${(m.illum * 100).round()}% · edad ${m.age.toStringAsFixed(1)} días'),
              Text('Valor calculado (±1 día), no medido.', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
            ])),
          ])),
          const SizedBox(height: 12),
          if (loading) const Center(child: CircularProgressIndicator()),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
          if (place == null && !loading) const Center(child: Text('Elige un lugar para ver amanecer, atardecer y UV')),
          if (d != null)
            for (var i = 0; i < (d!['time'] as List).length; i++)
              Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: GlassCard(
                      child: Row(children: [
                    SizedBox(width: 64, child: Text('${(d!['time'] as List)[i]}'.substring(5), style: const TextStyle(fontWeight: FontWeight.w700))),
                    const Icon(Icons.wb_twilight_rounded, size: 18),
                    Text(' ${_tm((d!['sunrise'] as List)[i])}  '),
                    const Icon(Icons.nights_stay_rounded, size: 18),
                    Text(' ${_tm((d!['sunset'] as List)[i])}'),
                    const Spacer(),
                    Text('UV ${((d!['uv_index_max'] as List)[i] as num).toStringAsFixed(1)} (${_uv((d!['uv_index_max'] as List)[i] as num)})'),
                  ]))),
          Text('Datos: Open-Meteo.com (CC BY 4.0). Horas locales del lugar.', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
        ]));
  }
}
