import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';
import '../core/spark.dart';

/// Clima histórico (Open-Meteo Archive, reanálisis ERA5).
class ClimateHistTool extends StatefulWidget {
  const ClimateHistTool({super.key});
  @override
  State<ClimateHistTool> createState() => _CH();
}

class _CH extends State<ClimateHistTool> {
  Place? place;
  int year = DateTime.now().year - 1;
  bool loading = false;
  String? error;
  List<double> tmax = [], tmin = [];
  Map<String, String> kv = {};

  Future<void> _run() async {
    if (place == null) return;
    setState(() { loading = true; error = null; kv = {}; });
    try {
      final j = await getJson('https://archive-api.open-meteo.com/v1/archive?latitude=${place!.lat}&longitude=${place!.lon}&start_date=$year-01-01&end_date=$year-12-31&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto', ttl: const Duration(hours: 6), timeout: const Duration(seconds: 25));
      final d = j['daily'] as Map;
      double? n(x) => (x as num?)?.toDouble();
      tmax = [for (final x in d['temperature_2m_max']) n(x) ?? 0];
      tmin = [for (final x in d['temperature_2m_min']) n(x) ?? 0];
      final pr = [for (final x in d['precipitation_sum']) n(x) ?? 0];
      final hi = tmax.reduce((x, y) => x > y ? x : y), lo = tmin.reduce((x, y) => x < y ? x : y);
      final rain = pr.fold<double>(0, (s, x) => s + x);
      kv = {
        'Lugar / año': '${place!.name} · $year',
        'Temp. máx. absoluta': '${hi.toStringAsFixed(1)} °C',
        'Temp. mín. absoluta': '${lo.toStringAsFixed(1)} °C',
        'Media de máximas': '${(tmax.reduce((x, y) => x + y) / tmax.length).toStringAsFixed(1)} °C',
        'Precipitación total': '${rain.toStringAsFixed(0)} mm',
        'Días con lluvia ≥1 mm': '${pr.where((x) => x >= 1).length}',
        'Fuente': 'Open-Meteo Archive (reanálisis, no estación local) · Confirmado salvo últimos días',
      };
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Clima histórico',
      maxWidth: 700,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        PlaceBar(onPlace: (p) { place = p; _run(); }),
        DropdownButton<int>(isExpanded: true, value: year, items: [for (var y = DateTime.now().year; y >= 1950; y--) DropdownMenuItem(value: y, child: Text('Año $y'))], onChanged: (v) { setState(() => year = v!); _run(); }),
        if (place == null) const Text('Busca una ciudad para ver su año.'),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (kv.isNotEmpty) ...[
          GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Máximas diarias (°C)'),
            Spark(tmax, color: Colors.orangeAccent),
            const SizedBox(height: 8),
            const Text('Mínimas diarias (°C)'),
            Spark(tmin, color: Colors.lightBlueAccent),
          ])),
          KV(kv),
        ],
      ]));
}
