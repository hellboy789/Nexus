import 'dart:math';
import 'package:flutter/material.dart';
import '../core/glass.dart';

class PasswordTool extends StatefulWidget {
  const PasswordTool({super.key});
  @override
  State<PasswordTool> createState() => _S();
}

class _S extends State<PasswordTool> {
  double len = 20;
  bool lower = true, upper = true, digits = true, symbols = true;
  String pass = '';
  static final _r = Random.secure();

  @override
  void initState() {
    super.initState();
    _gen();
  }

  List<String> get _sets => [
        if (lower) 'abcdefghijklmnopqrstuvwxyz',
        if (upper) 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        if (digits) '0123456789',
        if (symbols) '!@#\$%^&*()-_=+[]{};:,.<>?',
      ];

  void _gen() {
    final sets = _sets;
    if (sets.isEmpty) {
      setState(() => pass = '');
      return;
    }
    final all = sets.join();
    final chars = <String>[for (final s in sets) s[_r.nextInt(s.length)]];
    while (chars.length < len.round()) {
      chars.add(all[_r.nextInt(all.length)]);
    }
    chars.shuffle(_r);
    setState(() => pass = chars.take(len.round()).join());
  }

  String get _strength {
    final pool = _sets.join().length;
    if (pool == 0) return '–';
    final bits = len.round() * (log(pool) / ln2);
    final l = bits < 40 ? 'Débil' : bits < 60 ? 'Media' : bits < 80 ? 'Fuerte' : 'Muy fuerte';
    return '$l · ${bits.toStringAsFixed(0)} bits';
  }

  Widget _sw(String l, bool v, ValueChanged<bool> f) => SwitchListTile(title: Text(l), value: v, onChanged: (x) {
        f(x);
        _gen();
      });

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Contraseñas',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          GlassCard(
              child: Column(children: [
            SelectableText(pass.isEmpty ? 'Elige al menos un tipo' : pass, textAlign: TextAlign.center, style: const TextStyle(fontFamily: 'monospace', fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(_strength, style: TextStyle(color: Theme.of(context).hintColor)),
          ])),
          const SizedBox(height: 12),
          GlassCard(
              child: Column(children: [
            Row(children: [const Text('Longitud'), const Spacer(), Text('${len.round()}')]),
            Slider(value: len, min: 6, max: 64, onChanged: (v) {
              setState(() => len = v);
              _gen();
            }),
            _sw('Minúsculas', lower, (v) => lower = v),
            _sw('Mayúsculas', upper, (v) => upper = v),
            _sw('Números', digits, (v) => digits = v),
            _sw('Símbolos', symbols, (v) => symbols = v),
          ])),
          const SizedBox(height: 12),
          Wrap(spacing: 10, children: [
            GlassButton('Generar', icon: Icons.refresh_rounded, onTap: _gen),
            GlassButton('Copiar', icon: Icons.copy_rounded, onTap: pass.isEmpty ? null : () => copy(context, pass)),
          ]),
        ]),
      );
}
