import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/glass.dart';
import '../core/net.dart';

String wmoText(int c) {
  if (c == 0) return 'Despejado';
  if (c <= 2) return 'Poco nuboso';
  if (c == 3) return 'Nublado';
  if (c == 45 || c == 48) return 'Niebla';
  if (c >= 51 && c <= 57) return 'Llovizna';
  if (c >= 61 && c <= 67) return 'Lluvia';
  if (c >= 71 && c <= 77) return 'Nieve';
  if (c >= 80 && c <= 82) return 'Chubascos';
  if (c == 85 || c == 86) return 'Chubascos de nieve';
  if (c >= 95) return 'Tormenta';
  return 'Variable';
}

IconData wmoIcon(int c) {
  if (c == 0) return Icons.wb_sunny_rounded;
  if (c <= 2) return Icons.wb_cloudy_rounded;
  if (c == 3) return Icons.cloud_rounded;
  if (c == 45 || c == 48) return Icons.blur_on_rounded;
  if (c >= 71 && c <= 77) return Icons.ac_unit_rounded;
  if (c >= 95) return Icons.thunderstorm_rounded;
  return Icons.grain_rounded;
}

class WeatherTool extends StatefulWidget {
  const WeatherTool({super.key});
  @override
  State<WeatherTool> createState() => _W();
}

class _W extends State<WeatherTool> {
  Place? place;
  Map? data;
  String? error;
  bool loading = false;

  Future<void> _load(Place p) async {
    setState(() {
      place = p;
      loading = true;
      error = null;
    });
    try {
      final j = await getJson('https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}'
          '&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,precipitation,is_day'
          '&hourly=temperature_2m,precipitation_probability,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_gusts_10m_max,uv_index_max'
          '&forecast_days=7&timezone=auto');
      if (mounted) setState(() => data = j as Map);
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    }
    if (mounted) setState(() => loading = false);
  }

  /// Avisos calculados a partir de la previsión (NO son avisos oficiales).
  List<String> _alerts() {
    final d = data!['daily'] as Map;
    final t = (d['time'] as List);
    final out = <String>[];
    for (var i = 0; i < t.length; i++) {
      double n(String k) => ((d[k] as List)[i] as num?)?.toDouble() ?? 0;
      final day = t[i];
      if (n('precipitation_sum') >= 30) out.add('$day · Lluvia intensa: ${n('precipitation_sum').toStringAsFixed(0)} mm');
      if (n('wind_gusts_10m_max') >= 70) out.add('$day · Rachas fuertes: ${n('wind_gusts_10m_max').toStringAsFixed(0)} km/h');
      if (n('temperature_2m_max') >= 38) out.add('$day · Calor extremo: ${n('temperature_2m_max').toStringAsFixed(0)} °C');
      if (n('temperature_2m_min') <= -5) out.add('$day · Frío intenso: ${n('temperature_2m_min').toStringAsFixed(0)} °C');
      if (n('uv_index_max') >= 8) out.add('$day · Índice UV muy alto: ${n('uv_index_max').toStringAsFixed(0)}');
      if (((d['weather_code'] as List)[i] as num) >= 95) out.add('$day · Posibles tormentas');
    }
    return out;
  }

  Widget _forecast() {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (error != null) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center)));
    if (data == null) return const Center(child: Text('Busca una ciudad o usa tu ubicación'));
    final c = data!['current'] as Map, h = data!['hourly'] as Map, d = data!['daily'] as Map;
    final now = DateTime.now();
    final ht = (h['time'] as List).map((e) => DateTime.parse(e as String)).toList();
    var start = ht.indexWhere((x) => x.isAfter(now.subtract(const Duration(hours: 1))));
    if (start < 0) start = 0;
    final alerts = _alerts();
    return ListView(padding: const EdgeInsets.all(16), children: [
      GlassCard(
          child: Row(children: [
        Icon(wmoIcon(c['weather_code']), size: 64),
        const SizedBox(width: 16),
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(place!.name, style: const TextStyle(fontWeight: FontWeight.w700)),
          Text('${(c['temperature_2m'] as num).round()}°', style: const TextStyle(fontSize: 52, fontWeight: FontWeight.w800)),
          Text('${wmoText(c['weather_code'])} · sensación ${(c['apparent_temperature'] as num).round()}°'),
          Text('Humedad ${c['relative_humidity_2m']}% · Viento ${c['wind_speed_10m']} km/h'),
        ])),
      ])),
      const SizedBox(height: 12),
      GlassCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.warning_amber_rounded),
          const SizedBox(width: 8),
          Text(alerts.isEmpty ? 'Sin avisos en la previsión' : 'Avisos de la previsión', style: const TextStyle(fontWeight: FontWeight.w700))
        ]),
        for (final a in alerts) Padding(padding: const EdgeInsets.only(top: 6), child: Text(a)),
        const SizedBox(height: 6),
        Text('Calculados con umbrales sobre la previsión de Open-Meteo. No son avisos oficiales: consulta a tu agencia meteorológica nacional.',
            style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
      ])),
      const SizedBox(height: 12),
      SizedBox(
          height: 128,
          child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: (ht.length - start).clamp(0, 48),
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final k = start + i;
                return SizedBox(
                    width: 76,
                    child: GlassCard(
                        padding: const EdgeInsets.all(8),
                        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('${ht[k].hour.toString().padLeft(2, '0')}h'),
                          Icon(wmoIcon((h['weather_code'] as List)[k]), size: 24),
                          Text('${((h['temperature_2m'] as List)[k] as num).round()}°', style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text('${(h['precipitation_probability'] as List)[k] ?? 0}%', style: const TextStyle(fontSize: 11)),
                        ])));
              })),
      const SizedBox(height: 12),
      for (var i = 0; i < (d['time'] as List).length; i++)
        Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  SizedBox(width: 90, child: Text((d['time'] as List)[i].toString().substring(5))),
                  Icon(wmoIcon((d['weather_code'] as List)[i])),
                  const SizedBox(width: 8),
                  Expanded(child: Text('${(d['precipitation_probability_max'] as List)[i] ?? 0}% · ${(d['precipitation_sum'] as List)[i]} mm', style: const TextStyle(fontSize: 12))),
                  Text('${((d['temperature_2m_min'] as List)[i] as num).round()}° / ${((d['temperature_2m_max'] as List)[i] as num).round()}°', style: const TextStyle(fontWeight: FontWeight.w700)),
                ]))),
      Text('Datos: Open-Meteo.com (CC BY 4.0)', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
    ]);
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 2,
      child: GlassPage(
          title: 'Clima y radar',
          maxWidth: 1000,
          bottom: const TabBar(tabs: [Tab(text: 'Previsión'), Tab(text: 'Radar')]),
          child: Column(children: [
            Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0), child: PlaceBar(onPlace: _load)),
            Expanded(child: TabBarView(children: [_forecast(), RadarMap(center: place == null ? null : LatLng(place!.lat, place!.lon))])),
          ])));
}

/// Radar de precipitación en tiempo real (RainViewer, sin API key) sobre OpenStreetMap.
class RadarMap extends StatefulWidget {
  const RadarMap({super.key, this.center});
  final LatLng? center;
  @override
  State<RadarMap> createState() => _R();
}

class _R extends State<RadarMap> {
  final ctrl = MapController();
  List<String> paths = [];
  List<int> times = [];
  String host = '';
  int idx = 0;
  bool playing = false;
  String? error;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant RadarMap o) {
    super.didUpdateWidget(o);
    if (widget.center != null && widget.center != o.center) ctrl.move(widget.center!, 7);
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final j = await getJson('https://api.rainviewer.com/public/weather-maps.json');
      final past = (j['radar']['past'] as List);
      if (past.isEmpty) throw 'RainViewer no devolvió fotogramas de radar.';
      if (mounted) {
        setState(() {
          host = j['host'];
          paths = past.map((e) => e['path'] as String).toList();
          times = past.map((e) => e['time'] as int).toList();
          idx = paths.length - 1;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    }
  }

  void _toggle() {
    setState(() => playing = !playing);
    timer?.cancel();
    if (playing) timer = Timer.periodic(const Duration(milliseconds: 700), (_) => setState(() => idx = (idx + 1) % paths.length));
  }

  @override
  Widget build(BuildContext context) {
    if (error != null) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!)));
    final t = times.isEmpty ? null : DateTime.fromMillisecondsSinceEpoch(times[idx] * 1000);
    return Stack(children: [
      FlutterMap(mapController: ctrl, options: MapOptions(initialCenter: widget.center ?? const LatLng(40, -3), initialZoom: widget.center == null ? 5 : 7, maxZoom: 7), children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'dev.nexus.nexus'),
        if (paths.isNotEmpty) Opacity(opacity: .7, child: TileLayer(key: ValueKey(idx), urlTemplate: '$host${paths[idx]}/256/{z}/{x}/{y}/2/1_1.png', maxNativeZoom: 7)),
        const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap · Radar: RainViewer')]),
      ]),
      if (paths.isNotEmpty)
        Positioned(
            left: 12,
            right: 12,
            bottom: 28,
            child: GlassCard(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Row(children: [
                  IconButton(icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded), onPressed: _toggle),
                  Expanded(child: Slider(value: idx.toDouble(), min: 0, max: (paths.length - 1).toDouble(), divisions: paths.length > 1 ? paths.length - 1 : null, onChanged: (v) => setState(() => idx = v.round()))),
                  Text(t == null ? '' : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}'),
                ]))),
    ]);
  }
}
