import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import '../core/glass.dart';

/// Analiza enlaces y muestra metadatos públicos (oEmbed). NO descarga contenido:
/// respeta los términos de TikTok, Instagram y YouTube.
class LinksTool extends StatefulWidget {
  const LinksTool({super.key});
  @override
  State<LinksTool> createState() => _S();
}

class _S extends State<LinksTool> {
  final ctrl = TextEditingController();
  Map<String, String>? info;
  String? thumb;
  bool busy = false;

  Future<void> _analyze() async {
    final url = ctrl.text.trim();
    final u = Uri.tryParse(url);
    if (u == null || !u.hasScheme || u.host.isEmpty) {
      msg(context, 'Enlace no válido');
      return;
    }
    final h = u.host.toLowerCase();
    String plat = 'Desconocida';
    String tipo = 'Enlace';
    String? id;
    String? oembed;
    if (h.contains('youtube.com') || h.contains('youtu.be')) {
      plat = 'YouTube';
      if (h.contains('youtu.be')) {
        id = u.pathSegments.isEmpty ? null : u.pathSegments.first;
      } else if (u.path.startsWith('/shorts/')) {
        tipo = 'Short';
        id = u.pathSegments.length > 1 ? u.pathSegments[1] : null;
      } else {
        id = u.queryParameters['v'];
      }
      if (tipo == 'Enlace') tipo = 'Vídeo';
      oembed = 'https://www.youtube.com/oembed?format=json&url=${Uri.encodeComponent(url)}';
    } else if (h.contains('tiktok.com')) {
      plat = 'TikTok';
      tipo = 'Vídeo';
      final m = RegExp(r'/video/(\d+)').firstMatch(u.path);
      id = m?.group(1);
      oembed = 'https://www.tiktok.com/oembed?url=${Uri.encodeComponent(url)}';
    } else if (h.contains('instagram.com')) {
      plat = 'Instagram';
      final s = u.pathSegments;
      if (s.length >= 2) {
        tipo = {'reel': 'Reel', 'p': 'Publicación', 'tv': 'IGTV'}[s[0]] ?? 'Perfil/otro';
        id = s[1];
      }
    }
    final r = <String, String>{'Plataforma': plat, 'Tipo': tipo, if (id != null) 'ID': id};
    setState(() {
      busy = true;
      thumb = null;
      info = r;
    });
    if (oembed != null) {
      try {
        final res = await http.get(Uri.parse(oembed)).timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) {
          final j = jsonDecode(res.body) as Map<String, dynamic>;
          if (j['title'] != null) r['Título'] = '${j['title']}';
          if (j['author_name'] != null) r['Autor'] = '${j['author_name']}';
          thumb = j['thumbnail_url'] as String?;
        } else {
          r['Metadatos'] = 'No disponibles (HTTP ${res.statusCode})';
        }
      } catch (_) {
        r['Metadatos'] = 'No disponibles';
      }
    } else if (plat == 'Instagram') {
      r['Metadatos'] = 'Instagram no ofrece metadatos públicos sin API oficial';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Enlaces',
        child: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Pega un enlace de TikTok, Instagram o YouTube', prefixIcon: Icon(Icons.link_rounded))),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 10, children: [
            GlassButton(busy ? 'Analizando…' : 'Analizar', icon: Icons.search_rounded, onTap: busy ? null : _analyze),
            GlassButton('Abrir', icon: Icons.open_in_new_rounded, onTap: () {
              final u = Uri.tryParse(ctrl.text.trim());
              if (u != null && u.hasScheme) launchUrl(u, mode: LaunchMode.externalApplication);
            }),
            GlassButton('Copiar', icon: Icons.copy_rounded, onTap: () => copy(context, ctrl.text.trim())),
          ]),
          const SizedBox(height: 16),
          if (thumb != null) ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.network(thumb!, errorBuilder: (_, __, ___) => const SizedBox())),
          if (thumb != null) const SizedBox(height: 12),
          if (info != null) KV(info!),
          const SizedBox(height: 16),
          GlassCard(
              child: Text(
                  'NEXUS no descarga vídeos de estas plataformas porque sus términos lo prohíben. Para guardar contenido usa las opciones oficiales (p. ej. «Guardar vídeo» de TikTok, YouTube Premium) o descarga solo contenido propio desde tu cuenta.',
                  style: TextStyle(color: Theme.of(context).hintColor, fontSize: 13))),
        ]),
      );
}
