import 'dart:io';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/glass.dart';

class QrTool extends StatefulWidget {
  const QrTool({super.key});
  @override
  State<QrTool> createState() => _S();
}

class _S extends State<QrTool> {
  final ctrl = TextEditingController(text: 'https://');
  String? scanned;

  Widget _gen() => ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: ctrl, minLines: 1, maxLines: 4, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Texto o enlace')),
        const SizedBox(height: 20),
        Center(
            child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
                child: ctrl.text.trim().isEmpty
                    ? const SizedBox(width: 240, height: 240)
                    : QrImageView(data: ctrl.text.trim(), size: 240))),
      ]);

  Widget _scan() {
    if (!Platform.isAndroid) {
      return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('El lector con cámara solo está disponible en Android.', textAlign: TextAlign.center)));
    }
    return ListView(padding: const EdgeInsets.all(16), children: [
      ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: SizedBox(
              height: 320,
              child: MobileScanner(onDetect: (cap) {
                final v = cap.barcodes.isEmpty ? null : cap.barcodes.first.rawValue;
                if (v != null && v != scanned) setState(() => scanned = v);
              }))),
      const SizedBox(height: 16),
      if (scanned != null)
        GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SelectableText(scanned!),
          const SizedBox(height: 12),
          Wrap(spacing: 10, children: [
            GlassButton('Copiar', icon: Icons.copy_rounded, onTap: () => copy(context, scanned!)),
            if (Uri.tryParse(scanned!)?.hasScheme ?? false)
              GlassButton('Abrir', icon: Icons.open_in_new_rounded, onTap: () => launchUrl(Uri.parse(scanned!), mode: LaunchMode.externalApplication)),
          ]),
        ])),
    ]);
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 2,
      child: GlassPage(
        title: 'QR',
        bottom: const TabBar(tabs: [Tab(text: 'Generar'), Tab(text: 'Leer')]),
        child: TabBarView(children: [_gen(), _scan()]),
      ));
}
