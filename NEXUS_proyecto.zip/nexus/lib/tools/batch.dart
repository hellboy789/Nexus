import 'dart:io';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import '../core/files.dart';
import '../core/glass.dart';
import '../core/ui.dart';

/// Resultado por archivo: bytes de salida o null si no se pudo decodificar.
Uint8List? _proc(Map<String, dynamic> a) {
  var im = img.decodeImage(a['b'] as Uint8List);
  if (im == null) return null;
  im = img.bakeOrientation(im);
  final mw = a['w'] as int;
  if (mw > 0 && im.width > mw) im = img.copyResize(im, width: mw);
  if (a['gray'] as bool) im = img.grayscale(im);
  return a['fmt'] == 'png' ? Uint8List.fromList(img.encodePng(im)) : Uint8List.fromList(img.encodeJpg(im, quality: a['q'] as int));
}

/// BATCH: procesa muchas imágenes (redimensionar, convertir, renombrar) y entrega un único ZIP.
class BatchTool extends StatefulWidget {
  const BatchTool({super.key});
  @override
  State<BatchTool> createState() => _S();
}

class _S extends State<BatchTool> {
  static const maxFiles = 300;
  List<String> files = [];
  String fmt = 'jpg';
  double quality = 80, maxW = 1920;
  bool noResize = false, gray = false;
  final pattern = TextEditingController(text: '{name}');
  String status = '';
  double? progress;
  bool cancel = false;

  @override
  void dispose() {
    pattern.dispose();
    super.dispose();
  }

  String _outName(String src, int n, Set<String> used) {
    final base = p.basenameWithoutExtension(src);
    var s = pattern.text.trim().isEmpty ? '{name}' : pattern.text.trim();
    s = s.replaceAll('{name}', base).replaceAll('{n}', n.toString().padLeft(3, '0')).replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    var out = '$s.$fmt', k = 2;
    while (!used.add(out.toLowerCase())) {
      out = '${s}_${k++}.$fmt';
    }
    return out;
  }

  Future<void> _run() async {
    cancel = false;
    setState(() {
      progress = 0;
      status = '';
    });
    final arc = Archive();
    final used = <String>{};
    final errors = <String>[];
    var inBytes = 0, outBytes = 0;
    try {
      for (var i = 0; i < files.length; i++) {
        if (cancel) break;
        final f = files[i];
        try {
          final src = await File(f).readAsBytes();
          inBytes += src.length;
          final out = await compute(_proc, {'b': src, 'w': noResize ? 0 : maxW.round(), 'q': quality.round(), 'fmt': fmt, 'gray': gray});
          if (out == null) {
            errors.add('${p.basename(f)}: formato no soportado');
          } else {
            outBytes += out.length;
            arc.addFile(ArchiveFile(_outName(f, i + 1, used), out.length, out));
          }
        } catch (e) {
          errors.add('${p.basename(f)}: $e');
        }
        if (mounted) setState(() => progress = (i + 1) / files.length);
      }
      if (cancel) {
        status = 'Cancelado (nada guardado)';
      } else if (arc.isEmpty) {
        status = 'No se pudo procesar ningún archivo.\n${errors.join('\n')}';
      } else {
        final z = ZipEncoder().encode(arc) as List<int>;
        final saved = await saveBytes('nexus_batch.zip', Uint8List.fromList(z));
        status = '${arc.length} de ${files.length} procesados · ${fmtSize(inBytes)} → ${fmtSize(outBytes)}'
            '${saved == null ? '\nZIP sin guardar (cancelado)' : '\nGuardado: $saved'}'
            '${errors.isEmpty ? '' : '\nFallos (${errors.length}):\n${errors.take(10).join('\n')}'}';
      }
    } catch (e) {
      status = 'Error: $e';
    }
    if (mounted) setState(() => progress = null);
  }

  @override
  Widget build(BuildContext context) {
    final busy = progress != null;
    return GlassPage(
      title: 'BATCH',
      child: ListView(padding: const EdgeInsets.all(16), children: [
        GlassCard(child: Text(files.isEmpty ? 'Sin archivos (máx. $maxFiles). Salida: un ZIP.' : '${files.length} archivos · ${files.take(3).map(p.basename).join(', ')}${files.length > 3 ? '…' : ''}')),
        const SizedBox(height: 12),
        GlassCard(
            child: Column(children: [
          Row(children: [
            const Text('Formato'),
            const SizedBox(width: 12),
            SegmentedButton<String>(segments: const [ButtonSegment(value: 'jpg', label: Text('JPG')), ButtonSegment(value: 'png', label: Text('PNG'))], selected: {fmt}, onSelectionChanged: (s) => setState(() => fmt = s.first)),
          ]),
          if (fmt == 'jpg') ...[
            Row(children: [const Text('Calidad'), const Spacer(), Text('${quality.round()}%')]),
            Slider(value: quality, min: 10, max: 100, onChanged: (v) => setState(() => quality = v)),
          ],
          Row(children: [const Expanded(child: Text('Mantener tamaño original')), Switch(value: noResize, onChanged: (v) => setState(() => noResize = v))]),
          if (!noResize) ...[
            Row(children: [const Text('Ancho máximo'), const Spacer(), Text('${maxW.round()} px')]),
            Slider(value: maxW, min: 320, max: 4096, onChanged: (v) => setState(() => maxW = v)),
          ],
          Row(children: [const Expanded(child: Text('Blanco y negro')), Switch(value: gray, onChanged: (v) => setState(() => gray = v))]),
          TextField(controller: pattern, decoration: const InputDecoration(labelText: 'Nombre de salida', helperText: '{name} = original · {n} = número 001, 002…')),
        ])),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, children: [
          GlassButton('Elegir imágenes', icon: Icons.photo_library_rounded, onTap: busy ? null : () async {
            final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jpg', 'jpeg', 'png', 'bmp', 'gif', 'webp'], allowMultiple: true);
            if (r == null) return;
            final l = r.paths.whereType<String>().toList();
            if (l.length > maxFiles) msg(context, 'Se usarán las primeras $maxFiles');
            setState(() => files = l.take(maxFiles).toList());
          }),
          GlassButton('Procesar → ZIP', icon: Icons.archive_rounded, onTap: (files.isEmpty || busy) ? null : _run),
          if (busy) GlassButton('Cancelar', icon: Icons.stop_rounded, onTap: () => cancel = true),
        ]),
        if (busy) Padding(padding: const EdgeInsets.only(top: 16), child: LinearProgressIndicator(value: progress)),
        const SizedBox(height: 16),
        if (status.isNotEmpty) GlassCard(child: SelectableText(status)),
      ]),
    );
  }
}
