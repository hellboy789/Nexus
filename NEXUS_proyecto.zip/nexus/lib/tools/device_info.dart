import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import '../core/glass.dart';

class DeviceInfoTool extends StatefulWidget {
  const DeviceInfoTool({super.key});
  @override
  State<DeviceInfoTool> createState() => _S();
}

class _S extends State<DeviceInfoTool> {
  Map<String, String> info = {};
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final m = <String, String>{
      'Sistema': Platform.operatingSystem,
      'Versión del SO': Platform.operatingSystemVersion,
      'Núcleos CPU': '${Platform.numberOfProcessors}',
      'Idioma': Platform.localeName,
      'Dart': Platform.version.split(' ').first,
    };
    try {
      final d = (await DeviceInfoPlugin().deviceInfo).data;
      void add(String k, dynamic v) {
        if (k == 'systemFeatures' || k.contains('digitalProductId')) return;
        if (v is Map) {
          v.forEach((k2, v2) => add('$k.$k2', v2));
        } else if (v is List) {
          if (v.length <= 20) m[k] = v.join(', ');
        } else {
          m[k] = '$v';
        }
      }

      d.forEach(add);
    } catch (e) {
      m['Error'] = '$e';
    }
    if (mounted) setState(() => info = m);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Dispositivo',
        actions: [
          IconButton(
              icon: const Icon(Icons.copy_rounded),
              onPressed: () => copy(context, info.entries.map((e) => '${e.key}: ${e.value}').join('\n')))
        ],
        child: info.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : ListView(padding: const EdgeInsets.all(16), children: [KV(info)]),
      );
}
