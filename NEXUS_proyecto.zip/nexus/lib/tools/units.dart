import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';
import 'calculator.dart' show fmtNum;

class _U {
  const _U(this.name, this.f);
  final String name;
  final double f; // factor a unidad base
}

const _groups = <String, List<_U>>{
  'Longitud': [_U('m', 1), _U('km', 1000), _U('cm', .01), _U('mm', .001), _U('milla', 1609.344), _U('yarda', .9144), _U('pie', .3048), _U('pulgada', .0254)],
  'Masa': [_U('kg', 1), _U('g', .001), _U('mg', 1e-6), _U('t', 1000), _U('libra', .45359237), _U('onza', .028349523125)],
  'Volumen': [_U('L', 1), _U('mL', .001), _U('m³', 1000), _U('galón US', 3.785411784), _U('taza US', .2365882365), _U('fl oz US', .0295735295625)],
  'Área': [_U('m²', 1), _U('km²', 1e6), _U('ha', 1e4), _U('acre', 4046.8564224), _U('ft²', .09290304)],
  'Velocidad': [_U('m/s', 1), _U('km/h', 1 / 3.6), _U('mph', .44704), _U('nudo', .514444444)],
  'Datos': [_U('B', 1), _U('KB', 1e3), _U('MB', 1e6), _U('GB', 1e9), _U('TB', 1e12), _U('KiB', 1024), _U('MiB', 1048576), _U('GiB', 1073741824)],
  'Tiempo': [_U('s', 1), _U('min', 60), _U('h', 3600), _U('día', 86400), _U('semana', 604800)],
  'Temperatura': [_U('°C', 1), _U('°F', 1), _U('K', 1)],
  'Divisas': [],
};

class UnitsTool extends StatefulWidget {
  const UnitsTool({super.key});
  @override
  State<UnitsTool> createState() => _UT();
}

class _UT extends State<UnitsTool> {
  String group = 'Longitud';
  String from = 'm', to = 'km';
  final input = TextEditingController(text: '1');
  String out = '';
  String? error, rateInfo;
  Map<String, String> currencies = {};
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _calc();
  }

  List<String> get names => group == 'Divisas' ? currencies.keys.toList() : _groups[group]!.map((e) => e.name).toList();

  void _setGroup(String g) {
    setState(() {
      group = g;
      error = null;
      if (g == 'Divisas') {
        from = 'EUR';
        to = 'USD';
        out = '';
        _loadCurrencies();
      } else {
        from = _groups[g]![0].name;
        to = _groups[g]![1].name;
        _calc();
      }
    });
  }

  Future<void> _loadCurrencies() async {
    setState(() => loading = true);
    try {
      if (currencies.isEmpty) {
        final j = await getJson('https://api.frankfurter.dev/v1/currencies') as Map;
        currencies = j.map((k, v) => MapEntry(k as String, v as String));
      }
      await _calc();
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _calc() async {
    final v = double.tryParse(input.text.replaceAll(',', '.'));
    if (v == null) return setState(() => out = '');
    if (group == 'Divisas') {
      if (!currencies.containsKey(from) || !currencies.containsKey(to)) return;
      try {
        if (from == to) {
          setState(() { out = fmtNum(v); error = null; });
          return;
        }
        final j = await getJson('https://api.frankfurter.dev/v1/latest?base=$from&symbols=$to&amount=${v.toString()}');
        final r = (j['rates'][to] as num).toDouble();
        if (mounted) setState(() { out = r.toStringAsFixed(4); rateInfo = 'Tipo del BCE · ${j['date']}'; error = null; });
      } catch (e) {
        if (mounted) setState(() => error = '$e');
      }
      return;
    }
    double r;
    if (group == 'Temperatura') {
      final c = from == '°C' ? v : from == '°F' ? (v - 32) * 5 / 9 : v - 273.15;
      r = to == '°C' ? c : to == '°F' ? c * 9 / 5 + 32 : c + 273.15;
    } else {
      final l = _groups[group]!;
      r = v * l.firstWhere((e) => e.name == from).f / l.firstWhere((e) => e.name == to).f;
    }
    setState(() => out = fmtNum(double.parse(r.toStringAsPrecision(10))));
  }

  Widget _drop(String val, void Function(String) f) => Expanded(
      child: DropdownButtonFormField<String>(
          value: names.contains(val) ? val : null,
          isExpanded: true,
          items: [for (final n in names) DropdownMenuItem(value: n, child: Text(group == 'Divisas' ? '$n · ${currencies[n]}' : n, overflow: TextOverflow.ellipsis))],
          onChanged: (x) {
            if (x != null) { setState(() => f(x)); _calc(); }
          }));

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Unidades y divisas',
      maxWidth: 600,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Wrap(spacing: 8, runSpacing: 4, children: [for (final g in _groups.keys) ChoiceChip(label: Text(g), selected: g == group, onSelected: (_) => _setGroup(g))]),
        const SizedBox(height: 16),
        GlassCard(
            child: Column(children: [
          TextField(controller: input, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), onChanged: (_) => _calc(), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Row(children: [
            _drop(from, (x) => from = x),
            IconButton(icon: const Icon(Icons.swap_horiz_rounded), onPressed: () { setState(() { final t = from; from = to; to = t; }); _calc(); }),
            _drop(to, (x) => to = x),
          ]),
          const SizedBox(height: 16),
          if (loading) const CircularProgressIndicator() else SelectableText(out.isEmpty ? '—' : '$out $to', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          if (group == 'Divisas' && rateInfo != null && error == null) Text(rateInfo!, style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        ])),
        const SizedBox(height: 8),
        if (group == 'Divisas') Text('Divisas: Frankfurter (tipos de referencia del BCE, actualizados en días laborables).', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
      ]));
}
