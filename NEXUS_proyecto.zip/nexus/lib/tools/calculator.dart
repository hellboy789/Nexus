import 'dart:math' as m;
import 'package:flutter/material.dart';
import '../core/glass.dart';

/// Evaluador recursivo: + - * / ^ %, paréntesis, funciones y constantes.
class _P {
  _P(this.s, this.deg);
  final String s;
  final bool deg;
  int i = 0;
  String? _peek() {
    while (i < s.length && s[i] == ' ') i++;
    return i < s.length ? s[i] : null;
  }

  double parse() {
    final v = _expr();
    if (_peek() != null) throw 'Expresión no válida';
    return v;
  }

  double _expr() {
    var v = _term();
    while (true) {
      final c = _peek();
      if (c == '+') { i++; v += _term(); }
      else if (c == '-') { i++; v -= _term(); }
      else return v;
    }
  }

  double _term() {
    var v = _pow();
    while (true) {
      final c = _peek();
      if (c == '*' || c == '×') { i++; v *= _pow(); }
      else if (c == '/' || c == '÷') { i++; final d = _pow(); if (d == 0) throw 'División por cero'; v /= d; }
      else if (c == '%') { i++; v = v % _pow(); }
      else return v;
    }
  }

  double _pow() {
    final b = _unary();
    if (_peek() == '^') { i++; return m.pow(b, _pow()).toDouble(); }
    return b;
  }

  double _unary() {
    final c = _peek();
    if (c == '-') { i++; return -_unary(); }
    if (c == '+') { i++; return _unary(); }
    return _post();
  }

  double _post() {
    var v = _atom();
    while (_peek() == '!') {
      i++;
      if (v < 0 || v != v.roundToDouble() || v > 170) throw 'Factorial no válido';
      var f = 1.0;
      for (var k = 2; k <= v; k++) f *= k;
      v = f;
    }
    return v;
  }

  double _atom() {
    final c = _peek();
    if (c == null) throw 'Expresión incompleta';
    if (c == '(') {
      i++;
      final v = _expr();
      if (_peek() != ')') throw 'Falta )';
      i++;
      return v;
    }
    if (RegExp(r'[0-9.]').hasMatch(c)) {
      final st = i;
      while (i < s.length && RegExp(r'[0-9.]').hasMatch(s[i])) i++;
      return double.parse(s.substring(st, i));
    }
    final st = i;
    while (i < s.length && RegExp(r'[a-zπ]').hasMatch(s[i])) i++;
    final n = s.substring(st, i);
    if (n.isEmpty) throw 'Carácter no válido: $c';
    if (n == 'pi' || n == 'π') return m.pi;
    if (n == 'e') return m.e;
    if (_peek() != '(') throw 'Función sin paréntesis: $n';
    i++;
    final a = _expr();
    if (_peek() != ')') throw 'Falta )';
    i++;
    final r = deg ? a * m.pi / 180 : a;
    switch (n) {
      case 'sin': return m.sin(r);
      case 'cos': return m.cos(r);
      case 'tan': return m.tan(r);
      case 'asin': return deg ? m.asin(a) * 180 / m.pi : m.asin(a);
      case 'acos': return deg ? m.acos(a) * 180 / m.pi : m.acos(a);
      case 'atan': return deg ? m.atan(a) * 180 / m.pi : m.atan(a);
      case 'sqrt': if (a < 0) throw 'Raíz de negativo'; return m.sqrt(a);
      case 'ln': if (a <= 0) throw 'ln de no positivo'; return m.log(a);
      case 'log': if (a <= 0) throw 'log de no positivo'; return m.log(a) / m.ln10;
      case 'abs': return a.abs();
      case 'exp': return m.exp(a);
    }
    throw 'Función desconocida: $n';
  }
}

String fmtNum(double v) {
  if (v == v.roundToDouble() && v.abs() < 1e15) return v.toInt().toString();
  return double.parse(v.toStringAsPrecision(12)).toString();
}

class CalculatorTool extends StatefulWidget {
  const CalculatorTool({super.key});
  @override
  State<CalculatorTool> createState() => _C();
}

class _C extends State<CalculatorTool> {
  String expr = '';
  String result = '';
  bool deg = true, sci = false;
  final history = <String>[];

  void _eval() {
    try {
      final v = _P(expr.replaceAll(',', '.'), deg).parse();
      if (v.isNaN || v.isInfinite) throw 'Resultado no definido';
      final r = fmtNum(v);
      history.insert(0, '$expr = $r');
      setState(() { expr = r; result = ''; });
    } catch (e) {
      setState(() => result = e is String ? e : 'Expresión no válida');
    }
  }

  void _live() {
    try {
      final v = _P(expr.replaceAll(',', '.'), deg).parse();
      result = v.isNaN || v.isInfinite ? '' : fmtNum(v);
    } catch (_) {
      result = '';
    }
  }

  void _tap(String k) {
    setState(() {
      if (k == 'C') { expr = ''; result = ''; }
      else if (k == '⌫') { if (expr.isNotEmpty) expr = expr.substring(0, expr.length - 1); _live(); }
      else if (k == '=') { _eval(); }
      else { expr += k; _live(); }
    });
  }

  Widget _key(String k, {bool accent = false}) => Expanded(
      child: Padding(
          padding: const EdgeInsets.all(4),
          child: GlassCard(
              radius: 18,
              padding: const EdgeInsets.symmetric(vertical: 16),
              onTap: () => _tap(k.endsWith('(') || k == 'π' ? k : k),
              child: Center(child: Text(k, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: accent ? Theme.of(context).colorScheme.primary : null))))));

  @override
  Widget build(BuildContext context) {
    final rows = [
      ['C', '(', ')', '÷'],
      ['7', '8', '9', '×'],
      ['4', '5', '6', '-'],
      ['1', '2', '3', '+'],
      ['0', '.', '⌫', '='],
    ];
    return GlassPage(
        title: 'Calculadora',
        maxWidth: 480,
        actions: [
          TextButton(onPressed: () => setState(() => deg = !deg), child: Text(deg ? 'DEG' : 'RAD')),
          IconButton(icon: Icon(sci ? Icons.keyboard_hide_rounded : Icons.functions_rounded), onPressed: () => setState(() => sci = !sci)),
        ],
        child: Column(children: [
          Expanded(
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: GlassCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Expanded(
                        child: ListView(reverse: true, children: [
                      for (final h in history.take(30)) Align(alignment: Alignment.centerRight, child: Text(h, style: TextStyle(color: Theme.of(context).hintColor))),
                    ])),
                    SelectableText(expr.isEmpty ? '0' : expr, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
                    Text(result, style: TextStyle(fontSize: 20, color: Theme.of(context).hintColor)),
                  ])))),
          if (sci)
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Wrap(spacing: 6, children: [
                  for (final f in ['sin(', 'cos(', 'tan(', 'asin(', 'acos(', 'atan(', 'ln(', 'log(', 'sqrt(', 'abs(', 'exp(', '^', '!', 'π', 'e', '%'])
                    ActionChip(label: Text(f), onPressed: () => _tap(f)),
                ])),
          Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
              child: Column(children: [
                for (final r in rows) Row(children: [for (final k in r) _key(k, accent: '÷×-+='.contains(k))]),
              ])),
        ]));
  }
}
