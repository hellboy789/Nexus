import 'package:flutter/material.dart';
import '../core/glass.dart';
import '../core/net.dart';

const _rr = {1: 'A', 2: 'NS', 5: 'CNAME', 6: 'SOA', 15: 'MX', 16: 'TXT', 28: 'AAAA', 257: 'CAA'};

/// DNS (DNS-over-HTTPS de Google) + información de dominio (RDAP). Sin claves.
class DnsTool extends StatefulWidget {
  const DnsTool({super.key});
  @override
  State<DnsTool> createState() => _D();
}

class _D extends State<DnsTool> {
  final c = TextEditingController();
  final types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA', 'CAA'];
  String type = 'A';
  bool loading = false;
  String? error;
  List<String> dns = [];
  Map<String, String> rdap = {};
  String status = '';

  String _host() => c.text.trim().replaceAll(RegExp(r'^https?://'), '').split('/').first.toLowerCase();

  Future<void> _run() async {
    final h = _host();
    if (h.isEmpty || !h.contains('.')) return setState(() => error = 'Introduce un dominio válido (ej. ejemplo.com).');
    setState(() { loading = true; error = null; dns = []; rdap = {}; status = ''; });
    try {
      final j = await getJson('https://dns.google/resolve?name=${Uri.encodeQueryComponent(h)}&type=$type', ttl: const Duration(minutes: 2));
      const st = {0: 'NOERROR', 2: 'SERVFAIL', 3: 'NXDOMAIN (el dominio no existe)', 5: 'REFUSED'};
      status = 'Estado DNS: ${st[j['Status']] ?? j['Status']}';
      dns = [for (final a in ((j['Answer'] as List?) ?? [])) '${_rr[a['type']] ?? a['type']} · TTL ${a['TTL']} · ${a['data']}'];
    } catch (e) {
      error = '$e';
    }
    try {
      final j = await getJson('https://rdap.org/domain/$h', ttl: const Duration(minutes: 10), timeout: const Duration(seconds: 15));
      final ev = {for (final e in ((j['events'] as List?) ?? [])) '${e['eventAction']}': '${e['eventDate']}'.split('T').first};
      final ns = ((j['nameservers'] as List?) ?? []).map((n) => '${n['ldhName']}'.toLowerCase()).join(', ');
      final reg = ((j['entities'] as List?) ?? []).where((e) => (e['roles'] as List?)?.contains('registrar') == true).map((e) {
        final v = e['vcardArray'];
        try {
          return '${(v[1] as List).firstWhere((x) => x[0] == 'fn')[3]}';
        } catch (_) {
          return '${e['handle']}';
        }
      }).join(', ');
      rdap = {
        if (j['ldhName'] != null) 'Dominio': '${j['ldhName']}'.toLowerCase(),
        if (reg.isNotEmpty) 'Registrador': reg,
        if (ev['registration'] != null) 'Registrado': ev['registration']!,
        if (ev['expiration'] != null) 'Caduca': ev['expiration']!,
        if (ev['last changed'] != null) 'Última modificación': ev['last changed']!,
        if (ns.isNotEmpty) 'Servidores DNS': ns,
        if (j['status'] != null) 'Estado': (j['status'] as List).join(', '),
      };
    } catch (e) {
      rdap = {'RDAP': 'No disponible: $e'};
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'DNS y dominio',
      maxWidth: 700,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: c, onSubmitted: (_) => _run(), decoration: const InputDecoration(hintText: 'ejemplo.com', prefixIcon: Icon(Icons.dns_rounded))),
        const SizedBox(height: 8),
        Wrap(spacing: 6, children: [for (final t in types) ChoiceChip(label: Text(t), selected: type == t, onSelected: (_) => setState(() => type = t))]),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerLeft, child: GlassButton('Consultar', icon: Icons.search_rounded, onTap: loading ? null : _run)),
        const SizedBox(height: 12),
        if (loading) const Center(child: CircularProgressIndicator()),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (status.isNotEmpty) Text(status),
        if (dns.isNotEmpty) GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final d in dns) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: SelectableText(d))])),
        if (status.isNotEmpty && dns.isEmpty && error == null) const Text('Sin registros de ese tipo.'),
        const SizedBox(height: 12),
        if (rdap.isNotEmpty) KV(rdap),
        const SizedBox(height: 8),
        Text('DNS: dns.google (DoH). Dominio: RDAP vía rdap.org (puede no cubrir todos los TLD).', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
      ]));
}
