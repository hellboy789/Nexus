import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:xml/xml.dart';
import '../core/glass.dart';

/// Visor y formateador de JSON y XML con vista de árbol.
class JsonTool extends StatefulWidget {
  const JsonTool({super.key});
  @override
  State<JsonTool> createState() => _J();
}

class _J extends State<JsonTool> {
  final c = TextEditingController();
  String? error, pretty;
  dynamic tree;
  bool isXml = false;

  void _run() {
    final t = c.text.trim();
    setState(() { error = null; pretty = null; tree = null; });
    if (t.isEmpty) return;
    try {
      if (t.startsWith('<')) {
        isXml = true;
        pretty = XmlDocument.parse(t).toXmlString(pretty: true, indent: '  ');
      } else {
        isXml = false;
        tree = jsonDecode(t);
        pretty = const JsonEncoder.withIndent('  ').convert(tree);
      }
    } catch (e) {
      error = '${isXml || t.startsWith('<') ? 'XML' : 'JSON'} no válido: ${e.toString().split('\n').first}';
    }
    setState(() {});
  }

  Widget _node(String k, dynamic v) {
    if (v is Map) return ExpansionTile(title: Text('$k {${v.length}}'), dense: true, children: [for (final e in v.entries) Padding(padding: const EdgeInsets.only(left: 12), child: _node('${e.key}', e.value))]);
    if (v is List) return ExpansionTile(title: Text('$k [${v.length}]'), dense: true, children: [for (var i = 0; i < v.length; i++) Padding(padding: const EdgeInsets.only(left: 12), child: _node('$i', v[i]))]);
    return ListTile(dense: true, title: SelectableText('$k: $v'));
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'JSON / XML',
      maxWidth: 900,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: c, maxLines: 8, decoration: const InputDecoration(hintText: 'Pega JSON o XML')),
        const SizedBox(height: 8),
        Row(children: [
          GlassButton('Formatear', icon: Icons.data_object_rounded, onTap: _run),
          const SizedBox(width: 8),
          GlassButton('Minificar', icon: Icons.compress_rounded, onTap: () {
            try {
              c.text = jsonEncode(jsonDecode(c.text));
              _run();
            } catch (_) {
              setState(() => error = 'Solo se puede minificar JSON válido.');
            }
          }),
          const SizedBox(width: 8),
          if (pretty != null) GlassButton('Copiar', icon: Icons.copy_rounded, onTap: () => copy(context, pretty!)),
        ]),
        const SizedBox(height: 12),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.redAccent)),
        if (tree != null) GlassCard(padding: const EdgeInsets.all(4), child: _node('raíz', tree)),
        if (pretty != null) ...[const SizedBox(height: 8), GlassCard(child: SelectableText(pretty!, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)))],
      ]));
}
