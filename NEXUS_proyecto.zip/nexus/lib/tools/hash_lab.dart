import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../core/files.dart';
import '../core/glass.dart';
import '../core/ui.dart';

class _Out implements Sink<Digest> {
  Digest? d;
  @override
  void add(Digest data) => d = data;
  @override
  void close() {}
}

/// HASH LAB: MD5/SHA-1/SHA-256/SHA-512 de archivos (en streaming) y texto, HMAC y verificación.
class HashLabTool extends StatefulWidget {
  const HashLabTool({super.key});
  @override
  State<HashLabTool> createState() => _S();
}

class _S extends State<HashLabTool> {
  static const algos = <String, Hash>{'MD5': md5, 'SHA-1': sha1, 'SHA-256': sha256, 'SHA-512': sha512};
  final text = TextEditingController();
  final key = TextEditingController();
  final expect = TextEditingController();
  Map<String, String> out = {};
  String? file;
  int? size;
  double? progress;
  bool cancel = false;
  String err = '';

  @override
  void dispose() {
    text.dispose();
    key.dispose();
    expect.dispose();
    super.dispose();
  }

  Future<void> _file() async {
    final r = await FilePicker.platform.pickFiles();
    final path = r?.files.single.path;
    if (path == null) return;
    cancel = false;
    setState(() {
      file = path;
      out = {};
      err = '';
      progress = 0;
    });
    try {
      final f = File(path);
      final total = await f.length();
      size = total;
      final outs = {for (final k in algos.keys) k: _Out()};
      final convs = {for (final e in algos.entries) e.key: e.value.startChunkedConversion(outs[e.key]!)};
      var done = 0, tick = 0;
      await for (final chunk in f.openRead()) {
        if (cancel) break;
        for (final c in convs.values) {
          c.add(chunk);
        }
        done += chunk.length;
        if (++tick % 8 == 0 && mounted) setState(() => progress = total == 0 ? 1 : done / total);
      }
      if (cancel) {
        err = 'Cancelado';
      } else {
        for (final c in convs.values) {
          c.close();
        }
        out = {for (final k in algos.keys) k: outs[k]!.d.toString()};
      }
    } catch (e) {
      err = 'Error: $e';
    }
    if (mounted) setState(() => progress = null);
  }

  void _text() {
    final b = utf8.encode(text.text);
    setState(() {
      file = null;
      err = '';
      size = b.length;
      out = {for (final e in algos.entries) e.key: (key.text.isEmpty ? e.value.convert(b) : Hmac(e.value, utf8.encode(key.text)).convert(b)).toString()};
    });
  }

  @override
  Widget build(BuildContext context) {
    final e = expect.text.trim().toLowerCase().replaceAll(RegExp(r'\s'), '');
    final match = e.isEmpty ? null : out.entries.where((x) => x.value == e).map((x) => x.key).toList();
    return GlassPage(
      title: 'HASH LAB',
      child: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: text, minLines: 3, maxLines: 8, decoration: const InputDecoration(hintText: 'Texto a convertir en hash…')),
        const SizedBox(height: 8),
        TextField(controller: key, decoration: const InputDecoration(labelText: 'Clave HMAC (opcional)')),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, children: [
          GlassButton('Hash del texto', icon: Icons.tag_rounded, onTap: _text),
          GlassButton('Hash de un archivo', icon: Icons.insert_drive_file_rounded, onTap: progress != null ? null : _file),
          if (progress != null) GlassButton('Cancelar', icon: Icons.stop_rounded, onTap: () => cancel = true),
        ]),
        if (progress != null) Padding(padding: const EdgeInsets.only(top: 12), child: LinearProgressIndicator(value: progress)),
        if (err.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: GlassCard(child: Text(err))),
        if (file != null && out.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: GlassCard(child: Text('${file!.split(RegExp(r'[\\/]')).last} · ${fmtSize(size ?? 0)}'))),
        const SizedBox(height: 12),
        for (final en in out.entries)
          Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GlassCard(
                  onTap: () => copy(context, en.value),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [Text(en.key, style: const TextStyle(fontWeight: FontWeight.w800)), const Spacer(), const Icon(Icons.copy_rounded, size: 16)]),
                    const SizedBox(height: 4),
                    SelectableText(en.value, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                  ]))),
        const SizedBox(height: 8),
        TextField(controller: expect, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Hash esperado (verificar integridad)')),
        if (match != null && out.isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(top: 10),
              child: GlassCard(
                  child: Row(children: [
                Icon(match.isEmpty ? Icons.cancel_rounded : Icons.verified_rounded, color: match.isEmpty ? Colors.redAccent : Colors.greenAccent),
                const SizedBox(width: 10),
                Expanded(child: Text(match.isEmpty ? 'NO coincide con ningún hash calculado' : 'Coincide (${match.join(', ')})')),
              ]))),
      ]),
    );
  }
}
