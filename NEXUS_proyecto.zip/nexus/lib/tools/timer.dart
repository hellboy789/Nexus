import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:ui' show FontFeature;
import 'package:flutter/services.dart';
import '../core/glass.dart';

String _fmt(Duration d, {bool cs = false}) {
  String t(int n, [int w = 2]) => n.toString().padLeft(w, '0');
  final h = d.inHours;
  return '${h > 0 ? '$h:' : ''}${t(d.inMinutes % 60)}:${t(d.inSeconds % 60)}${cs ? '.${t((d.inMilliseconds % 1000) ~/ 10)}' : ''}';
}

class TimerTool extends StatefulWidget {
  const TimerTool({super.key});
  @override
  State<TimerTool> createState() => _T();
}

class _T extends State<TimerTool> with SingleTickerProviderStateMixin {
  late final TabController tc = TabController(length: 2, vsync: this);
  // Cronómetro
  final sw = Stopwatch();
  final laps = <Duration>[];
  // Temporizador
  Duration total = const Duration(minutes: 5), left = const Duration(minutes: 5);
  DateTime? endAt;
  Timer? tick;

  @override
  void initState() {
    super.initState();
    tick = Timer.periodic(const Duration(milliseconds: 50), (_) {
      if (endAt != null) {
        left = endAt!.difference(DateTime.now());
        if (left <= Duration.zero) {
          left = Duration.zero;
          endAt = null;
          HapticFeedback.heavyImpact();
          SystemSound.play(SystemSoundType.alert);
          if (mounted) msg(context, '¡Tiempo!');
        }
      }
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    tick?.cancel();
    tc.dispose();
    super.dispose();
  }

  Widget _big(String s) => Center(child: Text(s, style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()])));

  Widget _stopwatch() => Column(children: [
        const SizedBox(height: 24),
        _big(_fmt(sw.elapsed, cs: true)),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          GlassButton(sw.isRunning ? 'Pausar' : 'Iniciar', icon: sw.isRunning ? Icons.pause_rounded : Icons.play_arrow_rounded, onTap: () => sw.isRunning ? sw.stop() : sw.start()),
          const SizedBox(width: 12),
          GlassButton('Vuelta', icon: Icons.flag_rounded, onTap: sw.isRunning ? () => laps.insert(0, sw.elapsed) : null),
          const SizedBox(width: 12),
          GlassButton('Reiniciar', icon: Icons.restart_alt_rounded, onTap: () { sw.reset(); laps.clear(); }),
        ]),
        Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [for (var i = 0; i < laps.length; i++) ListTile(leading: Text('#${laps.length - i}'), title: Text(_fmt(laps[i], cs: true)))])),
      ]);

  Widget _timer() {
    final running = endAt != null;
    return Column(children: [
      const SizedBox(height: 24),
      _big(_fmt(left + (running ? const Duration(milliseconds: 999) : Duration.zero))),
      const SizedBox(height: 8),
      if (!running)
        Wrap(spacing: 8, children: [
          for (final m in [1, 3, 5, 10, 15, 30, 60]) ActionChip(label: Text('$m min'), onPressed: () => setState(() { total = Duration(minutes: m); left = total; })),
        ]),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        GlassButton(running ? 'Pausar' : 'Iniciar', icon: running ? Icons.pause_rounded : Icons.play_arrow_rounded, onTap: () {
          if (running) { endAt = null; }
          else { if (left <= Duration.zero) left = total; endAt = DateTime.now().add(left); }
        }),
        const SizedBox(width: 12),
        GlassButton('Reiniciar', icon: Icons.restart_alt_rounded, onTap: () { endAt = null; left = total; }),
      ]),
    ]);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: 'Reloj',
      maxWidth: 600,
      bottom: TabBar(controller: tc, tabs: const [Tab(text: 'Temporizador'), Tab(text: 'Cronómetro')]),
      child: TabBarView(controller: tc, children: [_timer(), _stopwatch()]));
}
