import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';

Future<String?> pickPath({List<String>? ext}) async {
  final r = await FilePicker.platform
      .pickFiles(type: ext == null ? FileType.any : FileType.custom, allowedExtensions: ext);
  return r?.files.single.path;
}

/// Guarda bytes pidiendo ubicación al usuario. Devuelve ruta/URI o null si se cancela.
Future<String?> saveBytes(String name, Uint8List bytes) async {
  if (Platform.isAndroid || Platform.isIOS) {
    return FilePicker.platform.saveFile(fileName: name, bytes: bytes);
  }
  final path = await FilePicker.platform.saveFile(fileName: name);
  if (path == null) return null;
  await File(path).writeAsBytes(bytes);
  return path;
}

String fmtSize(int b) {
  if (b < 1024) return '$b B';
  if (b < 1048576) return '${(b / 1024).toStringAsFixed(1)} KB';
  return '${(b / 1048576).toStringAsFixed(2)} MB';
}
