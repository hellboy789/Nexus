import 'package:flutter/material.dart';

/// Gráfico de línea mínimo (sin dependencias).
class Spark extends StatelessWidget {
  const Spark(this.v, {super.key, this.color, this.height = 120});
  final List<double> v;
  final Color? color;
  final double height;
  @override
  Widget build(BuildContext context) => SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _SP(v, color ?? Theme.of(context).colorScheme.primary)));
}

class _SP extends CustomPainter {
  _SP(this.v, this.c);
  final List<double> v;
  final Color c;
  @override
  void paint(Canvas can, Size s) {
    if (v.length < 2) return;
    var lo = v.first, hi = v.first;
    for (final x in v) {
      if (x < lo) lo = x;
      if (x > hi) hi = x;
    }
    final r = (hi - lo) == 0 ? 1.0 : (hi - lo);
    final p = Path();
    for (var i = 0; i < v.length; i++) {
      final x = s.width * i / (v.length - 1);
      final y = s.height - (v[i] - lo) / r * (s.height - 8) - 4;
      i == 0 ? p.moveTo(x, y) : p.lineTo(x, y);
    }
    can.drawPath(p, Paint()..color = c..style = PaintingStyle.stroke..strokeWidth = 2);
  }

  @override
  bool shouldRepaint(_SP o) => o.v != v;
}
