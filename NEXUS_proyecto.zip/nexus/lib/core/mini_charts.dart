import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Barras horizontales etiquetadas (ranking).
class HBars extends StatelessWidget {
  const HBars(this.data, {super.key, this.color = const Color(0xFF38BDF8)});
  final List<MapEntry<String, num>> data;
  final Color color;
  @override
  Widget build(BuildContext context) {
    final mx = data.isEmpty ? 1 : data.map((e) => e.value).reduce((a, b) => a > b ? a : b);
    return Column(children: [
      for (final e in data)
        Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Row(children: [
              SizedBox(width: 96, child: Text(e.key, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12))),
              Expanded(
                  child: LayoutBuilder(
                      builder: (_, k) => Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                              height: 10,
                              width: k.maxWidth * (mx == 0 ? 0.0 : e.value / mx),
                              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(5)))))),
              SizedBox(width: 60, child: Text('${e.value}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 12))),
            ])),
    ]);
  }
}

/// Columnas verticales (histograma). first/last son las etiquetas de los extremos del eje X.
class Columns extends StatelessWidget {
  const Columns(this.values, {super.key, this.first = '', this.last = '', this.color = const Color(0xFF38BDF8), this.height = 100});
  final List<num> values;
  final String first, last;
  final Color color;
  final double height;
  @override
  Widget build(BuildContext context) => Column(children: [
        SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _ColP(values, color))),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(first, style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
          Text('máx. ${values.isEmpty ? 0 : values.reduce(math.max)}', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
          Text(last, style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
        ]),
      ]);
}

class _ColP extends CustomPainter {
  _ColP(this.v, this.c);
  final List<num> v;
  final Color c;
  @override
  void paint(Canvas canvas, Size s) {
    if (v.isEmpty) return;
    final mx = v.reduce(math.max);
    if (mx <= 0) return;
    final w = s.width / v.length;
    final p = Paint()..color = c;
    for (var i = 0; i < v.length; i++) {
      final h = s.height * (v[i] / mx);
      canvas.drawRect(Rect.fromLTWH(i * w, s.height - h, math.max(w - 1, 1), h), p);
    }
  }

  @override
  bool shouldRepaint(covariant _ColP o) => o.v != v || o.c != c;
}

/// Línea con puntos (evolución). Mínimo 1 punto.
class LineSeries extends StatelessWidget {
  const LineSeries(this.values, {super.key, this.first = '', this.last = '', this.color = const Color(0xFF34D399), this.height = 110, this.unit = ''});
  final List<double> values;
  final String first, last, unit;
  final Color color;
  final double height;
  @override
  Widget build(BuildContext context) {
    final hint = TextStyle(fontSize: 11, color: Theme.of(context).hintColor);
    final lo = values.isEmpty ? 0 : values.reduce(math.min), hi = values.isEmpty ? 0 : values.reduce(math.max);
    return Column(children: [
      SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _LineP(values, color))),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(first, style: hint),
        Text('mín. ${lo.toStringAsFixed(2)} · máx. ${hi.toStringAsFixed(2)} $unit', style: hint),
        Text(last, style: hint),
      ]),
    ]);
  }
}

class _LineP extends CustomPainter {
  _LineP(this.v, this.c);
  final List<double> v;
  final Color c;
  @override
  void paint(Canvas canvas, Size s) {
    if (v.isEmpty) return;
    final lo = v.reduce(math.min), hi = v.reduce(math.max);
    final span = hi - lo == 0 ? 1.0 : hi - lo;
    Offset pt(int i) => Offset(v.length == 1 ? s.width / 2 : s.width * i / (v.length - 1), s.height - 8 - (s.height - 16) * ((v[i] - lo) / span));
    final line = Paint()
      ..color = c
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final path = Path()..moveTo(pt(0).dx, pt(0).dy);
    for (var i = 1; i < v.length; i++) {
      path.lineTo(pt(i).dx, pt(i).dy);
    }
    canvas.drawPath(path, line);
    final dot = Paint()..color = c;
    for (var i = 0; i < v.length; i++) {
      canvas.drawCircle(pt(i), 3, dot);
    }
  }

  @override
  bool shouldRepaint(covariant _LineP o) => o.v != v || o.c != c;
}
