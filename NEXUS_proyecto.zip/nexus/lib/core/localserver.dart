import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'store.dart';

/// Servidor HTTP local compartido por SHARE y BRIDGE.
/// Seguridad: PIN de 6 cifras en TODAS las rutas, bloqueo 60 s tras 5 fallos,
/// solo sirve elementos de la bandeja explícitamente compartidos, nombres saneados.
/// El tráfico en la LAN va en HTTP SIN cifrar (limitación conocida).
class NexusServer {
  NexusServer._();
  static final I = NexusServer._();

  HttpServer? _s;
  final owners = <String>{}; // 'send' | 'recv' | 'bridge'
  final shareIds = <String>{};
  String pin = '';
  int port = 0;
  List<String> ips = [];
  int _fails = 0;
  DateTime? _lock;
  final tick = ValueNotifier<int>(0);
  final log = ValueNotifier<List<String>>([]);

  bool get running => _s != null;
  bool get upload => owners.contains('recv') || owners.contains('bridge');
  bool get exposeAll => owners.contains('bridge');

  void _log(String s) {
    final t = DateTime.now();
    final hh = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:${t.second.toString().padLeft(2, '0')}';
    log.value = ['$hh  $s', ...log.value].take(100).toList();
  }

  static Future<List<String>> lanAddresses() async {
    final out = <String>[];
    for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4, includeLoopback: false)) {
      for (final a in i.addresses) {
        final x = a.address;
        final b = x.split('.').map(int.tryParse).toList();
        final priv = x.startsWith('192.168.') || x.startsWith('10.') || (b.length == 4 && b[0] == 172 && (b[1] ?? 0) >= 16 && (b[1] ?? 0) <= 31);
        if (priv) out.add(x);
      }
    }
    return out;
  }

  Future<void> start(String owner) async {
    await DropStore.ensure();
    if (_s == null) {
      try {
        _s = await HttpServer.bind(InternetAddress.anyIPv4, 8765);
      } on SocketException {
        _s = await HttpServer.bind(InternetAddress.anyIPv4, 0);
      }
      port = _s!.port;
      final r = Random.secure();
      pin = List.generate(6, (_) => r.nextInt(10)).join();
      ips = await lanAddresses();
      _fails = 0;
      _lock = null;
      _s!.listen(_handle, onError: (_) {});
      _log('Servidor iniciado en el puerto $port');
    }
    owners.add(owner);
    tick.value++;
  }

  Future<void> stop(String owner) async {
    owners.remove(owner);
    if (owners.isEmpty && _s != null) {
      await _s!.close(force: true);
      _s = null;
      shareIds.clear();
      _log('Servidor detenido');
    }
    tick.value++;
  }

  List<String> urls() => [for (final ip in ips) 'http://$ip:$port'];
  String? get qrData => ips.isEmpty ? null : 'http://${ips.first}:$port/?k=$pin';

  bool _ok(HttpRequest r) {
    final k = r.uri.queryParameters['k'] ?? r.headers.value('x-nexus-key') ?? '';
    if (k.length != pin.length) return false;
    var d = 0;
    for (var i = 0; i < k.length; i++) {
      d |= k.codeUnitAt(i) ^ pin.codeUnitAt(i);
    }
    return d == 0;
  }

  bool _visible(DropItem i) => exposeAll || shareIds.contains(i.id);

  Future<void> _end(HttpRequest r, int code, [String? body]) async {
    r.response.statusCode = code;
    if (body != null) {
      r.response.headers.contentType = ContentType.text;
      r.response.write(body);
    }
    await r.response.close();
  }

  Future<void> _handle(HttpRequest r) async {
    final ip = r.connectionInfo?.remoteAddress.address ?? '?';
    try {
      if (_lock != null && DateTime.now().isBefore(_lock!)) return _end(r, 429, 'Demasiados intentos');
      if (!_ok(r)) {
        _fails++;
        if (_fails >= 5) {
          _lock = DateTime.now().add(const Duration(seconds: 60));
          _fails = 0;
        }
        _log('PIN incorrecto desde $ip');
        return _end(r, 403, 'PIN incorrecto');
      }
      _fails = 0;
      final path = r.uri.path;
      final m = r.method;
      if (m == 'GET' && path == '/') {
        r.response.headers.contentType = ContentType.html;
        r.response.write(_page());
        await r.response.close();
      } else if (m == 'GET' && path == '/api/ping') {
        r.response.headers.contentType = ContentType.json;
        r.response.write(jsonEncode({'nexus': 1, 'name': Platform.localHostname, 'os': Platform.operatingSystem, 'upload': upload, 'list': exposeAll || shareIds.isNotEmpty}));
        await r.response.close();
      } else if (m == 'GET' && path == '/api/list') {
        final l = DropStore.items.value.where(_visible).map((i) => {'id': i.id, 'kind': i.kind, 'title': i.title, 'size': i.size, if (!i.isFile) 'text': i.text}).toList();
        r.response.headers.contentType = ContentType.json;
        r.response.write(jsonEncode(l));
        await r.response.close();
      } else if (m == 'GET' && path.startsWith('/f/')) {
        final it = DropStore.byId(path.substring(3));
        if (it == null || !it.isFile || !_visible(it)) return _end(r, 404, 'No encontrado');
        final f = File(it.path!);
        if (!await f.exists()) return _end(r, 404, 'No encontrado');
        r.response.headers.contentType = ContentType.binary;
        r.response.headers.set('content-disposition', "attachment; filename*=UTF-8''${Uri.encodeComponent(it.title)}");
        r.response.contentLength = await f.length();
        _log('Descarga de "${it.title}" por $ip');
        await r.response.addStream(f.openRead());
        await r.response.close();
      } else if (m == 'POST' && path == '/up') {
        if (!upload) return _end(r, 403, 'Recepción desactivada');
        if (r.contentLength > 4 * 1024 * 1024 * 1024) return _end(r, 413, 'Demasiado grande');
        final name = safeName(r.uri.queryParameters['name'] ?? 'archivo');
        final id = DropStore.newId();
        final f = File(p.join(DropStore.dir.path, '${id}_$name'));
        final sink = f.openWrite();
        try {
          await sink.addStream(r);
          await sink.close();
        } catch (e) {
          try {
            await f.delete();
          } catch (_) {}
          return _end(r, 500, 'Error al recibir');
        }
        await DropStore.adopt(id, name, f);
        _log('Recibido "$name" de $ip');
        await _end(r, 200, 'ok');
      } else if (m == 'POST' && path == '/txt') {
        if (!upload) return _end(r, 403, 'Recepción desactivada');
        final b = StringBuffer();
        await for (final s in utf8.decoder.bind(r)) {
          b.write(s);
          if (b.length > 200000) return _end(r, 413, 'Demasiado grande');
        }
        if (b.toString().trim().isEmpty) return _end(r, 400, 'Vacío');
        await DropStore.addText(b.toString());
        _log('Texto recibido de $ip');
        await _end(r, 200, 'ok');
      } else {
        await _end(r, 404, 'No encontrado');
      }
    } catch (_) {
      try {
        await _end(r, 500);
      } catch (_) {}
    }
  }

  static String _h(String s) => const HtmlEscape().convert(s);

  String _page() {
    final rows = StringBuffer();
    for (final i in DropStore.items.value.where(_visible)) {
      if (i.isFile) {
        rows.write('<li><a href="/f/${i.id}?k=$pin">${_h(i.title)}</a> <small>${i.size ~/ 1024} KB</small></li>');
      } else {
        rows.write('<li><pre>${_h(i.text ?? '')}</pre></li>');
      }
    }
    final up = upload
        ? '<h3>Enviar a este equipo</h3><input type="file" multiple onchange="up(this)"><br><br>'
            '<textarea id="t" rows="3" style="width:100%"></textarea><button onclick="tx()">Enviar texto</button><pre id="st"></pre>'
        : '';
    return '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>NEXUS</title><style>body{font-family:system-ui;background:#0b1026;color:#eef;max-width:640px;margin:auto;padding:16px}'
        'a{color:#8fb4ff}li{margin:8px 0}pre{white-space:pre-wrap}</style>'
        '<h2>NEXUS</h2><h3>Archivos disponibles</h3><ul>${rows.isEmpty ? '<li>Nada compartido</li>' : rows}</ul>$up'
        '<script>const K=new URLSearchParams(location.search).get("k");'
        'async function up(i){for(const f of i.files){const r=await fetch("/up?k="+encodeURIComponent(K)+"&name="+encodeURIComponent(f.name),{method:"POST",body:f});'
        'st.textContent+=f.name+(r.ok?" ✓\\n":" ✗ "+r.status+"\\n")}}'
        'async function tx(){const r=await fetch("/txt?k="+encodeURIComponent(K),{method:"POST",body:t.value});st.textContent+=r.ok?"Texto enviado ✓\\n":"Error "+r.status+"\\n";if(r.ok)t.value=""}'
        '</script>';
  }
}
