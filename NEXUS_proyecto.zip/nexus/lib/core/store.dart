import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Elemento de la bandeja NEXUS DROPZONE.
class DropItem {
  DropItem({required this.id, required this.kind, required this.title, this.path, this.text, this.size = 0, int? added})
      : added = added ?? DateTime.now().millisecondsSinceEpoch;
  final String id, kind, title; // kind: file | image | link | text
  final String? path, text;
  final int size, added;
  bool get isFile => path != null;
  Map<String, dynamic> toJson() => {'id': id, 'kind': kind, 'title': title, 'path': path, 'text': text, 'size': size, 'added': added};
  factory DropItem.fromJson(Map<String, dynamic> j) => DropItem(
      id: j['id'] as String,
      kind: j['kind'] as String,
      title: j['title'] as String,
      path: j['path'] as String?,
      text: j['text'] as String?,
      size: (j['size'] as num?)?.toInt() ?? 0,
      added: (j['added'] as num?)?.toInt());
}

/// Nombre de fichero seguro (sin rutas ni caracteres reservados).
String safeName(String s) {
  var n = s.replaceAll('\\', '/').split('/').last;
  n = n.replaceAll(RegExp(r'[<>:"|?*\x00-\x1F]'), '_').trim();
  while (n.startsWith('.')) {
    n = n.substring(1);
  }
  if (n.length > 120) n = n.substring(n.length - 120);
  return n.isEmpty ? 'archivo' : n;
}

class DropStore {
  static final items = ValueNotifier<List<DropItem>>([]);
  static Directory? _dir;
  static bool _loaded = false;
  static final _rnd = Random.secure();
  static const _imgExt = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp'};

  static Directory get dir => _dir!;
  static File get _index => File(p.join(_dir!.path, 'index.json'));
  static String newId() => List.generate(10, (_) => _rnd.nextInt(16).toRadixString(16)).join();

  static Future<void> ensure() async {
    if (_loaded) return;
    final base = await getApplicationSupportDirectory();
    _dir = Directory(p.join(base.path, 'dropzone'));
    await _dir!.create(recursive: true);
    if (await _index.exists()) {
      try {
        final l = jsonDecode(await _index.readAsString()) as List;
        items.value = [for (final e in l) DropItem.fromJson(Map<String, dynamic>.from(e as Map))]
            .where((i) => i.path == null || File(i.path!).existsSync())
            .toList();
      } catch (_) {
        items.value = [];
      }
    }
    _loaded = true;
  }

  static Future<void> _save() => _index.writeAsString(jsonEncode(items.value.map((e) => e.toJson()).toList()));

  static String _kindOf(String name) => _imgExt.contains(p.extension(name).toLowerCase()) ? 'image' : 'file';

  /// Registra un fichero que YA está dentro de la carpeta de la bandeja (nombre `<id>_<nombre>`).
  static Future<DropItem> adopt(String id, String name, File f) async {
    final it = DropItem(id: id, kind: _kindOf(name), title: name, path: f.path, size: await f.length());
    items.value = [it, ...items.value];
    await _save();
    return it;
  }

  /// Copia un fichero externo a la bandeja (el original no se toca).
  static Future<DropItem> addFile(String src) async {
    await ensure();
    final name = safeName(src);
    final id = newId();
    final dst = await File(src).copy(p.join(_dir!.path, '${id}_$name'));
    return adopt(id, name, dst);
  }

  static Future<DropItem> addText(String t) async {
    await ensure();
    final s = t.trim();
    final link = RegExp(r'^https?://\S+$').hasMatch(s);
    final first = s.split('\n').first;
    final it = DropItem(
        id: newId(), kind: link ? 'link' : 'text', title: first.length > 70 ? '${first.substring(0, 70)}…' : first, text: s, size: utf8.encode(s).length);
    items.value = [it, ...items.value];
    await _save();
    return it;
  }

  static DropItem? byId(String id) {
    for (final i in items.value) {
      if (i.id == id) return i;
    }
    return null;
  }

  static Future<void> remove(DropItem it) async {
    if (it.path != null) {
      try {
        await File(it.path!).delete();
      } catch (_) {}
    }
    items.value = items.value.where((e) => e.id != it.id).toList();
    await _save();
  }
}
