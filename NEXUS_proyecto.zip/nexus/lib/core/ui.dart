import 'package:flutter/material.dart';

Future<bool> confirmDlg(BuildContext c, String text, {String ok = 'Eliminar'}) async {
  final r = await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
            content: Text(text),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(ok)),
            ],
          ));
  return r == true;
}
