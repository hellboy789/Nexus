import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'glass.dart';

const nexusUA = 'NEXUS/0.2 (app de herramientas)';

/// GET JSON con error claro. Lanza String legible.
Future<dynamic> getJson(String url, {Map<String, String>? headers}) async {
  try {
    final r = await http.get(Uri.parse(url), headers: {'User-Agent': nexusUA, ...?headers}).timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw 'El servicio respondió con error ${r.statusCode}';
    return jsonDecode(utf8.decode(r.bodyBytes));
  } on String {
    rethrow;
  } catch (e) {
    throw 'No se pudo conectar con el servicio (${Uri.parse(url).host}). Revisa tu conexión.';
  }
}

class Place {
  Place(this.name, this.lat, this.lon);
  final String name;
  final double lat, lon;
}

/// Pide permiso al usuario (diálogo propio + permiso del sistema) y devuelve la posición.
Future<Place?> askLocation(BuildContext c) async {
  final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
            title: const Text('Usar tu ubicación'),
            content: const Text('NEXUS necesita tu ubicación solo para esta consulta. No se guarda ni se envía a ningún servidor propio.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Ahora no')),
              FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Permitir')),
            ],
          ));
  if (ok != true) return null;
  try {
    if (!await Geolocator.isLocationServiceEnabled()) throw 'El servicio de ubicación está desactivado en el dispositivo.';
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) throw 'Permiso de ubicación denegado.';
    final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium, timeLimit: Duration(seconds: 20)));
    return Place('Mi ubicación', p.latitude, p.longitude);
  } catch (e) {
    if (c.mounted) msg(c, e is String ? e : 'No se pudo obtener la ubicación. Busca una ciudad manualmente.');
    return null;
  }
}

/// Geocodificación Open-Meteo (sin API key).
Future<List<Place>> searchCity(String q) async {
  final j = await getJson('https://geocoding-api.open-meteo.com/v1/search?count=6&language=es&name=${Uri.encodeQueryComponent(q)}');
  final l = (j['results'] as List?) ?? [];
  return l.map((e) => Place('${e['name']}${e['admin1'] != null ? ', ${e['admin1']}' : ''} (${e['country_code'] ?? ''})', (e['latitude'] as num).toDouble(), (e['longitude'] as num).toDouble())).toList();
}

/// Selector de lugar reutilizable: ubicación actual o búsqueda de ciudad.
class PlaceBar extends StatefulWidget {
  const PlaceBar({super.key, required this.onPlace});
  final void Function(Place) onPlace;
  @override
  State<PlaceBar> createState() => _PB();
}

class _PB extends State<PlaceBar> {
  final c = TextEditingController();
  Future<void> _search() async {
    if (c.text.trim().isEmpty) return;
    try {
      final r = await searchCity(c.text.trim());
      if (!mounted) return;
      if (r.isEmpty) return msg(context, 'Sin resultados');
      if (r.length == 1) return widget.onPlace(r.first);
      final p = await showModalBottomSheet<Place>(
          context: context,
          builder: (d) => ListView(children: [for (final x in r) ListTile(title: Text(x.name), onTap: () => Navigator.pop(d, x))]));
      if (p != null) widget.onPlace(p);
    } catch (e) {
      if (mounted) msg(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
            child: TextField(
                controller: c,
                onSubmitted: (_) => _search(),
                decoration: const InputDecoration(hintText: 'Buscar ciudad…', prefixIcon: Icon(Icons.search_rounded)))),
        const SizedBox(width: 8),
        IconButton.filledTonal(
            tooltip: 'Usar mi ubicación',
            icon: const Icon(Icons.my_location_rounded),
            onPressed: () async {
              final p = await askLocation(context);
              if (p != null) widget.onPlace(p);
            }),
      ]);
}
