import 'dart:io';
import 'dart:isolate';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;

class FEntry {
  const FEntry(this.path, this.size, this.mod);
  final String path;
  final int size;
  final int mod; // ms desde epoch
}

class ScanResult {
  ScanResult(this.files, this.dirs, this.errors, this.truncated);
  final List<FEntry> files;
  final int dirs, errors;
  final bool truncated;
  int get total => files.fold(0, (a, e) => a + e.size);
}

const kMaxScan = 300000;

/// Recorre una carpeta en un isolate. No sigue enlaces simbólicos.
Future<ScanResult> scanDir(String root, {int max = kMaxScan}) => Isolate.run(() => _scan(root, max));

Future<ScanResult> _scan(String root, int max) async {
  final files = <FEntry>[];
  var dirs = 0, errs = 0, trunc = false;
  final st = Directory(root).list(recursive: true, followLinks: false).handleError((_) {
    errs++;
  });
  await for (final e in st) {
    if (e is File) {
      try {
        final s = e.statSync();
        files.add(FEntry(e.path, s.size, s.modified.millisecondsSinceEpoch));
      } catch (_) {
        errs++;
      }
      if (files.length >= max) {
        trunc = true;
        break;
      }
    } else if (e is Directory) {
      dirs++;
    }
  }
  return ScanResult(files, dirs, errs, trunc);
}

/// Grupos de archivos idénticos (tamaño → hash parcial 64 KB → SHA-256 completo).
Future<List<List<FEntry>>> findDuplicates(List<FEntry> files, int minSize) => Isolate.run(() => _dupes(files, minSize));

Future<String?> _hash(String path, {int? limit}) async {
  try {
    final d = await sha256.bind(File(path).openRead(0, limit)).first;
    return d.toString();
  } catch (_) {
    return null;
  }
}

Future<List<List<FEntry>>> _dupes(List<FEntry> files, int minSize) async {
  const head = 65536;
  final bySize = <int, List<FEntry>>{};
  for (final f in files) {
    if (f.size > 0 && f.size >= minSize) bySize.putIfAbsent(f.size, () => []).add(f);
  }
  final out = <List<FEntry>>[];
  for (final g in bySize.values.where((g) => g.length > 1)) {
    final byHead = <String, List<FEntry>>{};
    for (final f in g) {
      final h = await _hash(f.path, limit: head);
      if (h != null) byHead.putIfAbsent(h, () => []).add(f);
    }
    for (final g2 in byHead.values.where((g) => g.length > 1)) {
      if (g2.first.size <= head) {
        out.add(g2);
        continue;
      }
      final byFull = <String, List<FEntry>>{};
      for (final f in g2) {
        final h = await _hash(f.path);
        if (h != null) byFull.putIfAbsent(h, () => []).add(f);
      }
      out.addAll(byFull.values.where((g) => g.length > 1));
    }
  }
  for (final g in out) {
    g.sort((a, b) => a.mod.compareTo(b.mod)); // el más antiguo primero
  }
  out.sort((a, b) => (b.first.size * (b.length - 1)).compareTo(a.first.size * (a.length - 1)));
  return out;
}

const categories = <String, List<String>>{
  'Imágenes': ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'heic', 'svg', 'tiff', 'raw', 'ico'],
  'Vídeo': ['mp4', 'mkv', 'avi', 'mov', 'wmv', 'webm', 'flv', 'm4v', '3gp'],
  'Audio': ['mp3', 'wav', 'flac', 'aac', 'ogg', 'm4a', 'opus', 'wma'],
  'Documentos': ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'md', 'odt', 'ods', 'csv', 'rtf', 'epub'],
  'Comprimidos': ['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'iso'],
  'Programas': ['exe', 'msi', 'apk', 'dll', 'bat', 'sh', 'aab'],
  'Código': ['dart', 'js', 'ts', 'py', 'java', 'kt', 'c', 'cpp', 'h', 'cs', 'go', 'rs', 'html', 'css', 'json', 'xml', 'yaml', 'yml'],
};

String categoryOf(String path) {
  final e = p.extension(path).toLowerCase().replaceFirst('.', '');
  for (final en in categories.entries) {
    if (en.value.contains(e)) return en.key;
  }
  return 'Otros';
}

/// Nodo del árbol de tamaños (carpeta o archivo).
class DNode {
  DNode(this.name, {this.isDir = false});
  final String name;
  final bool isDir;
  int size = 0;
  final Map<String, DNode> kids = {};
  List<DNode> sorted() => kids.values.toList()..sort((a, b) => b.size.compareTo(a.size));
}

class TreeResult {
  TreeResult(this.root, this.files, this.errors, this.truncated);
  final DNode root;
  final int files, errors;
  final bool truncated;
}

Future<TreeResult> scanTree(String root, {int max = kMaxScan}) => Isolate.run(() async {
      final r = await _scan(root, max);
      final top = DNode(p.basename(root).isEmpty ? root : p.basename(root), isDir: true);
      for (final f in r.files) {
        final parts = p.split(p.relative(f.path, from: root));
        var n = top;
        n.size += f.size;
        for (var i = 0; i < parts.length; i++) {
          final last = i == parts.length - 1;
          n = n.kids.putIfAbsent(parts[i], () => DNode(parts[i], isDir: !last));
          n.size += f.size;
        }
      }
      return TreeResult(top, r.files.length, r.errors, r.truncated);
    });
