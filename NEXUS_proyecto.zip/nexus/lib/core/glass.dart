import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

final themeMode = ValueNotifier<ThemeMode>(ThemeMode.dark);

ThemeData nexusTheme(Brightness b) {
  final dark = b == Brightness.dark;
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C7BFF), brightness: b),
    scaffoldBackgroundColor: Colors.transparent,
    appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0, centerTitle: false),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: (dark ? Colors.white : Colors.black).withOpacity(.07),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    ),
  );
}

void msg(BuildContext c, String t) {
  if (!c.mounted) return;
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
      content: Text(t), behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))));
}

void copy(BuildContext c, String t) {
  Clipboard.setData(ClipboardData(text: t));
  msg(c, 'Copiado');
}

class GlassBackground extends StatelessWidget {
  const GlassBackground({super.key});
  Widget _blob(double size, Color col, {double? top, double? left, double? right, double? bottom}) => Positioned(
      top: top,
      left: left,
      right: right,
      bottom: bottom,
      child: ImageFiltered(
          imageFilter: ImageFilter.blur(sigmaX: 70, sigmaY: 70),
          child: Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: col.withOpacity(.4)))));
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: dark
                  ? const [Color(0xFF0B1026), Color(0xFF1B1038), Color(0xFF081C2E)]
                  : const [Color(0xFFE6EEFF), Color(0xFFF3E8FF), Color(0xFFE0F7FA)])),
      child: Stack(children: [
        _blob(320, const Color(0xFF6C7BFF), top: -80, left: -60),
        _blob(360, const Color(0xFFFF6CCB), bottom: -100, right: -80),
        _blob(260, const Color(0xFF3DDCFF), top: 320, right: -120),
      ]),
    );
  }
}

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.radius = 24, this.onTap});
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final r = BorderRadius.circular(radius);
    return ClipRRect(
      borderRadius: r,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: r,
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [
              Colors.white.withOpacity(dark ? .16 : .6),
              Colors.white.withOpacity(dark ? .05 : .25),
            ]),
            border: Border.all(color: Colors.white.withOpacity(dark ? .22 : .75)),
          ),
          child: Stack(children: [
            Positioned.fill(
                child: IgnorePointer(
                    child: DecoratedBox(
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: const Alignment(0, -.2),
                                colors: [Colors.white.withOpacity(dark ? .14 : .35), Colors.white.withOpacity(0)]))))),
            Material(
                color: Colors.transparent,
                child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child))),
          ]),
        ),
      ),
    );
  }
}

class GlassButton extends StatelessWidget {
  const GlassButton(this.label, {super.key, this.icon, this.onTap});
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Opacity(
      opacity: onTap == null ? .45 : 1,
      child: GlassCard(
          radius: 18,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          onTap: onTap,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          ])));
}

class GlassPage extends StatelessWidget {
  const GlassPage({super.key, required this.title, required this.child, this.actions, this.maxWidth = 900, this.bottom});
  final String title;
  final Widget child;
  final List<Widget>? actions;
  final double maxWidth;
  final PreferredSizeWidget? bottom;
  @override
  Widget build(BuildContext context) => Stack(children: [
        const Positioned.fill(child: GlassBackground()),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), actions: actions, bottom: bottom),
          body: SafeArea(
              child: Center(child: ConstrainedBox(constraints: BoxConstraints(maxWidth: maxWidth), child: child))),
        ),
      ]);
}

/// Lista de pares clave/valor en tarjeta de cristal.
class KV extends StatelessWidget {
  const KV(this.data, {super.key});
  final Map<String, String> data;
  @override
  Widget build(BuildContext context) => GlassCard(
      child: Column(
          children: data.entries
              .map((e) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(flex: 4, child: Text(e.key, style: TextStyle(color: Theme.of(context).hintColor))),
                    Expanded(flex: 6, child: SelectableText(e.value, style: const TextStyle(fontWeight: FontWeight.w600))),
                  ])))
              .toList()));
}
