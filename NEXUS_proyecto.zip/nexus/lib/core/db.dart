import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class NexusDb {
  static Database? _db;

  static Future<void> init() async {
    if (!kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
    final dir = await getApplicationSupportDirectory();
    await dir.create(recursive: true);
    _db = await openDatabase(p.join(dir.path, 'nexus.db'), version: 1, onCreate: (db, v) async {
      await db.execute('CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, body TEXT, updated INTEGER)');
      await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
    });
  }

  static Future<String?> getSetting(String k) async {
    final r = await _db!.query('settings', where: 'key=?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['value'] as String?;
  }

  static Future<void> setSetting(String k, String v) =>
      _db!.insert('settings', {'key': k, 'value': v}, conflictAlgorithm: ConflictAlgorithm.replace);

  static Future<List<Map<String, Object?>>> notes([String q = '']) => _db!.query('notes',
      where: q.isEmpty ? null : 'title LIKE ? OR body LIKE ?',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
      orderBy: 'updated DESC');

  static Future<void> saveNote({int? id, required String title, required String body}) async {
    final v = {'title': title, 'body': body, 'updated': DateTime.now().millisecondsSinceEpoch};
    if (id == null) {
      await _db!.insert('notes', v);
    } else {
      await _db!.update('notes', v, where: 'id=?', whereArgs: [id]);
    }
  }

  static Future<void> deleteNote(int id) => _db!.delete('notes', where: 'id=?', whereArgs: [id]);
}
