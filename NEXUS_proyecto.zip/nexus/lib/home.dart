import 'dart:ui';
import 'package:flutter/material.dart';
import 'core/db.dart';
import 'core/glass.dart';
import 'tools/registry.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _H();
}

class _H extends State<HomePage> {
  String q = '';
  String cat = 'Todas';
  Set<String> favs = {};
  List<String> recent = [];

  @override
  void initState() {
    super.initState();
    NexusDb.getSetting('favs').then((s) {
      if (s != null && mounted) setState(() => favs = s.split(',').where((e) => e.isNotEmpty).toSet());
    });
    NexusDb.getSetting('recent').then((s) {
      if (s != null && mounted) setState(() => recent = s.split(',').where((e) => e.isNotEmpty).toList());
    });
  }

  NexusTool? _byId(String id) {
    for (final t in nexusTools) {
      if (t.id == id) return t;
    }
    return null;
  }

  Future<void> _open(NexusTool t) async {
    recent = [t.id, ...recent.where((e) => e != t.id)].take(6).toList();
    NexusDb.setSetting('recent', recent.join(','));
    await Navigator.of(context).push(PageRouteBuilder(
        pageBuilder: (ctx, a, b) => t.builder(ctx),
        transitionDuration: const Duration(milliseconds: 380),
        transitionsBuilder: (ctx, a, b, child) => FadeTransition(
            opacity: a,
            child: ScaleTransition(scale: Tween(begin: .96, end: 1.0).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)), child: child))));
    if (mounted) setState(() {});
  }

  void _fav(NexusTool t) {
    setState(() => favs.contains(t.id) ? favs.remove(t.id) : favs.add(t.id));
    NexusDb.setSetting('favs', favs.join(','));
  }

  Widget _tile(NexusTool t, int i) {
    final fav = favs.contains(t.id);
    return TweenAnimationBuilder<double>(
        key: ValueKey('${t.id}$cat$q'),
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 300 + (i * 40).clamp(0, 400)),
        curve: Curves.easeOutCubic,
        builder: (_, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 22 * (1 - v)), child: child)),
        child: GestureDetector(
            onLongPress: () => _fav(t),
            child: GlassCard(
                onTap: () => _open(t),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [t.color, t.color.withOpacity(.55)]),
                            boxShadow: [BoxShadow(color: t.color.withOpacity(.45), blurRadius: 14, offset: const Offset(0, 6))]),
                        child: Icon(t.icon, color: Colors.white, size: 24)),
                    const Spacer(),
                    InkResponse(onTap: () => _fav(t), child: Icon(fav ? Icons.star_rounded : Icons.star_outline_rounded, color: fav ? const Color(0xFFFFC857) : Theme.of(context).hintColor, size: 22)),
                  ]),
                  const Spacer(),
                  Text(t.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5, letterSpacing: -.2)),
                  const SizedBox(height: 2),
                  Text(t.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
                ]))));
  }

  Widget _grid(List<NexusTool> l) => SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      sliver: SliverGrid(
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 210, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.05),
          delegate: SliverChildBuilderDelegate((c, i) => _tile(l[i], i), childCount: l.length)));

  Widget _head(String t) => SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 10), child: Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: -.3))));

  Widget _quick(NexusTool t) => Padding(
      padding: const EdgeInsets.only(right: 10),
      child: GlassCard(
          radius: 22,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          onTap: () => _open(t),
          child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(t.icon, color: t.color, size: 22), const SizedBox(width: 8), Text(t.name, style: const TextStyle(fontWeight: FontWeight.w700))])));

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final cats = ['Todas', ...{for (final t in nexusTools) t.cat}];
    final ql = q.trim().toLowerCase();
    final filtered = nexusTools.where((t) => (cat == 'Todas' || t.cat == cat) && (ql.isEmpty || '${t.name} ${t.desc} ${t.cat}'.toLowerCase().contains(ql))).toList();
    final favList = favs.map(_byId).whereType<NexusTool>().toList();
    final recentList = recent.map(_byId).whereType<NexusTool>().take(5).toList();
    final searching = ql.isNotEmpty || cat != 'Todas';
    return Stack(children: [
      const Positioned.fill(child: GlassBackground()),
      Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
              child: Center(
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 1100),
                      child: CustomScrollView(slivers: [
                        SliverToBoxAdapter(
                            child: Padding(
                                padding: const EdgeInsets.fromLTRB(20, 20, 12, 0),
                                child: Row(children: [
                                  Expanded(
                                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    ShaderMask(
                                        shaderCallback: (r) => const LinearGradient(colors: [Color(0xFF6C7BFF), Color(0xFFFF6CCB), Color(0xFF3DDCFF)]).createShader(r),
                                        child: const Text('NEXUS', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, letterSpacing: 4, color: Colors.white))),
                                    Text('${nexusTools.length} herramientas para tu día a día', style: TextStyle(color: Theme.of(context).hintColor)),
                                  ])),
                                  IconButton.filledTonal(
                                      icon: Icon(dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
                                      onPressed: () {
                                        themeMode.value = dark ? ThemeMode.light : ThemeMode.dark;
                                        NexusDb.setSetting('theme', dark ? 'light' : 'dark');
                                      }),
                                ]))),
                        SliverToBoxAdapter(
                            child: Padding(
                                padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(22),
                                    child: BackdropFilter(
                                        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                                        child: TextField(
                                            onChanged: (v) => setState(() => q = v),
                                            decoration: InputDecoration(
                                                hintText: 'Buscar herramienta…',
                                                prefixIcon: const Icon(Icons.search_rounded),
                                                contentPadding: const EdgeInsets.symmetric(vertical: 16),
                                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: Colors.white.withOpacity(.2)))),
                                          ))))),
                        SliverToBoxAdapter(
                            child: SizedBox(
                                height: 56,
                                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), children: [
                                  for (final c in cats) Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(c), selected: cat == c, onSelected: (_) => setState(() => cat = c))),
                                ]))),
                        if (!searching && recentList.isNotEmpty) ...[
                          _head('Accesos rápidos'),
                          SliverToBoxAdapter(child: SizedBox(height: 56, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.only(left: 16), children: [for (final t in recentList) _quick(t)]))),
                        ],
                        if (!searching && favList.isNotEmpty) ...[_head('Favoritos'), _grid(favList)],
                        _head(searching ? 'Resultados (${filtered.length})' : 'Todas las herramientas'),
                        if (filtered.isEmpty) const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Nada encontrado')))) else _grid(filtered),
                        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('Mantén pulsada una tarjeta o toca ★ para añadir a favoritos', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))))),
                      ]))))),
    ]);
  }
}
