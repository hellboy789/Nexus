import 'package:flutter/material.dart';
import 'core/db.dart';
import 'core/glass.dart';
import 'tools/registry.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void _open(BuildContext c, NexusTool t) => Navigator.of(c).push(PageRouteBuilder(
      pageBuilder: (ctx, a, b) => t.builder(ctx),
      transitionsBuilder: (ctx, a, b, child) => FadeTransition(
          opacity: a,
          child: SlideTransition(
              position: Tween(begin: const Offset(0, .04), end: Offset.zero)
                  .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
              child: child))));

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return GlassPage(
      title: 'NEXUS',
      maxWidth: 1100,
      actions: [
        IconButton(
            icon: Icon(dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
            onPressed: () {
              themeMode.value = dark ? ThemeMode.light : ThemeMode.dark;
              NexusDb.setSetting('theme', dark ? 'light' : 'dark');
            }),
      ],
      child: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 220, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: 1.0),
        itemCount: nexusTools.length,
        itemBuilder: (ctx, i) {
          final t = nexusTools[i];
          return TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: Duration(milliseconds: 350 + i * 60),
            curve: Curves.easeOutCubic,
            builder: (_, v, child) =>
                Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 24 * (1 - v)), child: child)),
            child: GlassCard(
              onTap: () => _open(ctx, t),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        gradient: LinearGradient(colors: [t.color, t.color.withOpacity(.55)])),
                    child: Icon(t.icon, color: Colors.white)),
                const Spacer(),
                Text(t.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 2),
                Text(t.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(ctx).hintColor, fontSize: 12)),
              ]),
            ),
          );
        },
      ),
    );
  }
}
