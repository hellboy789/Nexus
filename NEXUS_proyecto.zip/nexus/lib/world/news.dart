import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/glass.dart';
import '../core/net.dart';

/// Noticias internacionales agregadas por GDELT DOC 2.0 (gratuito, sin clave; ~1 petición/5 s).
class NewsPage extends StatefulWidget {
  const NewsPage({super.key, this.title = 'Noticias del mundo', this.queries});
  final String title;
  final Map<String, String>? queries;
  @override
  State<NewsPage> createState() => _NP();
}

class _NP extends State<NewsPage> {
  late final Map<String, String> qs = widget.queries ??
      {
        'Conflictos': '(war OR "armed conflict" OR ceasefire OR offensive)',
        'Emergencias': '(earthquake OR wildfire OR flood OR volcano OR hurricane)',
        'Mundo': '(international OR diplomacy OR summit OR sanctions)',
      };
  late String sel = qs.keys.first;
  String lang = 'spanish', span = '24h';
  List<Map> arts = [];
  bool loading = false;
  String? error;
  DateTime? updated;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final q = '${qs[sel]} sourcelang:$lang';
      final j = await getJson('https://api.gdeltproject.org/api/v2/doc/doc?query=${Uri.encodeQueryComponent(q)}&mode=artlist&format=json&maxrecords=60&sort=datedesc&timespan=$span');
      final seen = <String>{};
      final l = <Map>[];
      for (final a in ((j['articles'] as List?) ?? [])) {
        if (seen.add(('${a['title']}').toLowerCase())) l.add(a as Map);
      }
      if (mounted) setState(() { arts = l; updated = DateTime.now(); });
    } catch (e) {
      if (mounted) setState(() { error = '$e'; arts = []; });
    }
    if (mounted) setState(() => loading = false);
  }

  String _date(String? s) {
    if (s == null || s.length < 13) return '';
    return '${s.substring(6, 8)}/${s.substring(4, 6)} ${s.substring(9, 11)}:${s.substring(11, 13)} UTC';
  }

  @override
  Widget build(BuildContext context) => GlassPage(
      title: widget.title,
      maxWidth: 800,
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: loading ? null : _load)],
      child: Column(children: [
        SizedBox(
            height: 50,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), children: [
              for (final k in qs.keys) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text(k), selected: sel == k, onSelected: (_) { sel = k; _load(); })),
              for (final e in {'spanish': 'ES', 'english': 'EN', 'french': 'FR'}.entries) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text(e.value), selected: lang == e.key, onSelected: (_) { lang = e.key; _load(); })),
              for (final e in {'24h': '24 h', '3d': '3 días', '7d': '7 días'}.entries) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text(e.value), selected: span == e.key, onSelected: (_) { span = e.key; _load(); })),
            ])),
        Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : error != null
                    ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center)))
                    : arts.isEmpty
                        ? const Center(child: Text('Sin artículos para este filtro'))
                        : ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: arts.length,
                            itemBuilder: (_, i) {
                              final a = arts[i];
                              return Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: GlassCard(
                                      onTap: () => launchUrl(Uri.parse('${a['url']}'), mode: LaunchMode.externalApplication),
                                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                        Text('${a['title']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                                        const SizedBox(height: 4),
                                        Text('${a['domain']} · ${a['sourcecountry'] ?? ''} · ${_date(a['seendate'] as String?)}', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                                      ])));
                            })),
        Padding(
            padding: const EdgeInsets.all(8),
            child: Text('Agregador automático GDELT${updated == null ? '' : ' · actualizado ${updated!.hour.toString().padLeft(2, '0')}:${updated!.minute.toString().padLeft(2, '0')}'}. Los titulares NO están verificados por NEXUS: contrasta varias fuentes.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Theme.of(context).hintColor))),
      ]));
}
