import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:xml/xml.dart';
import '../core/glass.dart';
import '../core/net.dart';

class _Feed {
  const _Feed(this.name, this.url, this.lang);
  final String name, url, lang;
}

// RSS públicos de medios internacionales (sin clave). Se consultan bajo demanda y con caché de 10 min.
const _feeds = [
  _Feed('BBC Mundo', 'https://feeds.bbci.co.uk/mundo/rss.xml', 'es'),
  _Feed('DW Español', 'https://rss.dw.com/xml/rss-sp-all', 'es'),
  _Feed('Noticias ONU', 'https://news.un.org/feed/subscribe/es/news/all/rss.xml', 'es'),
  _Feed('BBC World', 'https://feeds.bbci.co.uk/news/world/rss.xml', 'en'),
  _Feed('Al Jazeera', 'https://www.aljazeera.com/xml/rss/all.xml', 'en'),
  _Feed('DW English', 'https://rss.dw.com/xml/rss-en-world', 'en'),
];

class _Art {
  _Art(this.title, this.link, this.source, this.date, this.summary);
  final String title, link, source, summary;
  final DateTime? date;
}

const _months = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6, 'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12};

DateTime? _parseDate(String? s) {
  if (s == null) return null;
  final iso = DateTime.tryParse(s.trim());
  if (iso != null) return iso;
  final m = RegExp(r'(\d{1,2})\s+([A-Za-z]{3})[a-z]*\s+(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?\s*([+-]\d{4}|GMT|UT|Z)?').firstMatch(s);
  if (m == null) return null;
  var d = DateTime.utc(int.parse(m[3]!), _months[m[2]!.toLowerCase()] ?? 1, int.parse(m[1]!), int.parse(m[4]!), int.parse(m[5]!), int.tryParse(m[6] ?? '0') ?? 0);
  final tz = m[7];
  if (tz != null && RegExp(r'^[+-]\d{4}$').hasMatch(tz)) {
    final off = Duration(hours: int.parse(tz.substring(1, 3)), minutes: int.parse(tz.substring(3, 5)));
    d = tz.startsWith('+') ? d.subtract(off) : d.add(off);
  }
  return d;
}

String _norm(String s) => s.toLowerCase().replaceAll('á', 'a').replaceAll('é', 'e').replaceAll('í', 'i').replaceAll('ó', 'o').replaceAll('ú', 'u').replaceAll('ñ', 'n');

const _cats = {
  'Conflictos': ['guerra', 'war', 'conflict', 'conflicto', 'ataque', 'attack', 'ceasefire', 'alto el fuego', 'militar', 'military', 'offensive', 'ofensiva', 'bombard', 'strike', 'hostilit', 'troops', 'tropas', 'missile', 'misil', 'drone', 'dron'],
  'Emergencias': ['terremoto', 'earthquake', 'sismo', 'incendio', 'wildfire', 'fire', 'inundacion', 'flood', 'volcan', 'huracan', 'hurricane', 'typhoon', 'tifon', 'ciclon', 'cyclone', 'tsunami', 'storm', 'tormenta', 'sequia', 'drought', 'emergency', 'emergencia'],
  'Economía': ['econom', 'mercado', 'market', 'inflacion', 'inflation', 'bolsa', 'banco', 'bank', 'trade', 'comercio', 'arancel', 'tariff'],
};

/// Noticias internacionales por RSS (caché 10 min, bajo demanda) + GDELT opcional con throttle y backoff.
class NewsPage extends StatefulWidget {
  const NewsPage({super.key, this.title = 'Noticias del mundo', this.keywords});
  final String title;
  final List<String>? keywords;
  @override
  State<NewsPage> createState() => _NP();
}

class _NP extends State<NewsPage> {
  String cat = 'Todas', lang = 'es', q = '';
  List<_Art> all = [];
  final status = <String, String>{};
  bool loading = false;
  DateTime? updated;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<List<_Art>> _one(_Feed f) async {
    final xml = XmlDocument.parse(await getText(f.url, ttl: const Duration(minutes: 10)));
    final out = <_Art>[];
    for (final it in xml.findAllElements('item')) {
      String t(String n) => it.getElement(n)?.innerText.trim() ?? '';
      final title = t('title'), link = t('link');
      if (title.isEmpty || link.isEmpty) continue;
      out.add(_Art(title, link, f.name, _parseDate(t('pubDate')), t('description').replaceAll(RegExp(r'<[^>]*>'), '').trim()));
    }
    return out;
  }

  Future<void> _load() async {
    setState(() { loading = true; status.clear(); });
    final res = await Future.wait(_feeds.where((f) => f.lang == lang).map((f) async {
      try {
        final l = await _one(f);
        status[f.name] = 'OK · ${l.length}';
        return l;
      } catch (e) {
        status[f.name] = '$e';
        return <_Art>[];
      }
    }));
    final l = res.expand((x) => x).toList()..sort((a, b) => (b.date ?? DateTime(2000)).compareTo(a.date ?? DateTime(2000)));
    if (mounted) setState(() { all = l; loading = false; updated = DateTime.now(); });
  }

  Future<void> _gdelt() async {
    final kw = widget.keywords;
    final term = kw != null && kw.isNotEmpty ? '(${kw.take(4).join(' OR ')})' : (q.trim().isNotEmpty ? q.trim() : '(war OR conflict OR earthquake)');
    setState(() => loading = true);
    try {
      await throttle('gdelt', const Duration(seconds: 6));
      final j = await getJson('https://api.gdeltproject.org/api/v2/doc/doc?query=${Uri.encodeQueryComponent('$term sourcelang:${lang == 'es' ? 'spanish' : 'english'}')}&mode=artlist&format=json&maxrecords=40&sort=datedesc&timespan=3d', ttl: const Duration(minutes: 15), retries: 2, timeout: const Duration(seconds: 20));
      final extra = <_Art>[];
      for (final a in ((j['articles'] as List?) ?? [])) {
        final sd = '${a['seendate']}';
        extra.add(_Art('${a['title']}', '${a['url']}', 'GDELT · ${a['domain']}', sd.length >= 15 ? DateTime.tryParse('${sd.substring(0, 8)}T${sd.substring(9, 15)}Z') : null, ''));
      }
      if (mounted) setState(() { all = [...all, ...extra]..sort((a, b) => (b.date ?? DateTime(2000)).compareTo(a.date ?? DateTime(2000))); status['GDELT'] = 'OK · ${extra.length}'; });
    } catch (e) {
      if (mounted) setState(() => status['GDELT'] = '$e');
    }
    if (mounted) setState(() => loading = false);
  }

  List<_Art> get shown {
    final kw = (widget.keywords ?? []).map(_norm).toList();
    final words = cat == 'Todas' ? <String>[] : _cats[cat]!;
    final qq = _norm(q.trim());
    final seen = <String>{};
    return all.where((a) {
      final t = _norm('${a.title} ${a.summary}');
      if (kw.isNotEmpty && !kw.any(t.contains)) return false;
      if (words.isNotEmpty && !words.any(t.contains)) return false;
      if (qq.isNotEmpty && !t.contains(qq)) return false;
      return seen.add(_norm(a.title));
    }).toList();
  }

  String _d(DateTime? d) => d == null ? '' : '${d.toLocal().day.toString().padLeft(2, '0')}/${d.toLocal().month.toString().padLeft(2, '0')} ${d.toLocal().hour.toString().padLeft(2, '0')}:${d.toLocal().minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final l = shown;
    final bad = status.entries.where((e) => !e.value.startsWith('OK')).toList();
    return GlassPage(
        title: widget.title,
        maxWidth: 800,
        actions: [
          IconButton(tooltip: 'Buscar también en GDELT (bajo demanda)', icon: const Icon(Icons.travel_explore_rounded), onPressed: loading ? null : _gdelt),
          IconButton(tooltip: 'Actualizar', icon: const Icon(Icons.refresh_rounded), onPressed: loading ? null : _load),
        ],
        child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 0), child: TextField(onChanged: (v) => setState(() => q = v), decoration: const InputDecoration(hintText: 'Filtrar por país o palabra…', prefixIcon: Icon(Icons.search_rounded)))),
          SizedBox(
              height: 50,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), children: [
                for (final k in ['Todas', ..._cats.keys]) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text(k), selected: cat == k, onSelected: (_) => setState(() => cat = k))),
                for (final e in {'es': 'ES', 'en': 'EN'}.entries) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(label: Text(e.value), selected: lang == e.key, onSelected: (_) { lang = e.key; _load(); })),
              ])),
          if (bad.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(bad.map((e) => '⚠ ${e.key}: ${e.value}').join('\n'), style: const TextStyle(fontSize: 11, color: Colors.orangeAccent))),
          Expanded(
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : l.isEmpty
                      ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(all.isEmpty ? 'No se pudo cargar ninguna fuente. Revisa tu conexión y pulsa actualizar.' : 'Sin titulares para este filtro. Prueba otra categoría o la búsqueda GDELT (icono del globo).', textAlign: TextAlign.center)))
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: l.length,
                          itemBuilder: (_, i) {
                            final a = l[i];
                            return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: GlassCard(
                                    onTap: () => launchUrl(Uri.parse(a.link), mode: LaunchMode.externalApplication),
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Text(a.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                                      if (a.summary.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(a.summary, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
                                      const SizedBox(height: 4),
                                      Text('${a.source} · ${_d(a.date)}', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
                                    ])));
                          })),
          Padding(
              padding: const EdgeInsets.all(8),
              child: Text('Fuentes: RSS públicos de BBC, DW, ONU y Al Jazeera${updated == null ? '' : ' · actualizado ${_d(updated)}'}. Caché de 10 min. Titulares sin verificar por NEXUS.', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Theme.of(context).hintColor))),
        ]));
  }
}
