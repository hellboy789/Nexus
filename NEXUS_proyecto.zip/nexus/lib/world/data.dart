import 'package:latlong2/latlong.dart';

/// Datos EDITORIALES ESTÁTICOS (no en tiempo real). Solo hechos de contexto
/// ampliamente documentados; sin cifras de víctimas ni posiciones tácticas.
/// Revisados con información hasta junio de 2026: el estado actual puede haber cambiado.
class Conflict {
  const Conflict(this.name, this.region, this.pos, this.since, this.parties, this.context, this.timeline, this.newsQuery, this.wiki);
  final String name, region, since, context, newsQuery, wiki;
  final LatLng pos;
  final List<String> parties;
  final List<(String, String)> timeline;
}

const conflictsNote = 'Ficha editorial estática, no en tiempo real. Revisada con datos hasta jun 2026; el estado actual puede haber cambiado. Posición = centro aproximado de la región, no zona de operaciones.';

const conflicts = <Conflict>[
  Conflict('Ucrania', 'Europa del Este', LatLng(48.5, 36.0), '2014', ['Rusia', 'Ucrania'],
      'Conflicto iniciado en 2014 con la anexión rusa de Crimea y los combates en el Donbás; escalado en 2022 con la invasión rusa a gran escala.',
      [('2014-02/03', 'Rusia anexiona Crimea (no reconocido por la mayoría de la ONU)'), ('2014-04', 'Comienzan los combates en el Donbás'), ('2022-02-24', 'Invasión rusa a gran escala')],
      'Ukraine Russia war', 'Guerra ruso-ucraniana'),
  Conflict('Sudán', 'África oriental', LatLng(15.5, 32.5), '2023', ['Fuerzas Armadas Sudanesas (SAF)', 'Fuerzas de Apoyo Rápido (RSF)'],
      'Guerra entre las dos principales fuerzas armadas del país, con grave crisis humanitaria y desplazamiento según agencias de la ONU.',
      [('2019-04', 'Caída de Omar al-Bashir'), ('2021-10-25', 'Golpe militar'), ('2023-04-15', 'Estallan los combates entre SAF y RSF')],
      'Sudan RSF army war', 'Guerra civil sudanesa (2023)'),
  Conflict('Israel – Gaza', 'Oriente Medio', LatLng(31.4, 34.4), '2023', ['Israel', 'Hamás y otros grupos armados'],
      'Conflicto armado en la Franja de Gaza iniciado tras el ataque de Hamás del 7 de octubre de 2023. Es un asunto muy disputado: consulta varias fuentes. El estado actual (alto el fuego, negociaciones) debe verificarse en las noticias.',
      [('2023-10-07', 'Ataque de Hamás a Israel y comienzo de las operaciones militares en Gaza')],
      'Gaza Israel Hamas', 'Guerra de Gaza'),
  Conflict('Myanmar', 'Sudeste asiático', LatLng(21.0, 96.0), '2021', ['Junta militar (Tatmadaw)', 'Fuerzas de resistencia y organizaciones armadas étnicas'],
      'Conflicto armado y político tras el golpe militar de febrero de 2021.',
      [('2021-02-01', 'Golpe militar y detención de dirigentes electos')], 'Myanmar military resistance conflict', 'Conflicto armado en Myanmar'),
  Conflict('Yemen', 'Península arábiga', LatLng(15.5, 47.5), '2014', ['Gobierno reconocido', 'Huzíes (Ansar Alá)', 'Coalición liderada por Arabia Saudí'],
      'Guerra civil con intervención extranjera y una de las mayores crisis humanitarias según la ONU.',
      [('2014-09', 'Los huzíes toman Saná'), ('2015-03-26', 'Intervención de la coalición liderada por Arabia Saudí')], 'Yemen Houthi war', 'Guerra civil yemení'),
  Conflict('Siria', 'Oriente Medio', LatLng(35.0, 38.5), '2011', ['Autoridades de transición', 'Diversos grupos armados', 'Actores internacionales'],
      'Conflicto iniciado en 2011; el gobierno de Bashar al-Asad cayó en diciembre de 2024. La situación sigue siendo inestable.',
      [('2011-03', 'Comienzan las protestas y el conflicto'), ('2024-12-08', 'Cae el gobierno de Bashar al-Asad')], 'Syria conflict', 'Guerra civil siria'),
  Conflict('RD Congo (este)', 'África central', LatLng(-1.7, 29.0), '2021', ['Gobierno de la RDC', 'M23', 'Otros grupos armados'],
      'Violencia en Kivu Norte y Sur con múltiples grupos armados; el M23 resurgió en 2021.',
      [('2021-11', 'El M23 reanuda su ofensiva'), ('2025-01', 'El M23 toma Goma')], 'Congo M23 Goma', 'Conflicto del Kivu'),
  Conflict('Sahel central', 'África occidental', LatLng(14.5, -1.5), '2012', ['Gobiernos de Mali, Burkina Faso y Níger', 'Grupos yihadistas', 'Grupos rebeldes'],
      'Insurgencia yihadista y rebelde desde 2012 en Mali, extendida a Burkina Faso y Níger, con varios golpes de Estado.',
      [('2012', 'Rebelión tuareg y avance yihadista en el norte de Mali'), ('2020-08', 'Golpe en Mali'), ('2023-07-26', 'Golpe en Níger')], 'Sahel Mali Burkina Faso jihadist', 'Conflicto en el Sahel'),
  Conflict('Somalia', 'Cuerno de África', LatLng(2.5, 45.5), '2006', ['Gobierno federal', 'Al-Shabaab', 'Fuerzas de la Unión Africana'],
      'Insurgencia de Al-Shabaab contra el gobierno federal somalí y las fuerzas aliadas.',
      [('2006-2007', 'Surge la insurgencia de Al-Shabaab y se despliega la misión de la UA')], 'Somalia al-Shabaab', 'Al-Shabaab'),
  Conflict('Etiopía', 'Cuerno de África', LatLng(11.0, 38.5), '2020', ['Gobierno federal', 'Fuerzas de Tigray (2020-2022)', 'Milicias Fano (Amhara)'],
      'Guerra de Tigray (2020-2022) y posterior conflicto en la región Amhara.',
      [('2020-11', 'Comienza la guerra de Tigray'), ('2022-11-02', 'Acuerdo de Pretoria')], 'Ethiopia Amhara Fano Tigray', 'Guerra de Tigray'),
  Conflict('Nigeria (noreste)', 'África occidental', LatLng(11.5, 13.0), '2009', ['Gobierno de Nigeria', 'Boko Haram y facción ISWAP'],
      'Insurgencia yihadista en el noreste de Nigeria y la cuenca del lago Chad.',
      [('2009-07', 'Levantamiento de Boko Haram')], 'Nigeria Boko Haram ISWAP', 'Insurgencia de Boko Haram'),
  Conflict('Cabo Delgado', 'África austral', LatLng(-12.5, 40.0), '2017', ['Gobierno de Mozambique', 'Insurgentes yihadistas', 'Fuerzas aliadas regionales'],
      'Insurgencia en el norte de Mozambique iniciada en 2017.',
      [('2017-10', 'Primeros ataques en Mocímboa da Praia')], 'Mozambique Cabo Delgado insurgency', 'Insurgencia de Cabo Delgado'),
];

const conflictSources = <(String, String)>[
  ('UCDP (Universidad de Uppsala)', 'https://ucdp.uu.se/'),
  ('International Crisis Group · CrisisWatch', 'https://www.crisisgroup.org/crisiswatch'),
  ('Noticias ONU', 'https://news.un.org/es/'),
  ('ACLED', 'https://acleddata.com/'),
];
