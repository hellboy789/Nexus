import 'package:latlong2/latlong.dart';
import '../core/net.dart';

class Aircraft {
  Aircraft(this.hex, this.call, this.reg, this.type, this.pos, this.altM, this.kmh, this.track, this.vrate);
  final String hex, call, reg, type;
  final LatLng pos;
  final double? altM, kmh, track, vrate;
}

class AircraftResult {
  AircraftResult(this.list, this.provider, this.time, this.failures);
  final List<Aircraft> list;
  final String provider;
  final DateTime time;
  final List<String> failures;
}

double? _n(dynamic v) => v is num ? v.toDouble() : null;

List<Aircraft> _parseAdsb(dynamic j) {
  final raw = (j['ac'] ?? j['aircraft']) as List? ?? [];
  final out = <Aircraft>[];
  for (final a in raw) {
    final lat = _n(a['lat']), lon = _n(a['lon']);
    if (lat == null || lon == null) continue;
    if (a['alt_baro'] == 'ground') continue;
    final alt = _n(a['alt_baro']);
    final gs = _n(a['gs']);
    out.add(Aircraft('${a['hex']}', '${a['flight'] ?? ''}'.trim(), '${a['r'] ?? ''}', '${a['t'] ?? ''}', LatLng(lat, lon), alt == null ? null : alt * 0.3048, gs == null ? null : gs * 1.852, _n(a['track']), _n(a['baro_rate']) == null ? null : _n(a['baro_rate'])! * 0.00508));
  }
  return out;
}

/// Proveedores públicos de ADS-B, probados en orden. Caché de 15 s.
/// adsb.lol (ODbL), airplanes.live (no comercial, 1 petición/s), adsb.fi (open data) y OpenSky como último recurso.
Future<AircraftResult> fetchAircraft(LatLng c, double radiusNm) async {
  final r = radiusNm.clamp(10, 250).round();
  final lat = c.latitude.toStringAsFixed(3), lon = c.longitude.toStringAsFixed(3);
  final fails = <String>[];
  final providers = <(String, String)>[
    ('adsb.lol', 'https://api.adsb.lol/v2/point/$lat/$lon/$r'),
    ('airplanes.live', 'https://api.airplanes.live/v2/point/$lat/$lon/$r'),
    ('adsb.fi', 'https://opendata.adsb.fi/api/v2/lat/$lat/lon/$lon/dist/$r'),
  ];
  for (final p in providers) {
    try {
      await throttle(p.$1, const Duration(seconds: 1));
      final j = await getJson(p.$2, ttl: const Duration(seconds: 15), timeout: const Duration(seconds: 10), retries: 0);
      return AircraftResult(_parseAdsb(j), p.$1, DateTime.now(), fails);
    } catch (e) {
      fails.add('${p.$1}: $e');
    }
  }
  try {
    final d = r / 60.0;
    final j = await getJson('https://opensky-network.org/api/states/all?lamin=${(c.latitude - d).toStringAsFixed(2)}&lomin=${(c.longitude - d).toStringAsFixed(2)}&lamax=${(c.latitude + d).toStringAsFixed(2)}&lomax=${(c.longitude + d).toStringAsFixed(2)}', ttl: const Duration(seconds: 30), timeout: const Duration(seconds: 12), retries: 0);
    final out = <Aircraft>[];
    for (final s in ((j['states'] as List?) ?? [])) {
      if (s[5] == null || s[6] == null || s[8] == true) continue;
      out.add(Aircraft('${s[0]}', '${s[1] ?? ''}'.trim(), '', '', LatLng((s[6] as num).toDouble(), (s[5] as num).toDouble()), _n(s[7]), _n(s[9]) == null ? null : _n(s[9])! * 3.6, _n(s[10]), _n(s[11])));
    }
    return AircraftResult(out, 'OpenSky', DateTime.now(), fails);
  } catch (e) {
    fails.add('OpenSky: $e');
  }
  throw NetError('Ningún proveedor de tráfico aéreo respondió.\n${fails.join('\n')}');
}
