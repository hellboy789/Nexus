import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/glass.dart';
import '../core/net.dart';
import 'data.dart';
import 'news.dart';

class _Layer {
  const _Layer(this.id, this.label, this.icon, this.color, this.note);
  final String id, label, note;
  final IconData icon;
  final Color color;
}

const _layers = [
  _Layer('conflicts', 'Conflictos', Icons.shield_outlined, Color(0xFFE5484D), 'Editorial estática'),
  _Layer('quakes', 'Terremotos', Icons.vibration_rounded, Color(0xFFFFA05A), 'USGS · M4.5+'),
  _Layer('fires', 'Incendios', Icons.local_fire_department_rounded, Color(0xFFFF6B3D), 'NASA EONET'),
  _Layer('volcanoes', 'Volcanes', Icons.landscape_rounded, Color(0xFFB5651D), 'NASA EONET'),
  _Layer('floods', 'Inundaciones', Icons.water_rounded, Color(0xFF3DA5FF), 'NASA EONET'),
  _Layer('storms', 'Meteo extrema', Icons.thunderstorm_rounded, Color(0xFF9B7BFF), 'NASA EONET'),
  _Layer('air', 'Calidad del aire', Icons.air_rounded, Color(0xFF47C1BF), 'Open-Meteo (modelo CAMS)'),
  _Layer('aircraft', 'Aviones', Icons.flight_rounded, Color(0xFFFFFFFF), 'OpenSky · zoom ≥ 4'),
  _Layer('ships', 'Barcos', Icons.directions_boat_rounded, Color(0xFF5AA9FF), 'Digitraffic · solo Finlandia/Báltico'),
  _Layer('iss', 'ISS', Icons.satellite_alt_rounded, Color(0xFFFFC857), 'wheretheiss.at'),
  _Layer('cables', 'Cables submarinos', Icons.cable_rounded, Color(0xFF2FC4A0), 'TeleGeography'),
];

const _cities = {
  'Madrid': [40.42, -3.70], 'París': [48.86, 2.35], 'Londres': [51.51, -0.13], 'Berlín': [52.52, 13.40], 'Roma': [41.90, 12.50],
  'Moscú': [55.76, 37.62], 'El Cairo': [30.04, 31.24], 'Lagos': [6.52, 3.38], 'Johannesburgo': [-26.20, 28.05], 'Nairobi': [-1.29, 36.82],
  'Estambul': [41.01, 28.98], 'Teherán': [35.69, 51.39], 'Riad': [24.71, 46.68], 'Delhi': [28.61, 77.21], 'Mumbai': [19.08, 72.88],
  'Pekín': [39.90, 116.41], 'Shanghái': [31.23, 121.47], 'Tokio': [35.68, 139.69], 'Seúl': [37.57, 126.98], 'Bangkok': [13.76, 100.50],
  'Yakarta': [-6.21, 106.85], 'Sídney': [-33.87, 151.21], 'Ciudad de México': [19.43, -99.13], 'Bogotá': [4.71, -74.07], 'Lima': [-12.05, -77.04],
  'São Paulo': [-23.55, -46.63], 'Buenos Aires': [-34.60, -58.38], 'Nueva York': [40.71, -74.01], 'Los Ángeles': [34.05, -118.24], 'Toronto': [43.65, -79.38],
};

class _Pin {
  _Pin(this.layer, this.title, this.pos, {this.subtitle = '', this.status = '', this.time, this.source = '', this.url, this.extra = const {}, this.color = Colors.white, this.size = 28, this.rot = 0, this.conflict});
  final String layer, title, subtitle, status, source;
  final String? url;
  final LatLng pos;
  final DateTime? time;
  final Map<String, String> extra;
  final Color color;
  final double size, rot;
  final Conflict? conflict;
}

class WorldTool extends StatefulWidget {
  const WorldTool({super.key});
  @override
  State<WorldTool> createState() => _WS();
}

class _WS extends State<WorldTool> {
  final map = MapController();
  final on = <String, bool>{'conflicts': true, 'quakes': true};
  final pins = <String, List<_Pin>>{};
  final updated = <String, DateTime>{};
  final errors = <String, String>{};
  final busy = <String>{};
  List<Polyline> cablesLines = [];
  final issTrail = <LatLng>[];
  Timer? issTimer;
  int days = 7;
  _Pin? sel;
  Map? eonetRaw;

  @override
  void initState() {
    super.initState();
    _refresh('conflicts');
    _refresh('quakes');
  }

  @override
  void dispose() {
    issTimer?.cancel();
    super.dispose();
  }

  void _toggle(String id, [bool? v]) {
    final val = v ?? !(on[id] ?? false);
    setState(() => on[id] = val);
    if (val) _refresh(id);
    if (id == 'iss') {
      issTimer?.cancel();
      if (val) issTimer = Timer.periodic(const Duration(seconds: 8), (_) => _loadIss());
    }
  }

  Future<void> _refresh(String id) async {
    if (busy.contains(id)) return;
    setState(() { busy.add(id); errors.remove(id); });
    try {
      switch (id) {
        case 'conflicts': _loadConflicts(); break;
        case 'quakes': await _loadQuakes(); break;
        case 'fires': case 'volcanoes': case 'floods': case 'storms': await _loadEonet(); break;
        case 'air': await _loadAir(); break;
        case 'aircraft': await _loadAircraft(); break;
        case 'ships': await _loadShips(); break;
        case 'iss': await _loadIss(); break;
        case 'cables': await _loadCables(); break;
      }
    } catch (e) {
      errors[id] = '$e';
    }
    if (mounted) setState(() => busy.remove(id));
  }

  void _loadConflicts() {
    pins['conflicts'] = [for (final c in conflicts) _Pin('conflicts', c.name, c.pos, subtitle: '${c.region} · desde ${c.since}', status: 'Editorial (no en vivo)', source: 'Ficha editorial NEXUS', color: const Color(0xFFE5484D), size: 30, conflict: c)];
    updated['conflicts'] = DateTime.now();
  }

  Future<void> _loadQuakes() async {
    final f = days == 1 ? '4.5_day' : days == 7 ? '4.5_week' : '4.5_month';
    final j = await getJson('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/$f.geojson');
    final l = <_Pin>[];
    for (final e in (j['features'] as List)) {
      final p = e['properties'], c = e['geometry']['coordinates'];
      final mag = (p['mag'] as num?)?.toDouble() ?? 0;
      final reviewed = p['status'] == 'reviewed';
      l.add(_Pin('quakes', 'M${mag.toStringAsFixed(1)} · ${p['place']}', LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()),
          subtitle: 'Profundidad ${(c[2] as num).toStringAsFixed(0)} km',
          status: reviewed ? 'Confirmado (revisado por USGS)' : 'Preliminar (automático, puede cambiar)',
          time: DateTime.fromMillisecondsSinceEpoch(p['time'] as int),
          source: 'USGS Earthquake Hazards', url: p['url'] as String?,
          extra: {'Magnitud': mag.toStringAsFixed(1), if (p['tsunami'] == 1) 'Tsunami': 'Aviso de tsunami asociado en el feed'},
          color: mag >= 7 ? const Color(0xFFE5484D) : mag >= 6 ? const Color(0xFFFF6B3D) : const Color(0xFFFFB84D),
          size: (14 + (mag - 4.5) * 8).clamp(14, 40).toDouble()));
    }
    pins['quakes'] = l;
    updated['quakes'] = DateTime.now();
  }

  static const _eMap = {'wildfires': 'fires', 'volcanoes': 'volcanoes', 'floods': 'floods', 'severeStorms': 'storms', 'tempExtremes': 'storms', 'drought': 'storms', 'dustHaze': 'storms', 'snow': 'storms'};

  Future<void> _loadEonet() async {
    final j = await getJson('https://eonet.gsfc.nasa.gov/api/v3/events?status=open&days=$days');
    final by = <String, List<_Pin>>{'fires': [], 'volcanoes': [], 'floods': [], 'storms': []};
    for (final e in (j['events'] as List)) {
      final cat = (e['categories'] as List).isEmpty ? '' : e['categories'][0]['id'] as String;
      final lid = _eMap[cat];
      final geos = e['geometry'] as List;
      if (lid == null || geos.isEmpty) continue;
      final g = geos.last;
      LatLng? pos;
      final co = g['coordinates'];
      if (g['type'] == 'Point') {
        pos = LatLng((co[1] as num).toDouble(), (co[0] as num).toDouble());
      } else if (g['type'] == 'Polygon') {
        final ring = co[0] as List;
        pos = LatLng(ring.map((c) => (c[1] as num).toDouble()).reduce((a, b) => a + b) / ring.length, ring.map((c) => (c[0] as num).toDouble()).reduce((a, b) => a + b) / ring.length);
      }
      if (pos == null) continue;
      final srcs = (e['sources'] as List?) ?? [];
      final lay = _layers.firstWhere((x) => x.id == lid);
      by[lid]!.add(_Pin(lid, e['title'] as String, pos,
          subtitle: e['categories'][0]['title'] as String,
          status: 'Preliminar (agregado automáticamente de fuentes oficiales; verifica en la fuente)',
          time: DateTime.tryParse(g['date'] as String? ?? ''),
          source: 'NASA EONET${srcs.isNotEmpty ? ' · ${srcs.map((s) => s['id']).join(', ')}' : ''}',
          url: srcs.isNotEmpty ? srcs.first['url'] as String? : e['link'] as String?,
          extra: {if (g['magnitudeValue'] != null) 'Magnitud': '${g['magnitudeValue']} ${g['magnitudeUnit'] ?? ''}'},
          color: lay.color, size: 26));
    }
    by.forEach((k, v) { pins[k] = v; updated[k] = DateTime.now(); });
  }

  Color _aqiColor(num a) => a <= 20 ? const Color(0xFF4DD99A) : a <= 40 ? const Color(0xFF9BE15D) : a <= 60 ? const Color(0xFFFFD84D) : a <= 80 ? const Color(0xFFFF9F43) : a <= 100 ? const Color(0xFFE5484D) : const Color(0xFF8E3B9B);

  Future<void> _loadAir() async {
    final names = _cities.keys.toList();
    final lat = names.map((n) => _cities[n]![0]).join(','), lon = names.map((n) => _cities[n]![1]).join(',');
    final j = await getJson('https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$lat&longitude=$lon&current=european_aqi,pm2_5,pm10,nitrogen_dioxide,ozone');
    final arr = j is List ? j : [j];
    final l = <_Pin>[];
    for (var i = 0; i < arr.length && i < names.length; i++) {
      final c = arr[i]['current'] as Map?;
      final a = c?['european_aqi'] as num?;
      if (c == null || a == null) continue;
      l.add(_Pin('air', '${names[i]} · AQI ${a.round()}', LatLng(_cities[names[i]]![0], _cities[names[i]]![1]),
          subtitle: 'Índice europeo de calidad del aire',
          status: 'Estimación de modelo (CAMS), no medición directa',
          time: DateTime.tryParse('${c['time']}Z'),
          source: 'Open-Meteo Air Quality (CC BY 4.0)',
          extra: {'PM2.5': '${c['pm2_5']} µg/m³', 'PM10': '${c['pm10']} µg/m³', 'NO₂': '${c['nitrogen_dioxide']} µg/m³', 'O₃': '${c['ozone']} µg/m³'},
          color: _aqiColor(a), size: 30));
    }
    pins['air'] = l;
    updated['air'] = DateTime.now();
  }

  Future<void> _loadAircraft() async {
    final cam = map.camera;
    if (cam.zoom < 4) throw 'Acerca el zoom (≥ 4) para cargar aviones: el servicio gratuito limita las consultas por área.';
    final b = cam.visibleBounds;
    final j = await getJson('https://opensky-network.org/api/states/all?lamin=${b.south.toStringAsFixed(2)}&lomin=${b.west.toStringAsFixed(2)}&lamax=${b.north.toStringAsFixed(2)}&lomax=${b.east.toStringAsFixed(2)}');
    final l = <_Pin>[];
    for (final s in ((j['states'] as List?) ?? [])) {
      if (s[5] == null || s[6] == null || s[8] == true) continue;
      final call = (s[1] as String?)?.trim() ?? '';
      final alt = (s[7] as num?)?.toDouble();
      final v = (s[9] as num?)?.toDouble();
      l.add(_Pin('aircraft', call.isEmpty ? (s[0] as String) : call, LatLng((s[6] as num).toDouble(), (s[5] as num).toDouble()),
          subtitle: 'País de registro: ${s[2]}',
          status: 'Posición ADS-B reportada (red OpenSky; puede tener segundos o minutos de retraso)',
          time: DateTime.fromMillisecondsSinceEpoch(((j['time'] as int?) ?? 0) * 1000),
          source: 'OpenSky Network',
          extra: {
            'ICAO24': '${s[0]}',
            'Altitud': alt == null ? 'n/d' : '${alt.round()} m (${(alt * 3.28084).round()} ft)',
            'Velocidad': v == null ? 'n/d' : '${(v * 3.6).round()} km/h',
            if (s[10] != null) 'Rumbo': '${(s[10] as num).round()}°',
            'Ruta': 'No disponible en el servicio gratuito',
          },
          rot: ((s[10] as num?)?.toDouble() ?? 0) * math.pi / 180, size: 22));
      if (l.length >= 700) break;
    }
    pins['aircraft'] = l;
    updated['aircraft'] = DateTime.now();
  }

  Future<void> _loadShips() async {
    final from = DateTime.now().subtract(const Duration(minutes: 20)).millisecondsSinceEpoch;
    final j = await getJson('https://meri.digitraffic.fi/api/ais/v1/locations?from=$from', headers: {'Digitraffic-User': 'NEXUS'});
    final l = <_Pin>[];
    for (final f in (j['features'] as List)) {
      final p = f['properties'], c = f['geometry']['coordinates'];
      final sog = (p['sog'] as num?)?.toDouble();
      l.add(_Pin('ships', 'MMSI ${p['mmsi']}', LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()),
          subtitle: 'Cobertura AIS: aguas de Finlandia/Báltico',
          status: 'Posición AIS reportada por el buque',
          time: p['timestampExternal'] == null ? null : DateTime.fromMillisecondsSinceEpoch(p['timestampExternal'] as int),
          source: 'Fintraffic Digitraffic (CC BY 4.0)',
          extra: {if (sog != null) 'Velocidad': '${sog.toStringAsFixed(1)} nudos', if (p['cog'] != null) 'Rumbo': '${p['cog']}°'},
          color: const Color(0xFF5AA9FF), size: 16));
      if (l.length >= 800) break;
    }
    pins['ships'] = l;
    updated['ships'] = DateTime.now();
  }

  Future<void> _loadIss() async {
    final j = await getJson('https://api.wheretheiss.at/v1/satellites/25544');
    final pos = LatLng((j['latitude'] as num).toDouble(), (j['longitude'] as num).toDouble());
    issTrail.add(pos);
    if (issTrail.length > 120) issTrail.removeAt(0);
    pins['iss'] = [
      _Pin('iss', 'Estación Espacial Internacional', pos,
          subtitle: 'Órbita baja terrestre',
          status: 'Posición calculada a partir de elementos orbitales (TLE)',
          time: DateTime.fromMillisecondsSinceEpoch(((j['timestamp'] as num).toInt()) * 1000),
          source: 'wheretheiss.at',
          extra: {'Altitud': '${(j['altitude'] as num).toStringAsFixed(0)} km', 'Velocidad': '${(j['velocity'] as num).toStringAsFixed(0)} km/h', 'Visibilidad': '${j['visibility']}'},
          color: const Color(0xFFFFC857), size: 34)
    ];
    updated['iss'] = DateTime.now();
    if (mounted) setState(() {});
  }

  Future<void> _loadCables() async {
    if (cablesLines.isNotEmpty) return;
    final r = await http.get(Uri.parse('https://www.submarinecablemap.com/api/v3/cable/cable-geo.json'), headers: {'User-Agent': nexusUA}).timeout(const Duration(seconds: 40));
    if (r.statusCode != 200) throw 'El mapa de cables respondió con error ${r.statusCode}.';
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    final l = <Polyline>[];
    for (final f in (j['features'] as List)) {
      final g = f['geometry'];
      if (g == null) continue;
      final col = RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch('${f['properties']?['color']}') ? Color(int.parse('FF${'${f['properties']['color']}'.substring(1)}', radix: 16)) : const Color(0xFF2FC4A0);
      final lines = g['type'] == 'MultiLineString' ? g['coordinates'] as List : g['type'] == 'LineString' ? [g['coordinates']] : [];
      for (final ln in lines) {
        final pts = <LatLng>[];
        final n = (ln as List).length;
        for (var i = 0; i < n; i += 3) {
          pts.add(LatLng((ln[i][1] as num).toDouble(), (ln[i][0] as num).toDouble()));
        }
        if (n > 0 && (n - 1) % 3 != 0) pts.add(LatLng((ln[n - 1][1] as num).toDouble(), (ln[n - 1][0] as num).toDouble()));
        if (pts.length > 1) l.add(Polyline(points: pts, strokeWidth: 1.6, color: col.withOpacity(.8)));
      }
    }
    cablesLines = l;
    updated['cables'] = DateTime.now();
  }

  String _t(DateTime d) => '${d.toLocal().hour.toString().padLeft(2, '0')}:${d.toLocal().minute.toString().padLeft(2, '0')}';
  String _dt(DateTime d) => '${d.toLocal().day.toString().padLeft(2, '0')}/${d.toLocal().month.toString().padLeft(2, '0')} ${_t(d)}';

  void _open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  Widget _pinInfo(_Pin p) {
    final h = Theme.of(context).hintColor;
    final c = p.conflict;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(p.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))), IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => sel = null))]),
      if (p.subtitle.isNotEmpty) Text(p.subtitle, style: TextStyle(color: h)),
      const SizedBox(height: 8),
      Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: (p.status.startsWith('Confirmado') ? Colors.green : Colors.amber).withOpacity(.2), borderRadius: BorderRadius.circular(12)), child: Text(p.status, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
      const SizedBox(height: 8),
      if (p.time != null) Text('Fecha del dato: ${_dt(p.time!)}'),
      for (final e in p.extra.entries) Text('${e.key}: ${e.value}'),
      Text('Fuente: ${p.source}', style: TextStyle(color: h, fontSize: 12)),
      if (p.url != null) TextButton.icon(onPressed: () => _open(p.url!), icon: const Icon(Icons.open_in_new_rounded, size: 16), label: const Text('Abrir fuente')),
      if (c != null) ...[
        const Divider(),
        Text(c.context),
        const SizedBox(height: 8),
        const Text('Partes implicadas', style: TextStyle(fontWeight: FontWeight.w700)),
        for (final x in c.parties) Text('• $x'),
        const SizedBox(height: 8),
        const Text('Cronología', style: TextStyle(fontWeight: FontWeight.w700)),
        for (final t in c.timeline) Padding(padding: const EdgeInsets.only(top: 4), child: Text('${t.$1} — ${t.$2}')),
        const SizedBox(height: 8),
        Text(conflictsNote, style: TextStyle(fontSize: 11, color: h)),
        Wrap(spacing: 6, children: [
          ActionChip(avatar: const Icon(Icons.newspaper_rounded, size: 16), label: const Text('Noticias'), onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => NewsPage(title: c.name, queries: {'Reciente': '(${c.newsQuery})'})))),
          ActionChip(label: const Text('Wikipedia'), onPressed: () => _open('https://es.wikipedia.org/wiki/Special:Search?search=${Uri.encodeQueryComponent(c.wiki)}')),
          for (final s in conflictSources) ActionChip(label: Text(s.$1.split(' ').first), onPressed: () => _open(s.$2)),
        ]),
      ],
    ]);
  }

  Widget _panel(VoidCallback re) {
    final h = Theme.of(context).hintColor;
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (sel != null) ...[_pinInfo(sel!), const Divider(height: 28)],
      const Text('Capas', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 4, children: [
        for (final d in [(1, '24 h'), (7, '7 días'), (30, '30 días')])
          ChoiceChip(label: Text(d.$2), selected: days == d.$1, onSelected: (_) { setState(() => days = d.$1); re(); for (final k in ['quakes', 'fires']) { if (on[k] == true) _refresh(k); } }),
      ]),
      Text('El filtro de fecha afecta a terremotos y eventos NASA EONET.', style: TextStyle(fontSize: 11, color: h)),
      const SizedBox(height: 6),
      for (final l in _layers)
        SwitchListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            secondary: busy.contains(l.id) ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(l.icon, color: l.color == Colors.white ? null : l.color),
            title: Text(l.label),
            subtitle: Text(errors[l.id] ?? '${l.note}${updated[l.id] != null ? ' · act. ${_t(updated[l.id]!)}' : ''}${pins[l.id] != null && l.id != 'cables' ? ' · ${pins[l.id]!.length}' : ''}', style: TextStyle(fontSize: 11, color: errors[l.id] != null ? Colors.redAccent : h)),
            value: on[l.id] ?? false,
            onChanged: (v) { _toggle(l.id, v); re(); }),
      if (on['air'] == true) Text('AQI europeo: 0–20 bueno · 40–60 moderado · 80–100 malo · >100 muy malo', style: TextStyle(fontSize: 11, color: h)),
      const SizedBox(height: 8),
      GlassButton('Noticias del mundo', icon: Icons.newspaper_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NewsPage()))),
      const SizedBox(height: 12),
      Text('Datos de terceros. No usar para decisiones de seguridad ni navegación. Sin información táctica.', style: TextStyle(fontSize: 11, color: h)),
    ]);
  }

  Widget _marker(_Pin p) => GestureDetector(
      onTap: () { setState(() => sel = p); if (MediaQuery.of(context).size.width < 900) _sheet(); },
      child: p.layer == 'aircraft'
          ? Transform.rotate(angle: p.rot, child: Icon(Icons.flight_rounded, size: p.size, color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black87))
          : Container(
              decoration: BoxDecoration(shape: BoxShape.circle, color: p.color.withOpacity(p.layer == 'quakes' ? .55 : .9), border: Border.all(color: Colors.white, width: 1.5), boxShadow: [BoxShadow(color: p.color.withOpacity(.6), blurRadius: 10)]),
              child: p.layer == 'air' ? Center(child: Text(p.title.split('AQI ').last, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.black))) : Icon(_layers.firstWhere((l) => l.id == p.layer).icon, size: p.size * .55, color: Colors.white)));

  Future<void> _sheet() => showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (c) => StatefulBuilder(
          builder: (c, ss) => DraggableScrollableSheet(
              initialChildSize: .55,
              minChildSize: .25,
              maxChildSize: .92,
              expand: false,
              builder: (c, sc) => ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                  child: Container(color: Theme.of(context).colorScheme.surface.withOpacity(.94), child: PrimaryScrollController(controller: sc, child: _panel(() => ss(() {}))))))));

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 900;
    final markers = <Marker>[
      for (final l in _layers)
        if (on[l.id] == true && l.id != 'cables') for (final p in (pins[l.id] ?? const <_Pin>[])) Marker(point: p.pos, width: p.size + 4, height: p.size + 4, child: _marker(p)),
    ];
    final mapW = Stack(children: [
      FlutterMap(
          mapController: map,
          options: MapOptions(initialCenter: const LatLng(25, 15), initialZoom: 2.2, minZoom: 1.5, maxZoom: 12, onTap: (_, __) => setState(() => sel = null)),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'dev.nexus.nexus'),
            if (on['cables'] == true && cablesLines.isNotEmpty) PolylineLayer(polylines: cablesLines),
            if (on['iss'] == true && issTrail.length > 1) PolylineLayer(polylines: [Polyline(points: issTrail, strokeWidth: 2, color: const Color(0xFFFFC857))]),
            MarkerLayer(markers: markers),
            const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap · USGS · NASA EONET · OpenSky · Open-Meteo · Digitraffic · TeleGeography (CC BY-SA 3.0) · wheretheiss.at')]),
          ]),
      Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: SafeArea(
              child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: GlassCard(
                      radius: 22,
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      child: Row(children: [
                        IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.of(context).pop()),
                        const Expanded(child: Text('NEXUS WORLD', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 2))),
                        IconButton(tooltip: 'Actualizar vista (aviones, barcos)', icon: const Icon(Icons.refresh_rounded), onPressed: () { for (final k in on.keys) { if (on[k] == true) { busy.remove(k); _refresh(k); } } }),
                        IconButton(tooltip: 'Noticias', icon: const Icon(Icons.newspaper_rounded), onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NewsPage()))),
                        if (!wide) IconButton(tooltip: 'Capas', icon: const Icon(Icons.layers_rounded), onPressed: _sheet),
                      ]))))),
    ]);
    return Scaffold(
        backgroundColor: Colors.black,
        body: wide
            ? Row(children: [Expanded(child: mapW), SizedBox(width: 380, child: Container(color: Theme.of(context).colorScheme.surface.withOpacity(.96), child: SafeArea(child: _panel(() {}))))])
            : mapW);
  }
}
